﻿using System;
using System.IO;
using System.Windows.Forms;
using VisualArrays;

namespace AppVentesTrimestre
{
    /// <summary>
    /// Manipulation de tableaux à 1D et 2D
    /// Méthodes avec paramètres
    /// </summary>
    public partial class FrmPrincipal : Form
    {
        private const string APP_INFO = "(DÉMO)";

        // tableau pré-initialisé à 2D contenant les ventes pour chaque ville à chaque mois
        private decimal[,] m_tabVentes = {
                                         { 12455, 14522, 19111 },
                                         { 33450, 36232, 42244 },
                                         { 31150, 32350, 22250 },
                                         { 33432, 36745, 42278 } };
        #region NE PAS MODIFIER
        // tableau pré-initialisé à 1D des mois
        private string[] m_tabMois = { "Janvier", "Février", "Mars" };

        // tableau pré-initialisé à 1D des villes
        private string[] m_tabVilles = { "Boucherville", "Laval", "Longueuil", "Montréal" };

        //---------------------------------------------------------------------------------
        public FrmPrincipal()
        {
            InitializeComponent();
            Text += APP_INFO;
            InitialiserLesGrilles();
        }
        //---------------------------------------------------------------------------------
        /// <summary>
        /// On va placer par programmation les en-têtes des rangées et des colonnes
        /// </summary>
        private void InitialiserLesGrilles()
        {
            for (int index = 0; index < vdaVentes.RowCount; index++)
                vdaVentes.RowHeaderArray[index] = m_tabVilles[index];

            for (int index = 0; index < vdaVentes.ColumnCount; index++)
                vdaVentes.ColumnHeaderArray[index] = m_tabMois[index];

            vdaTotauxParMois.RowHeaderArray[0] = "Totaux / Mois";
            vdaTotauxVilles.ColumnHeaderArray[0] = "Totaux / Villes";
        }
        //---------------------------------------------------------------------------------
        /// <summary>
        /// Vide le contenu de la grille des ventes
        /// </summary>		
        private void mnuFichierNouveau_Click(object sender, EventArgs e)
        {
            vdaVentes.Clear();
        }

        //---------------------------------------------------------------------------------
        private void mnuFichierQuitter_Click(object sender, EventArgs e)
        {
            Close();
        }
        //---------------------------------------------------------------------------------
        /// <summary>
        /// Todo 2: Placer des valeurs aléatoires dans la grille des ventes seulement
        /// </summary>		
        private void mnuSpécialValeursAléatoires_Click(object sender, EventArgs e)
        {
            vdaVentes.BeginUpdate();
            for (int rangée = 0; rangée < vdaVentes.RowCount; rangée++)
            {
                for (int colonne = 0; colonne < vdaVentes.ColumnCount; colonne++)
                {
                    vdaVentes[rangée, colonne] = vdaVentes.RandomValue();
                }
            }
            vdaVentes.EndUpdate();
        }
        #endregion

        #region Méthodes pour calculer les sommes : À COMPLÉTER
        //---------------------------------------------------------------------------------
        /// <summary>
        /// TODO 01 : Calculer la somme des colonnes et placer le résultat dans vdaTotauxParMois
        /// </summary>
        private void CalculerLaSommeDesColonnes()
        {
            for (int colonne = 0; colonne < vdaVentes.ColumnCount; colonne++)
            {
                decimal accVentesDuMois = 0;
                for (int rangée = 0; rangée < vdaVentes.RowCount; rangée++)
                {
                    accVentesDuMois += vdaVentes[rangée, colonne];
                }
                vdaTotauxParMois[colonne] = accVentesDuMois;
            }
        }
        //---------------------------------------------------------------------------------
        /// <summary>
        /// TODO 02 : Calculer la somme des rangées et placer le résultat dans vdaTotauxVilles
        /// </summary>
        private void CalculerLaSommeDesRangées()
        {
            for (int rangée = 0; rangée < vdaVentes.RowCount; rangée++)
            {
                decimal accVentesVille = 0;
                for (int colonne = 0; colonne < vdaVentes.ColumnCount; colonne++)
                {
                    accVentesVille += vdaVentes[rangée, colonne];
                }
                vdaTotauxVilles[rangée] = accVentesVille;
            }
        }
        //---------------------------------------------------------------------------------
        /// <summary>
        /// TODO 03 : Calculer le grand total de toutes les ventes et placer le résultat dans vsdGrandTotal
        /// </summary>
        private void CalculerGrandTotal()
        {
            decimal grandTotal = 0;

            for (int rangée = 0; rangée < vdaVentes.RowCount; rangée++)
            {
                for (int colonne = 0; colonne < vdaVentes.ColumnCount; colonne++)
                {
                    grandTotal += vdaVentes[rangée, colonne];
                }
            }
            vsdGrandTotal.Value = grandTotal;
        }
        #endregion

        #region Menu Spécial : À COMPLÉTER
        //=============================================================================================
        private void MnuSpécialMultiples_Click(object sender, EventArgs e)
        {
            // TODO 04 : Placer des multiples de 10 dans la grille
            vdaVentes.BeginUpdate();
            decimal nombre = 10;
            for (int rangée = 0; rangée < vdaVentes.RowCount; rangée++)
            {
                for (int colonne = 0; colonne < vdaVentes.ColumnCount; colonne++)
                {
                    vdaVentes[rangée, colonne] = nombre;
                    nombre += 10;
                }
            }
            vdaVentes.EndUpdate();
        }
        //=============================================================================================
        private void MnuSpécialTableauVersGrille_Click(object sender, EventArgs e)
        {
            // TODO 05 : Copier toutes les valeurs du tableau 2D m_tabVentes dans la grille vdaVentes
            vdaVentes.BeginUpdate();
            for (int rangée = 0; rangée < vdaVentes.RowCount; rangée++)
            {
                for (int colonne = 0; colonne < vdaVentes.ColumnCount; colonne++)
                {
                    vdaVentes[rangée, colonne] = m_tabVentes[rangée, colonne];
                }
            }
            vdaVentes.EndUpdate();
        }
        //=============================================================================================
        private void MnuSpécialGrilleVersTableau_Click(object sender, EventArgs e)
        {
            // TODO 06 : Copier toutes les valeurs de la grille vdaVentes dans le tableau m_tabVentes
            for (int rangée = 0; rangée < vdaVentes.RowCount; rangée++)
            {
                for (int colonne = 0; colonne < vdaVentes.ColumnCount; colonne++)
                {
                    m_tabVentes[rangée, colonne] = vdaVentes[rangée, colonne];
                }
            }
        }
        #endregion

        #region Événement ValueChanged : NE PAS MODIFIER
        //---------------------------------------------------------------------------------
        private void vdaVentes_ValueChanged(object sender, ValueChangedEventArgs e)
        {
            CalculerLaSommeDesColonnes();
            CalculerLaSommeDesRangées();
            CalculerGrandTotal();
        }
        #endregion

        #region Menu Enregistrer, charger fichier
        private void MnuFichierEnregistrer_Click(object sender, EventArgs e)
        {
            // TODO 07 : Copier toutes les valeurs de la grille vdaVentes dans le fichier Ventes.txt
            StreamWriter objFichier = new StreamWriter("Ventes.txt");

            for (int rangée = 0; rangée < vdaVentes.RowCount; rangée++)
            {
                for (int colonne = 0; colonne < vdaVentes.ColumnCount; colonne++)
                {
                    objFichier.WriteLine(vdaVentes[rangée, colonne]);
                }
            }
            objFichier.Close();
        }

        private void MnuFichierCharger_Click(object sender, EventArgs e)
        {
            // TODO 08 : Copier toutes les valeurs du fichier Ventes.txt dans la grille vdaVentes
            StreamReader objFichier = new StreamReader("Ventes.txt");

            for (int rangée = 0; rangée < vdaVentes.RowCount; rangée++)
            {
                for (int colonne = 0; colonne < vdaVentes.ColumnCount; colonne++)
                {
                    vdaVentes[rangée, colonne] = decimal.Parse(objFichier.ReadLine());
                }
            }

            objFichier.Close();
        }
        #endregion

    }
}
