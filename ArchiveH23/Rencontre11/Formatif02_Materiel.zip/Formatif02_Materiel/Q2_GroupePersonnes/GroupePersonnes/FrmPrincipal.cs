﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;

namespace GroupePersonnes
{
    public partial class FrmPrincipal : Form
    {

        #region Variables membres, constructeur et ChargerPersonnes (NE PAS modifier)
        // TODO 00 : Observez les variables membres de la Classe FrmPrincipal et la structure de la classe Personne
        // TODO 01 : Vous devez utiliser la boucle foreach pour chaque question demandant un parcours d'une collection

        public const string APP_INFO = "(Démo)";
        //----------- variables membre -------------------------------------------------------------------------
        private const string LISTE_DES_PERSONNES = "Fichiers\\ListeDesPersonnes.txt";

        private List<Personne> m_colPersonnes = new List<Personne>();
        private int m_indexPersonneCourante;
        private bool m_estModifié = false;

        //=======================================================================================================
        public FrmPrincipal()
        {
            InitializeComponent();
            this.Text += APP_INFO;
            //----------------------
            ChargerPersonnes(LISTE_DES_PERSONNES);
            AfficherStatistiques();
            m_indexPersonneCourante = -1;
        }

        //======================================================================================================
        /// <summary>
        /// Lit les informations dans le fichier, les charge en mémoire dans la liste générique.
        /// S'assurer que le fichier exite sur le disque, sinon affiche un message Box.
        /// Affiche la première personne de la liste.
        /// </summary>
        /// <param name="pNomDuFichier">nom du fichier à lire</param>
        /// ----------------------------------------------------------------------------------------------------
        private void ChargerPersonnes(string pNomDuFichier)
        {
            if (!File.Exists(pNomDuFichier))
            {
                MessageBox.Show("Impossible de trouver la liste des personnes",
                                Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //--------------------------------------------------------------------------------
            m_colPersonnes.Clear();

            //---- lecture dans le fichier ----------------------------------------------------
            // Remplir la collection m_colPersonnes à partir du fichier texte pNomDuFichier
            
            StreamReader objStreamReader = new StreamReader(pNomDuFichier);
            while (!objStreamReader.EndOfStream)
            {
                string uneLigneLue = objStreamReader.ReadLine();

                Personne unePersonne = new Personne(uneLigneLue);
                m_colPersonnes.Add(unePersonne);
            }
            objStreamReader.Close();
        }
        //================================================================
        private void mnuFichierQuitter_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //==============================================================================================================
        /// <summary>
        /// Au moment de quitter, s'il y a eu des modifications à la liste, on la sauvegarde dans un fichier.
        /// </summary>
        /// ------------------------------------------------------------------------------------------------------------
        private void FrmPrincipal_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (m_estModifié)
            {
                SauvegarderListe(LISTE_DES_PERSONNES);
            }
        }
        #endregion

        


        #region TODO 02 : Afficher les infos d'une personne
        //==================================================================================
        /// <summary>
        /// TODO 02 : Afficher dans les différents TextBox, les infos concernant la personne
        ///           dont l'index est fourni en paramètre.
        /// </summary>
        /// <param name="pIndex">index de la personne à afficher</param>
        /// --------------------------------------------------------------------------------
        private void AfficherElementCourant(int pIndex)
        {
            // À COMPLÉTER...
           

        }
        #endregion

        #region TODO 03 à 06 : méthodes IndexPersonneSelon... et bouton Rechercher
        /// ------------------------------------------------------------------------------------------------
        /// <summary>
        /// TODO 03 : Recherche dans la liste générique, l'index de la personne dont le NAS est spécifié.
        /// </summary>
        /// <param name="pNasRecherché">Nas à rechercher dans la liste</param>
        /// <returns>index de la personne trouvée, -1 si non trouvée</returns>
        /// ------------------------------------------------------------------------------------------------
        private int IndexPersonneSelonNas(string pNasRecherché)
        {
            // À COMPLÉTER...
           
            return -1;
        }
        /// --------------------------------------------------------------------------------------------------
        /// <summary>
        /// TODO 04 : Recherche dans la liste générique, l'index de la personne dont le PRENOM est spécifié.
        /// </summary>
        /// <param name="pPrenomRecherché">prénom à rechercher dans la liste</param>
        /// <returns>index de la personne trouvée, -1 si non trouvée</returns>
        /// --------------------------------------------------------------------------------------------------
        private int IndexPersonneSelonPrenom(string pPrenomRecherché)
        {
            // À COMPLÉTER...

            
            return -1;
        }
        /// ------------------------------------------------------------------------------------------------
        /// <summary>
        /// TODO 05 : Recherche dans la liste générique, l'index de la personne dont le NOM est spécifié.
        /// </summary>
        /// <param name="pNomRecherché">nom à rechercher dans la liste</param>
        /// <returns>index de la personne trouvée, -1 si non trouvée</returns>
        /// ------------------------------------------------------------------------------------------------
        private int IndexPersonneSelonNom(string pNomRecherché)
        {
            // À COMPLÉTER...

           
            return -1;
        }
        ///-------------------------------------------------------------------------------------------
        /// <summary>
        /// TODO 06 : Recherche et affiche la personne dont le NAS ou le NOM ou le PRENOM est indiqué.
        /// </summary>
        ///-------------------------------------------------------------------------------------------
        private void btnRechercher_Click(object sender, EventArgs e)
        {
            // À COMPLÉTER..
            
        }
        #endregion

       

        #region bouton ajouter une personne 

        ///-------------------------------------------------------------------------------------------
        /// <summary>
        /// Ajouter une personne à la fin de la liste générique. 
        /// Les NAS qui ont moins de 9 caractères ne sont pas acceptés
        /// Les noms qui ont moins de 3 caractères ne sont pas acceptés
        /// </summary>
        /// ------------------------------------------------------------------------------------------
        private void btnAjouter_Click(object sender, EventArgs e)
        {
            // À COMPLÉTER...
            string nas = mtxNAS.Text;

            int indexNASDéjàLà = IndexPersonneSelonNas(nas);
            if (indexNASDéjàLà != -1)
            {
                MessageBox.Show("Il y a déjà une personne avec ce NAS.",
                                Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            string nom = txtNom.Text.ToUpper(); 
            string prenom = txtPrenom.Text;
            int age = int.Parse(txtAge.Text);

            //condition de garde
            if (nas.Length < 11 || nom.Length < 3)
            {
                MessageBox.Show("Aucun élément n'a été ajouté à la liste",
                                Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Personne unePersonne = new Personne(nas, prenom, nom,age);
            m_colPersonnes.Add(unePersonne);

            m_estModifié = true;

            MessageBox.Show(m_colPersonnes[m_colPersonnes.Count - 1].Nom + " a été ajouté.", "Liste générique");
            txtNom.Clear();
            txtPrenom.Clear();
            mtxNAS.Clear();
            txtAge.Clear();
            txtIndex.Clear();

            AfficherStatistiques();


        }

        #endregion

        #region TODO 07 : bouton supprimer une personne
        ///-----------------------------------------------------------------------------------
        /// <summary>
        /// TODO 07 : Supprimer la personne affichée de la liste générique.
        /// </summary>
        ///-----------------------------------------------------------------------------------
        private void btnSupprimer_Click(object sender, EventArgs e)
        {
            // À COMPLÉTER...
           





            // NE PAS MODIFIER
            m_estModifié = true;

            txtNom.Clear();
            txtPrenom.Clear();
            mtxNAS.Clear();
            txtAge.Clear();
            txtIndex.Clear();

            AfficherStatistiques();
        }
        #endregion

       
        #region TODO 08 et 09 : boutons suivant et précédent
        //==================================================================================
        /// <summary>
        /// TODO 08 : Avancer d'une position dans la collection et afficher l'élément courant.
        /// </summary>
        /// --------------------------------------------------------------------------------
        private void btnSuivant_Click(object sender, EventArgs e)
        {
            // À COMPLÉTER...
           


        }

        //=====================================================================================
        /// <summary>
        /// TODO 09 : Reculer d'une position dans la collection et afficher l'élément courant.
        /// </summary>
        /// -----------------------------------------------------------------------------------
        private void btnPrecedent_Click(object sender, EventArgs e)
        {
            // À COMPLÉTER...
            




        }
        #endregion

        #region TODO 10 à 12 : Statistiques

        /// <summary>
        /// TODO 10 : Calculer et retourner l'age moyen des personnes
        /// </summary>
        /// <returns></returns>
        public int AgeMoyen()
        {
            // À COMPLÉTER...
           
            return 0;
        }
        /// <summary>
        /// TODO 11 : Calculer et retourner l'age minimum 
        /// </summary>
        /// <returns></returns>
        public int AgeMin()
        {
            // À COMPLÉTER...
            

            return 0;

        }
        /// <summary>
        /// /// TODO 12 : Calculer et retourner l'age maximum 
        /// </summary>
        /// <returns></returns>
        public int AgeMax()
        {
            // À COMPLÉTER...
            

            return 0;

        }

        public void AfficherStatistiques()
        {
            txtAgeMin.Text = AgeMin().ToString();
            txtAgeMax.Text = AgeMax().ToString();
            txtAgeMoyen.Text = AgeMoyen().ToString();
        }

        #endregion

        #region méthode Sauvegarder la collection dans un fichier Texte
        //==================================================================================
        /// <summary>
        /// TODO 13 : Sauvegarder la liste de personnes dans le fichier Texte.
        ///            On sépare les données d'une personne par une virgule.
        ///            Voici un exemple: 205456789,Robert,TREMBLAY
        ///                              nas,prénom,nom em majuscules
        /// </summary>
        /// --------------------------------------------------------------------------------
        private void SauvegarderListe(string pNomFichier)
        {
            // À COMPLÉTER...
           

        }

        #endregion
    }
}
