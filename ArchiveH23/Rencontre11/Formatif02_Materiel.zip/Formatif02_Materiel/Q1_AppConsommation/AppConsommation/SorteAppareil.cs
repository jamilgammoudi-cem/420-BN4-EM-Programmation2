﻿namespace AppConsommation
{
    ///========================================================================
    /// <summary>
    /// Énumère les différentes sortes d'appareils qui peuvent être branchés.
    /// </summary>
    /// -----------------------------------------------------------------------
    public enum SorteAppareil { Aucun = -1, Ordinateur, Lampe, Rasoir, Séchoir };
}