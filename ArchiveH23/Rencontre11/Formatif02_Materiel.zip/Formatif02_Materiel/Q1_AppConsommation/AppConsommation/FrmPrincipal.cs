﻿using System;
using System.Windows.Forms;

namespace AppConsommation
{
    /// <summary>
    /// Une application qui modélise deux prises de courant qui consomment de l'électricité d'un compteur hydro-électrique.
    /// 
    /// Liste des taches :
    /// TODO 00 : Observez que les valeurs des constantes pour la classe PriseDeCourant seront :
    ///	- CONSOMMATION_ORDINATEUR = 330;
    ///	- CONSOMMATION_LAMPE = 50;
    ///	- CONSOMMATION_RASOIR = 12;
    ///	- CONSOMMATION_SÉCHOIR = 1500;
    /// TODO 01 : En vous basant sur l’image "Diagramme classes.png" vous devez définir la classe CompteurHydro.
    /// TODO 02 : Dans le fichier Correcteur.cs activer le test de compilation de la classe CompteurHydro.
    /// TODO 03 : En vous basant sur l’image "Diagramme classes.png" vous devez définir la classe PriseDeCourant.
    /// TODO 04 : Dans le fichier Correcteur.cs activer le test de compilation de la classe PriseDeCourant.
    /// TODO 05 : Compléter la logique de la classe CompteurHydro puis activer les tests de fonctionnement pour cette classe dans Correcteur.cs
    /// TODO 06 : Compléter la logique de la classe PriseDeCourant puis activer les tests de fonctionnement pour cette classe dans Correcteur.cs.
    /// TODO 07 : Enlever les commentaires dans le formulaire afin de faire fonctionner l’application comme la démo.
    /// </summary>
    public partial class FrmPrincipal : Form
    {
        public const String APP_INFO = "(Matériel)";

        #region Champs
        //private CompteurHydro m_objCompteur;
        //private PriseDeCourant m_objPriseDeCourant1;
        //private PriseDeCourant m_objPriseDeCourant2;
        #endregion

        #region Constructeur et méthode
        //=================================================================================================
        public FrmPrincipal()
        {
            InitializeComponent();
            Text += APP_INFO;

            //m_objCompteur = new CompteurHydro();

            //m_objPriseDeCourant1 = new PriseDeCourant(m_objCompteur);
            //m_objPriseDeCourant2 = new PriseDeCourant(m_objCompteur);

            AfficherConsommationCompteur();
        }
        //=================================================================================================
        private void AfficherConsommationCompteur()
        {
            //lblConsommationCompteur.Text = m_objCompteur.ConsommationActuelle.ToString("000000");
        }
        #endregion

        #region Gestionnaires d'événements
        //=================================================================================================
        private void cboPrise1Appareil_SelectedIndexChanged(object sender, EventArgs e)
        {
            //m_objPriseDeCourant1.BrancherAppareil((SorteAppareil)cboPrise1Appareil.SelectedIndex);
            //numPrise1Durée.Value = 0;
        }
        //=================================================================================================
        private void cboPrise2Appareil_SelectedIndexChanged(object sender, EventArgs e)
        {
            //m_objPriseDeCourant2.BrancherAppareil((SorteAppareil)cboPrise2Appareil.SelectedIndex);
            //numPrise2Durée.Value = 0;
        }
        //=================================================================================================
        private void numPrise1Durée_ValueChanged(object sender, EventArgs e)
        {
            //int duréeEnMinutes = (int)numPrise1Durée.Value;
            //txtPrise1Qte.Text = m_objPriseDeCourant1.ConsommationPrévue(duréeEnMinutes).ToString();
        }
        //=================================================================================================
        private void numPrise2Durée_ValueChanged(object sender, EventArgs e)
        {
            //int duréeEnMinutes = (int)numPrise2Durée.Value;
            //txtPrise2Qte.Text = m_objPriseDeCourant2.ConsommationPrévue(duréeEnMinutes).ToString();
        }
        //=================================================================================================
        private void btnPrise1Consommmer_Click(object sender, EventArgs e)
        {
            //m_objPriseDeCourant1.Consommer(int.Parse(txtPrise1Qte.Text));
            //lblConsommationCompteur.Text = m_objPriseDeCourant1.CompteurHydro.ConsommationActuelle.ToString("000000");
            //cboPrise1Appareil.SelectedIndex = -1;
        }

        //=================================================================================================
        private void btnPrise2Consommer_Click(object sender, EventArgs e)
        {
            //m_objPriseDeCourant2.Consommer(int.Parse(txtPrise2Qte.Text));
            //lblConsommationCompteur.Text = m_objPriseDeCourant2.CompteurHydro.ConsommationActuelle.ToString("000000");
            //cboPrise2Appareil.SelectedIndex = -1;
        }
        //=================================================================================================
        private void mnuFichierQuitter_Click(object sender, EventArgs e)
        {
            Close();
        }
        #endregion
    }
}
