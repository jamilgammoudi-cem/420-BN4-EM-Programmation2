﻿using System;
using System.Windows.Forms;

namespace ApplicationDistributrice
{
    ///==============================================================================
    /// <summary>
    /// Simule une machine distributrice qui contient différents breuvages.
    /// 
    /// TODO 01 : Ajouter une nouvelle classe nommée Distributrice (voir diagramme dans le matériel)
    /// TODO 02 : Ajouter dans le fichier Distributrice.cs un nouveau type par énumération (voir diagramme dans le matériel)
    /// TODO 03 : Ajouter dans la classe distributrice une constante MAX_QUANTITÉ = 5
    /// TODO 04 : Dans le constructeur sans paramètre initialiser les quantités à MAX_QUANTITÉ
    /// TODO 05 : Compléter le formulaire pour faire fonctionner l'application
    /// 
    /// </summary>
    /// =============================================================================
    public partial class FrmPrincipal : Form
    {
        public const string APP_INFO = "(Démo)";
        //=====================================================
        //  CHAMP:  Variable  membre de la classe FrmPrincipal
        //-----------------------------------------------------
        private Distributrice m_objMachine;

        //=====================================================
        public FrmPrincipal()
        {
            InitializeComponent();
            Text += APP_INFO;
            //-----------------------
            m_objMachine = new Distributrice();
            AfficherInfosMachine();
        }
        //==============================================================================
        private void mnuFichierQuitter_Click(object sender, System.EventArgs e)
        {
            Close();
        }

        /// =================================================================================
        /// <summary>
        /// Affiche les informations dans la section "Infos sur la machine".
        /// </summary>
        /// =================================================================================
        private void AfficherInfosMachine()
        {
            txtNbCokes.Text = m_objMachine.Quantite(SorteBreuvage.Coke).ToString();
            txtNb7Up.Text = m_objMachine.Quantite(SorteBreuvage.SevenUp).ToString();
            txtNbJusDePommes.Text = m_objMachine.Quantite(SorteBreuvage.JusDePommes).ToString();
            txtNbTheGlace.Text = m_objMachine.Quantite(SorteBreuvage.TheGlace).ToString();

            int totalBreuvage = m_objMachine.Quantite(SorteBreuvage.Coke) + m_objMachine.Quantite(SorteBreuvage.SevenUp) +
                                m_objMachine.Quantite(SorteBreuvage.JusDePommes) + m_objMachine.Quantite(SorteBreuvage.TheGlace);
            txtEtat.Text = "Breuvages disponibles :        " + totalBreuvage;
        }
        //==============================================================================
        /// <summary>
        ///   Activer ou désactiver les boutons correspondant aux différents breuvages.
        /// </summary>
        /// ---------------------------------------------------------------------------
        private void MettreAJourBoutons()
        {
            btnObtenirUnCoke.Enabled = m_objMachine.EstDisponible(SorteBreuvage.Coke);
            btnObtenirUn7Up.Enabled = m_objMachine.EstDisponible(SorteBreuvage.SevenUp);
            btnObtenirUnJusDePommes.Enabled = m_objMachine.EstDisponible(SorteBreuvage.JusDePommes);
            btnObtenirUnTheGlace.Enabled = m_objMachine.EstDisponible(SorteBreuvage.TheGlace);
        }
        //=====================================================================================
        /// <summary>
        /// Ejecter le breuvage demandé et mettre à jours les boutons
        /// </summary>
        /// <param name="pBreuvage">breuvage demandé par le client</param>
        /// -----------------------------------------------------------------------------------
        private void ObtenirUnBreuvage(SorteBreuvage pBreuvage)
        {
            m_objMachine.Ejecter(pBreuvage);
            AfficherInfosMachine();
            MettreAJourBoutons();
        }
        //=====================================================================================
        private void btnObtenirUnCoke_Click(object sender, System.EventArgs e)
        {
            ObtenirUnBreuvage(SorteBreuvage.Coke);
        }
        //=====================================================================================
        private void btnObtenirUn7Up_Click(object sender, System.EventArgs e)
        {
            ObtenirUnBreuvage(SorteBreuvage.SevenUp);
        }
        //=====================================================================================
        private void btnObtenirUnJusDePommes_Click(object sender, System.EventArgs e)
        {
            ObtenirUnBreuvage(SorteBreuvage.JusDePommes);
        }
        //=====================================================================================
        private void btnObtenirUnTheGlace_Click(object sender, System.EventArgs e)
        {
            ObtenirUnBreuvage(SorteBreuvage.TheGlace);
        }

        //====================================================================================
        private void btnRecharger_Click(object sender, EventArgs e)
        {
            m_objMachine.Recharger();
            AfficherInfosMachine();
            MettreAJourBoutons();
        }
    }
}