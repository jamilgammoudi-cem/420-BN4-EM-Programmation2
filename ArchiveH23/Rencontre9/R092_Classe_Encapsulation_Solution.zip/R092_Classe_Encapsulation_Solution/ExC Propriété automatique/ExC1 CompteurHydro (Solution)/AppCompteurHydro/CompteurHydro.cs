namespace AppCompteurHydro
{
    /// ------------------------------------------------------------------------------------
    /// <summary>
    /// Repr�sente un compteur hydro �lectrique 
    /// </summary>
    /// ------------------------------------------------------------------------------------
    public class CompteurHydro
    {

        // TODO 01 : Utiliser une propri�t� automatique pour la ConsommationActuelle

        #region PROPRI�T�

        /// ---------------------------------------------------------------------------------
        /// <summary>
        ///    Obtient la consommation totale actuelle 
        /// </summary>
        public int ConsommationActuelle { get; private set; }

        #endregion

        #region CONSTRUCTEUR

        ///==================================================================================
        /// <summary>
        ///   Initialise une nouvelle instance. 
        /// </summary>
        public CompteurHydro()
        {
            ConsommationActuelle = 0;
        }

        #endregion

        #region M�THODE

        ///==================================================================================
        /// <summary>
        /// Augmente la quantit� d'�lectricit� consomm�e.
        /// </summary>
        /// <param name="pQuantit�Kwh">Quantit� d'�lectricit� � ajouter au compteur</param>
        public void Consommer(int pQuantit�Kwh)
        {
            ConsommationActuelle += pQuantit�Kwh;
        }

        #endregion
    }
}
