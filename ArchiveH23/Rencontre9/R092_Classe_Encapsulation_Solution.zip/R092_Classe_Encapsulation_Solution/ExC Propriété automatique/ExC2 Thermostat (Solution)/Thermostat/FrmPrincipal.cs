﻿using System;
using System.Windows.Forms;

namespace Thermostat
{
    public partial class FrmPrincipal : Form
    {
        public const string APP_INFO = "(Solution)";
        /// ==================================================================================
        /// <summary>
        /// Variable membre permettant de référer sur un objet de la classe Thermostat
        /// </summary>
        /// ----------------------------------------------------------------------------------
        private Thermostat m_objThermostat;
        
        //====================================================================================
        public FrmPrincipal()
        {
            InitializeComponent();
            Text += APP_INFO;

            m_objThermostat = new Thermostat();
            lblTemperature.Text = m_objThermostat.Temperature.ToString();
            ActualiserBoutonsSelonContexte();
        }

        //====================================================================================
        private void btnAugmenter_Click(object sender, System.EventArgs e)
        {
            m_objThermostat.AugmenterTemperature();
            lblTemperature.Text = m_objThermostat.Temperature.ToString();
            ActualiserBoutonsSelonContexte();
        }

        //====================================================================================
        private void btnDiminuer_Click(object sender, System.EventArgs e)
        {
            m_objThermostat.DiminuerTemperature();
            lblTemperature.Text = m_objThermostat.Temperature.ToString();
            ActualiserBoutonsSelonContexte();
        }

        //====================================================================================
        private void mnuAffichageTempMin_Click(object sender, EventArgs e)
        {
            lblTemperature.Text = Thermostat.MIN_TEMPERATURE.ToString();
        }

        //====================================================================================
        private void mnuAffichageTempMax_Click(object sender, EventArgs e)
        {
            lblTemperature.Text = Thermostat.MAX_TEMPERATURE.ToString();
        }

        //====================================================================================
        private void mnuAffichageTempCourante_Click(object sender, EventArgs e)
        {
            lblTemperature.Text = m_objThermostat.Temperature.ToString();
        }

        //====================================================================================
        private void ActualiserBoutonsSelonContexte()
        {
            btnDiminuer.Enabled  = m_objThermostat.Temperature > Thermostat.MIN_TEMPERATURE;
            btnAugmenter.Enabled = m_objThermostat.Temperature < Thermostat.MAX_TEMPERATURE;
        }

        //====================================================================================
        private void mnuFichierQuitter_Click(object sender, System.EventArgs e)
        {
            Close();
        }
    }
}