using System;

namespace ApplicationParcometre
{

    /// =============================================================================
    /// <summary>
    /// Repr�sente un parcom�tre dans lequel on peut ins�rer des pi�ces de monnaie
    /// et simuler le temps qui passe.
    /// </summary>
    public class Parcometre
    {
        public const int COUT_PAR_MINUTE = 5; // 5 cents la minute
        public const int MONTANT_MINIMUM = 25; // 25 cents

        #region Champs et Propri�t�s
        // =============================================================================
        // Nombre de minutes qui reste
        private int m_minutesRestantes;

        /// =============================================================================
        private int m_montantTotal; // montant total ajout� dans le parcom�tre
        ///-----------------------------------------------------------------------------
        /// <summary>
        /// Permet d'obtenir le montant total ajout� dans le parcom�tre
        /// </summary>
        public int MontantTotal
        {
            get
            {
                return m_montantTotal;
            }
        }
        #endregion

        #region Propri�t�s calcul�es
        /// =============================================================================
        /// <summary>
        ///  Obtient le temps qui reste avant l'infraction.
        ///  L'information est format�e dans un cha�ne comme suit : HH:MM
        /// </summary>
        public string TempsRestant
        {
            get
            {
                int nbHeures = m_minutesRestantes / 60;
                int nbMinutes = m_minutesRestantes % 60;
                return nbHeures.ToString("00") + ":" + nbMinutes.ToString("00");
            }
        }

        /// <summary>
        /// Obtient l'�tat de la transaction avec l'utilisateur.
        /// Il est en infraction si le nombre de minutes restantes est 0
        /// </summary>
        public bool EnInfraction
        {
            get { return m_minutesRestantes == 0; }
        }
        #endregion

        #region Constructeurs
        /// =============================================================================
        /// <summary>
        ///  Initialise une nouvelle instance de la classe Parcom�tre. 
        ///  Il n'y a pas d'argent dans le parcom�tre.
        /// </summary>
        public Parcometre()
        {
            m_montantTotal = 0;
            m_minutesRestantes = 0;
        }
        #endregion

        #region M�thodes
        /// =============================================================================
        /// <summary>
        ///  Ins�re un montant d'argent en cents ajoute des minutes au parcom�tre
        /// </summary>
        /// <param name="pMonnaie">montant � ins�r�</param>
        public void InsererMonnaie(int pMonnaie)
        {
            if (pMonnaie < 0)
            {
                throw new ArgumentOutOfRangeException();
            }

            m_minutesRestantes += pMonnaie / COUT_PAR_MINUTE;
            m_montantTotal += pMonnaie;
        }
        /// =============================================================================
        /// <summary>
        ///   Simuler le temps qui passe par �tape de 1 minute.
        /// </summary>
        public void ConsommerUneMinuteDeTemps()
        {
            if (m_minutesRestantes < 1)
            {
                throw new ArgumentOutOfRangeException();
            }

            m_minutesRestantes--;
        }

        #endregion
    }
}
