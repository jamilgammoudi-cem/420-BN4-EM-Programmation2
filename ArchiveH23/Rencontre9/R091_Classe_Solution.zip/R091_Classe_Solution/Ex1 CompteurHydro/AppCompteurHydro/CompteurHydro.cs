namespace AppCompteurHydro
{
    /// ------------------------------------------------------------------------------------
    /// <summary>
    /// Repr�sente un compteur hydro �lectrique 
    /// </summary>
    /// ------------------------------------------------------------------------------------
    public class CompteurHydro
    {
        // TODO 01 : Compl�ter cette classe en se basant sur le diagramme "Ex1 CompteurHydro.png"

        #region CHAMPS (variable membre) ET PROPRI�T�

        ///==================================================================================
        private int m_consommationActuelle;
        /// ---------------------------------------------------------------------------------
        /// <summary>
        ///    Obtient la consommation totale actuelle 
        /// </summary>
        public int ConsommationActuelle
        {
            get { return m_consommationActuelle; }
        }

        #endregion

        #region CONSTRUCTEUR

        ///==================================================================================
        /// <summary>
        ///   Initialise une nouvelle instance. 
        /// </summary>
        public CompteurHydro()
        {
            m_consommationActuelle = 0;
        }

        #endregion

        #region M�THODE

        ///==================================================================================
        /// <summary>
        /// Augmente la quantit� d'�lectricit� consomm�e.
        /// </summary>
        /// <param name="pQuantit�Kwh">Quantit� d'�lectricit� � ajouter au compteur</param>
        public void Consommer(int pQuantit�Kwh)
        {
            m_consommationActuelle += pQuantit�Kwh;
        }

        #endregion
    }
}
