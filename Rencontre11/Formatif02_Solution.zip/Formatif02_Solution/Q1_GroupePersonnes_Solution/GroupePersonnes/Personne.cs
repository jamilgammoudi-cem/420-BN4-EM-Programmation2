﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GroupePersonnes
{
    /// ------------------------------------------------------------------------------
    /// <summary>
    ///	 Représente une personne : son numéro d'assurance sociale, son nom et prénom.
    /// </summary>
    /// ------------------------------------------------------------------------------
    public class Personne
    {
        //------------------------------------------------------
        private string m_nas;
        /// ----------------------------------------------------
        /// <summary>
        /// Obtient et définit le numéro sociale d'une personne.
        /// </summary>
        /// ----------------------------------------------------
        public string Nas
        {
            get { return m_nas; }
            set { m_nas = value; }
        }

        //------------------------------------------------------
        private string m_nom;
        /// ----------------------------------------------------
        /// <summary>
        /// Obtient et définit le nom d'une personne.
        /// </summary>
        /// ----------------------------------------------------
        public string Nom
        {
            get { return m_nom; }
            set { m_nom = value; }
        }
        //------------------------------------------------------
        private string m_prenom;
        /// ----------------------------------------------------
        /// <summary>
        /// Obtient et définit le prénom d'une personne.
        /// </summary>
        /// ----------------------------------------------------
        public string Prenom
        {
            get { return m_prenom; }
            set { m_prenom = value; }
        }
        //------------------------------------------------------
        private int m_age;
        /// ----------------------------------------------------
        /// <summary>
        /// Obtient et définit l'age d'une personne.
        /// </summary>
        /// ----------------------------------------------------
        public int Age
        {
            get { return m_age; }
            set { m_age = value; }
        }
        //---------------------------------------------------------------
        /// <summary>
        /// Instancie une personne avec les données passées en paramètre.
        /// </summary>
        /// <param name="pNas">nas de la personne à créer</param>
        /// <param name="pNom">nom de la personne à créer</param>
        /// <param name="pPrenom">prénom de la personne à créer</param>
        /// /// <param name="pAge">age de la personne à créer</param>
        /// -------------------------------------------------------------
        public Personne(string pNas, string pPrenom, string pNom, int pAge)
        {
            m_nas = pNas;
            m_prenom = pPrenom;
            m_nom = pNom;
            m_age = pAge;
        }
        //----------------------------------------------------------------------------------
        /// <summary>
        /// Instancie une personne avec  la chaîne passée en paramètre.
        /// Les données sont séparées par une virgule, voici un exemple:
        ///              NAS, prenom, nom.
        /// </summary>
        /// <param name="pChaineInfos">chaine des données séparées par une virgule</param>
        /// ---------------------------------------------------------------------------------
        public Personne(string pChaineInfos)
        {
            string[] tabInfos = pChaineInfos.Split(',');
          
            m_nas = tabInfos[0];
            m_prenom = tabInfos[1];
            m_nom = tabInfos[2];
            m_age = int.Parse(tabInfos[3]);

        }
    }
}
