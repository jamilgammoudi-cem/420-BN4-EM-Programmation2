﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AppConsommation
{
    /// ------------------------------------------------------------------------------------
    /// <summary>
    /// Modélise un compteur hydro électrique 
    /// </summary>
    /// ------------------------------------------------------------------------------------
    public class CompteurHydro
    {
        #region CHAMPS (variable membre) ET PROPRIÉTÉ

        ///==================================================================================
        private int m_consommationActuelle;
        /// ---------------------------------------------------------------------------------
        /// <summary>
        ///    Obtient la consommation actuelle totale
        /// </summary>
        public int ConsommationActuelle
        {
            get { return m_consommationActuelle; }
        }

        #endregion

        #region CONSTRUCTEUR

        ///==================================================================================
        /// <summary>
        ///   Initialise une nouvelle instance. 
        /// </summary>
        public CompteurHydro()
        {
            m_consommationActuelle = 0;
        }

        #endregion

        #region MÉTHODE

        ///==================================================================================
        /// <summary>
        /// Augmente la quantité d'électricité consommée.
        /// </summary>
        /// <param name="pNbrWatts">Quantité d'électricité à ajouter au compteur</param>
        public void Consommer(int pNbrWatts)
        {
            if (pNbrWatts < 0)
                throw new ArgumentOutOfRangeException();

            m_consommationActuelle += pNbrWatts;
        }

        #endregion
    }
}
