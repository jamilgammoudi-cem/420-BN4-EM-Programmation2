using System;

namespace AppConsommation
{
    ///=========================================================================
    /// <summary>
	///  Mod�lise une prise de courant qui consomme de l'�lectricit�.
	/// </summary>
    /// ------------------------------------------------------------------------
	public class PriseDeCourant
    {
        #region Constantes
        //Consommation en watts par minute des appareils
        public const int CONSOMMATION_ORDINATEUR = 330;
        public const int CONSOMMATION_LAMPE = 50;
        public const int CONSOMMATION_RASOIR = 12;
        public const int CONSOMMATION_S�CHOIR = 1500;

        #endregion

        #region PROPRI�T�S
        /// ================================================================
        private SorteAppareil m_appareilBranch�;
        ///-----------------------------------------------------------------
        /// <summary>
        /// Obtient et d�finit le type d'appareil branch� dans la prise.
        /// </summary>
        public SorteAppareil AppareilBranch�
        {
            get { return m_appareilBranch�; }
        }
        /// ================================================================
        private CompteurHydro m_objCompteurHydro;
        ///-----------------------------------------------------------------
        /// <summary>
        /// Obtient l'objet Compteur duquel la prise consomme du courant
        /// </summary>
        public CompteurHydro CompteurHydro
        {
            get { return m_objCompteurHydro; }
        }
        #endregion

        #region CONSTRUCTEUR
       
        ///===================================================================================================
        /// <summary>
        /// Initialise une instance de la classe en pr�cisant � quelle Compteur est associ� la prise.
        /// </summary>
        /// <param name="pCompteur">Compteur auquel est associ� la prise</param>
        public PriseDeCourant(CompteurHydro pCompteur)
        {
            if (pCompteur == null)
                throw new ArgumentNullException();
            m_objCompteurHydro = pCompteur;
            m_appareilBranch� = SorteAppareil.Aucun;
        }
        #endregion

        #region M�THODES
        ///===================================================================================================
        /// <summary>
        /// Affecte un appareil � la prise de courant
        /// </summary>
        /// <param name="pAppareil">appareil � brancher</param>
        public void BrancherAppareil(SorteAppareil pAppareil)
        {
            m_appareilBranch� = pAppareil;

        }
        ///===================================================================================================
        /// <summary>
        /// Calcule la consommation pr�vue d'�lectricit� selon le type d'appareil et la dur�e d'utilisation.
        /// </summary>
        /// <param name="pDur�eUtilisation">Nombre de minutes d'utilisation de l'appareil</param>
        /// <returns>le nombre de watts</returns>
        public int ConsommationPr�vue(int pDur�eUtilisation)
        {
            //Clause de garde
            if (pDur�eUtilisation < 0)
                throw new ArgumentOutOfRangeException();

            switch (m_appareilBranch�)
            {
                case SorteAppareil.Aucun:
                    return 0;
                case SorteAppareil.Ordinateur:
                    return pDur�eUtilisation * CONSOMMATION_ORDINATEUR;
                case SorteAppareil.Lampe:
                    return pDur�eUtilisation * CONSOMMATION_LAMPE;
                case SorteAppareil.Rasoir:
                    return pDur�eUtilisation * CONSOMMATION_RASOIR;
                case SorteAppareil.S�choir:
                    return pDur�eUtilisation * CONSOMMATION_S�CHOIR;
                default:
                    return 0;
            }
        }
        ///===================================================================================================
        /// <summary>
        /// Consomme l'�lectricit� sur le compteur avec lequel la prise est jumel�e.
        /// </summary>
        /// <param name="pNbrWatts">nombre de watts � consommer</param>
        public void Consommer(int pNbrWatts)
        {
            if (pNbrWatts < 0)
                throw new ArgumentOutOfRangeException();

            m_objCompteurHydro.Consommer(pNbrWatts);
        }
        #endregion
    }
}
