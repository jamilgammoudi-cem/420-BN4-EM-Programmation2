﻿namespace AppConsommation
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPrise2Qte = new System.Windows.Forms.TextBox();
            this.btnPrise2Consommer = new System.Windows.Forms.Button();
            this.numPrise2Durée = new System.Windows.Forms.NumericUpDown();
            this.cboPrise2Appareil = new System.Windows.Forms.ComboBox();
            this.grpPrise1 = new System.Windows.Forms.GroupBox();
            this.lblPrise1Appareil = new System.Windows.Forms.Label();
            this.lblPrise1Qte = new System.Windows.Forms.Label();
            this.lblPrise1Durée = new System.Windows.Forms.Label();
            this.txtPrise1Qte = new System.Windows.Forms.TextBox();
            this.btnPrise1Consommer = new System.Windows.Forms.Button();
            this.cboPrise1Appareil = new System.Windows.Forms.ComboBox();
            this.numPrise1Durée = new System.Windows.Forms.NumericUpDown();
            this.picPrise1 = new System.Windows.Forms.PictureBox();
            this.grpPrise2 = new System.Windows.Forms.GroupBox();
            this.lblPrise2Appareil = new System.Windows.Forms.Label();
            this.lblPrise2Qte = new System.Windows.Forms.Label();
            this.lblPrise2Durée = new System.Windows.Forms.Label();
            this.picPrise2 = new System.Windows.Forms.PictureBox();
            this.mnuPrincipal = new System.Windows.Forms.MenuStrip();
            this.mnuFichier = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFichierQuitter = new System.Windows.Forms.ToolStripMenuItem();
            this.panPompes = new System.Windows.Forms.Panel();
            this.panConsommation = new System.Windows.Forms.Panel();
            this.lblConsommationCompteur = new System.Windows.Forms.Label();
            this.picCompteur = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panLigne1 = new System.Windows.Forms.Panel();
            this.panLigne2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.numPrise2Durée)).BeginInit();
            this.grpPrise1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPrise1Durée)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPrise1)).BeginInit();
            this.grpPrise2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picPrise2)).BeginInit();
            this.mnuPrincipal.SuspendLayout();
            this.panPompes.SuspendLayout();
            this.panConsommation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picCompteur)).BeginInit();
            this.SuspendLayout();
            // 
            // txtPrise2Qte
            // 
            this.txtPrise2Qte.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrise2Qte.Location = new System.Drawing.Point(143, 88);
            this.txtPrise2Qte.Name = "txtPrise2Qte";
            this.txtPrise2Qte.ReadOnly = true;
            this.txtPrise2Qte.Size = new System.Drawing.Size(61, 20);
            this.txtPrise2Qte.TabIndex = 23;
            this.txtPrise2Qte.Text = "0";
            this.txtPrise2Qte.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnPrise2Consommer
            // 
            this.btnPrise2Consommer.Location = new System.Drawing.Point(99, 117);
            this.btnPrise2Consommer.Name = "btnPrise2Consommer";
            this.btnPrise2Consommer.Size = new System.Drawing.Size(105, 23);
            this.btnPrise2Consommer.TabIndex = 22;
            this.btnPrise2Consommer.Text = "Prise2 consommer";
            this.btnPrise2Consommer.UseVisualStyleBackColor = true;
            this.btnPrise2Consommer.Click += new System.EventHandler(this.btnPrise2Consommer_Click);
            // 
            // numPrise2Durée
            // 
            this.numPrise2Durée.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numPrise2Durée.Location = new System.Drawing.Point(143, 63);
            this.numPrise2Durée.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.numPrise2Durée.Name = "numPrise2Durée";
            this.numPrise2Durée.Size = new System.Drawing.Size(61, 20);
            this.numPrise2Durée.TabIndex = 21;
            this.numPrise2Durée.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numPrise2Durée.ValueChanged += new System.EventHandler(this.numPrise2Durée_ValueChanged);
            // 
            // cboPrise2Appareil
            // 
            this.cboPrise2Appareil.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPrise2Appareil.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboPrise2Appareil.FormattingEnabled = true;
            this.cboPrise2Appareil.Items.AddRange(new object[] {
            "Ordinateur",
            "Lampe",
            "Rasoir",
            "Séchoir"});
            this.cboPrise2Appareil.Location = new System.Drawing.Point(99, 36);
            this.cboPrise2Appareil.Name = "cboPrise2Appareil";
            this.cboPrise2Appareil.Size = new System.Drawing.Size(105, 21);
            this.cboPrise2Appareil.TabIndex = 20;
            this.cboPrise2Appareil.SelectedIndexChanged += new System.EventHandler(this.cboPrise2Appareil_SelectedIndexChanged);
            // 
            // grpPrise1
            // 
            this.grpPrise1.Controls.Add(this.lblPrise1Appareil);
            this.grpPrise1.Controls.Add(this.lblPrise1Qte);
            this.grpPrise1.Controls.Add(this.lblPrise1Durée);
            this.grpPrise1.Controls.Add(this.txtPrise1Qte);
            this.grpPrise1.Controls.Add(this.btnPrise1Consommer);
            this.grpPrise1.Controls.Add(this.cboPrise1Appareil);
            this.grpPrise1.Controls.Add(this.numPrise1Durée);
            this.grpPrise1.Controls.Add(this.picPrise1);
            this.grpPrise1.Location = new System.Drawing.Point(13, 11);
            this.grpPrise1.Name = "grpPrise1";
            this.grpPrise1.Size = new System.Drawing.Size(220, 151);
            this.grpPrise1.TabIndex = 29;
            this.grpPrise1.TabStop = false;
            this.grpPrise1.Text = "Prise de courant #1";
            // 
            // lblPrise1Appareil
            // 
            this.lblPrise1Appareil.AutoSize = true;
            this.lblPrise1Appareil.Location = new System.Drawing.Point(97, 20);
            this.lblPrise1Appareil.Name = "lblPrise1Appareil";
            this.lblPrise1Appareil.Size = new System.Drawing.Size(93, 13);
            this.lblPrise1Appareil.TabIndex = 32;
            this.lblPrise1Appareil.Text = "Appareil branché :";
            // 
            // lblPrise1Qte
            // 
            this.lblPrise1Qte.AutoSize = true;
            this.lblPrise1Qte.Location = new System.Drawing.Point(86, 91);
            this.lblPrise1Qte.Name = "lblPrise1Qte";
            this.lblPrise1Qte.Size = new System.Drawing.Size(53, 13);
            this.lblPrise1Qte.TabIndex = 31;
            this.lblPrise1Qte.Text = "Quantité :";
            // 
            // lblPrise1Durée
            // 
            this.lblPrise1Durée.AutoSize = true;
            this.lblPrise1Durée.Location = new System.Drawing.Point(94, 65);
            this.lblPrise1Durée.Name = "lblPrise1Durée";
            this.lblPrise1Durée.Size = new System.Drawing.Size(42, 13);
            this.lblPrise1Durée.TabIndex = 30;
            this.lblPrise1Durée.Text = "Durée :";
            // 
            // txtPrise1Qte
            // 
            this.txtPrise1Qte.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrise1Qte.Location = new System.Drawing.Point(145, 88);
            this.txtPrise1Qte.Name = "txtPrise1Qte";
            this.txtPrise1Qte.ReadOnly = true;
            this.txtPrise1Qte.Size = new System.Drawing.Size(61, 20);
            this.txtPrise1Qte.TabIndex = 29;
            this.txtPrise1Qte.Text = "0";
            this.txtPrise1Qte.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnPrise1Consommer
            // 
            this.btnPrise1Consommer.Location = new System.Drawing.Point(89, 117);
            this.btnPrise1Consommer.Name = "btnPrise1Consommer";
            this.btnPrise1Consommer.Size = new System.Drawing.Size(117, 23);
            this.btnPrise1Consommer.TabIndex = 28;
            this.btnPrise1Consommer.Text = "Prise1 consommer";
            this.btnPrise1Consommer.UseVisualStyleBackColor = true;
            this.btnPrise1Consommer.Click += new System.EventHandler(this.btnPrise1Consommmer_Click);
            // 
            // cboPrise1Appareil
            // 
            this.cboPrise1Appareil.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPrise1Appareil.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboPrise1Appareil.FormattingEnabled = true;
            this.cboPrise1Appareil.Items.AddRange(new object[] {
            "Ordinateur",
            "Lampe",
            "Rasoir",
            "Séchoir"});
            this.cboPrise1Appareil.Location = new System.Drawing.Point(97, 36);
            this.cboPrise1Appareil.Name = "cboPrise1Appareil";
            this.cboPrise1Appareil.Size = new System.Drawing.Size(109, 21);
            this.cboPrise1Appareil.TabIndex = 26;
            this.cboPrise1Appareil.SelectedIndexChanged += new System.EventHandler(this.cboPrise1Appareil_SelectedIndexChanged);
            // 
            // numPrise1Durée
            // 
            this.numPrise1Durée.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numPrise1Durée.Location = new System.Drawing.Point(145, 62);
            this.numPrise1Durée.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.numPrise1Durée.Name = "numPrise1Durée";
            this.numPrise1Durée.Size = new System.Drawing.Size(61, 20);
            this.numPrise1Durée.TabIndex = 27;
            this.numPrise1Durée.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numPrise1Durée.ValueChanged += new System.EventHandler(this.numPrise1Durée_ValueChanged);
            // 
            // picPrise1
            // 
            this.picPrise1.BackgroundImage = global::AppConsommation.Properties.Resources.Prise;
            this.picPrise1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picPrise1.Location = new System.Drawing.Point(16, 46);
            this.picPrise1.Name = "picPrise1";
            this.picPrise1.Size = new System.Drawing.Size(64, 48);
            this.picPrise1.TabIndex = 25;
            this.picPrise1.TabStop = false;
            // 
            // grpPrise2
            // 
            this.grpPrise2.Controls.Add(this.lblPrise2Appareil);
            this.grpPrise2.Controls.Add(this.lblPrise2Qte);
            this.grpPrise2.Controls.Add(this.lblPrise2Durée);
            this.grpPrise2.Controls.Add(this.picPrise2);
            this.grpPrise2.Controls.Add(this.cboPrise2Appareil);
            this.grpPrise2.Controls.Add(this.txtPrise2Qte);
            this.grpPrise2.Controls.Add(this.numPrise2Durée);
            this.grpPrise2.Controls.Add(this.btnPrise2Consommer);
            this.grpPrise2.Location = new System.Drawing.Point(246, 11);
            this.grpPrise2.Name = "grpPrise2";
            this.grpPrise2.Size = new System.Drawing.Size(220, 151);
            this.grpPrise2.TabIndex = 30;
            this.grpPrise2.TabStop = false;
            this.grpPrise2.Text = "Prise de courant #2";
            // 
            // lblPrise2Appareil
            // 
            this.lblPrise2Appareil.AutoSize = true;
            this.lblPrise2Appareil.Location = new System.Drawing.Point(100, 20);
            this.lblPrise2Appareil.Name = "lblPrise2Appareil";
            this.lblPrise2Appareil.Size = new System.Drawing.Size(93, 13);
            this.lblPrise2Appareil.TabIndex = 33;
            this.lblPrise2Appareil.Text = "Appareil branché :";
            // 
            // lblPrise2Qte
            // 
            this.lblPrise2Qte.AutoSize = true;
            this.lblPrise2Qte.Location = new System.Drawing.Point(86, 91);
            this.lblPrise2Qte.Name = "lblPrise2Qte";
            this.lblPrise2Qte.Size = new System.Drawing.Size(53, 13);
            this.lblPrise2Qte.TabIndex = 32;
            this.lblPrise2Qte.Text = "Quantité :";
            // 
            // lblPrise2Durée
            // 
            this.lblPrise2Durée.AutoSize = true;
            this.lblPrise2Durée.Location = new System.Drawing.Point(96, 66);
            this.lblPrise2Durée.Name = "lblPrise2Durée";
            this.lblPrise2Durée.Size = new System.Drawing.Size(42, 13);
            this.lblPrise2Durée.TabIndex = 31;
            this.lblPrise2Durée.Text = "Durée :";
            // 
            // picPrise2
            // 
            this.picPrise2.BackgroundImage = global::AppConsommation.Properties.Resources.Prise;
            this.picPrise2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picPrise2.Location = new System.Drawing.Point(16, 45);
            this.picPrise2.Name = "picPrise2";
            this.picPrise2.Size = new System.Drawing.Size(64, 49);
            this.picPrise2.TabIndex = 15;
            this.picPrise2.TabStop = false;
            // 
            // mnuPrincipal
            // 
            this.mnuPrincipal.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFichier});
            this.mnuPrincipal.Location = new System.Drawing.Point(0, 0);
            this.mnuPrincipal.Name = "mnuPrincipal";
            this.mnuPrincipal.Size = new System.Drawing.Size(868, 24);
            this.mnuPrincipal.TabIndex = 31;
            this.mnuPrincipal.Text = "menuStrip1";
            // 
            // mnuFichier
            // 
            this.mnuFichier.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFichierQuitter});
            this.mnuFichier.Name = "mnuFichier";
            this.mnuFichier.Size = new System.Drawing.Size(54, 20);
            this.mnuFichier.Text = "&Fichier";
            // 
            // mnuFichierQuitter
            // 
            this.mnuFichierQuitter.Name = "mnuFichierQuitter";
            this.mnuFichierQuitter.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Q)));
            this.mnuFichierQuitter.Size = new System.Drawing.Size(154, 22);
            this.mnuFichierQuitter.Text = "&Quitter";
            this.mnuFichierQuitter.Click += new System.EventHandler(this.mnuFichierQuitter_Click);
            // 
            // panPompes
            // 
            this.panPompes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panPompes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panPompes.Controls.Add(this.grpPrise2);
            this.panPompes.Controls.Add(this.grpPrise1);
            this.panPompes.Location = new System.Drawing.Point(355, 6);
            this.panPompes.Name = "panPompes";
            this.panPompes.Size = new System.Drawing.Size(481, 172);
            this.panPompes.TabIndex = 2;
            // 
            // panConsommation
            // 
            this.panConsommation.BackColor = System.Drawing.Color.Silver;
            this.panConsommation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panConsommation.Controls.Add(this.lblConsommationCompteur);
            this.panConsommation.Controls.Add(this.picCompteur);
            this.panConsommation.Controls.Add(this.panPompes);
            this.panConsommation.Location = new System.Drawing.Point(12, 57);
            this.panConsommation.Name = "panConsommation";
            this.panConsommation.Size = new System.Drawing.Size(845, 186);
            this.panConsommation.TabIndex = 33;
            // 
            // lblConsommationCompteur
            // 
            this.lblConsommationCompteur.BackColor = System.Drawing.Color.Transparent;
            this.lblConsommationCompteur.Font = new System.Drawing.Font("Consolas", 18F);
            this.lblConsommationCompteur.Location = new System.Drawing.Point(82, 89);
            this.lblConsommationCompteur.Name = "lblConsommationCompteur";
            this.lblConsommationCompteur.Size = new System.Drawing.Size(113, 32);
            this.lblConsommationCompteur.TabIndex = 36;
            this.lblConsommationCompteur.Text = "000000";
            this.lblConsommationCompteur.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // picCompteur
            // 
            this.picCompteur.BackgroundImage = global::AppConsommation.Properties.Resources.Compteur;
            this.picCompteur.Location = new System.Drawing.Point(10, 18);
            this.picCompteur.Name = "picCompteur";
            this.picCompteur.Size = new System.Drawing.Size(254, 131);
            this.picCompteur.TabIndex = 35;
            this.picCompteur.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(15, 38);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(184, 13);
            this.label5.TabIndex = 34;
            this.label5.Text = "Consommation électrique totale";
            // 
            // panLigne1
            // 
            this.panLigne1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panLigne1.Location = new System.Drawing.Point(425, 167);
            this.panLigne1.Name = "panLigne1";
            this.panLigne1.Size = new System.Drawing.Size(10, 89);
            this.panLigne1.TabIndex = 31;
            // 
            // panLigne2
            // 
            this.panLigne2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panLigne2.Location = new System.Drawing.Point(658, 166);
            this.panLigne2.Name = "panLigne2";
            this.panLigne2.Size = new System.Drawing.Size(10, 90);
            this.panLigne2.TabIndex = 32;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Location = new System.Drawing.Point(148, 206);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(10, 56);
            this.panel1.TabIndex = 32;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel2.Location = new System.Drawing.Point(149, 252);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(519, 10);
            this.panel2.TabIndex = 33;
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(868, 277);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panLigne2);
            this.Controls.Add(this.panLigne1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panConsommation);
            this.Controls.Add(this.mnuPrincipal);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Définition de classes ";
            ((System.ComponentModel.ISupportInitialize)(this.numPrise2Durée)).EndInit();
            this.grpPrise1.ResumeLayout(false);
            this.grpPrise1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPrise1Durée)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPrise1)).EndInit();
            this.grpPrise2.ResumeLayout(false);
            this.grpPrise2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picPrise2)).EndInit();
            this.mnuPrincipal.ResumeLayout(false);
            this.mnuPrincipal.PerformLayout();
            this.panPompes.ResumeLayout(false);
            this.panConsommation.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picCompteur)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picPrise2;
        private System.Windows.Forms.TextBox txtPrise2Qte;
        private System.Windows.Forms.Button btnPrise2Consommer;
        private System.Windows.Forms.NumericUpDown numPrise2Durée;
        private System.Windows.Forms.ComboBox cboPrise2Appareil;
        private System.Windows.Forms.GroupBox grpPrise1;
        private System.Windows.Forms.TextBox txtPrise1Qte;
        private System.Windows.Forms.Button btnPrise1Consommer;
        private System.Windows.Forms.NumericUpDown numPrise1Durée;
        private System.Windows.Forms.ComboBox cboPrise1Appareil;
        private System.Windows.Forms.PictureBox picPrise1;
        private System.Windows.Forms.GroupBox grpPrise2;
        private System.Windows.Forms.MenuStrip mnuPrincipal;
        private System.Windows.Forms.ToolStripMenuItem mnuFichier;
        private System.Windows.Forms.ToolStripMenuItem mnuFichierQuitter;
        private System.Windows.Forms.Panel panPompes;
        private System.Windows.Forms.Panel panConsommation;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblPrise1Durée;
        private System.Windows.Forms.Label lblPrise2Durée;
        private System.Windows.Forms.Panel panLigne1;
        private System.Windows.Forms.Panel panLigne2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblPrise1Qte;
        private System.Windows.Forms.Label lblPrise2Qte;
        private System.Windows.Forms.PictureBox picCompteur;
        private System.Windows.Forms.Label lblConsommationCompteur;
        private System.Windows.Forms.Label lblPrise1Appareil;
        private System.Windows.Forms.Label lblPrise2Appareil;
    }
}