﻿//===================================================================
// Pour activer une région de tests, enlever les deux // du commentaire
//#define TestsCompilationCompteurHydro
//#define TestsFonctionementCompteurHydro
//#define TestsCompilationPriseDeCourant
//#define TestsFonctionnementPriseDeCourant

using AppConsommation;
using System.Windows.Forms;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.IO;
namespace TestAppStationService
{

    [TestClass()]
    public class Correcteur
    {
        public static string m_version = "Correcteur H21.1.1";

        #region Propriété et Attributs de tests supplémentaires
        private TestContext testContextInstance;

        /// <summary>
        ///Obtient ou définit le contexte de test qui fournit
        ///des informations sur la série de tests active ainsi que ses fonctionnalités.
        ///</summary>
        public TestContext TestContext
        {
            get { return testContextInstance; }
            set { testContextInstance = value; }
        }

        private static int m_totalScore;
        private static int m_maxScore;
        //private static System.Random m_objRandom = new System.Random();
        //Utilisez ClassInitialize pour exécuter du code avant d'exécuter le premier test dans la classe
        [ClassInitialize()]
        public static void MyClassInitialize(TestContext testContext)
        {
            m_totalScore = 0;
            m_maxScore = 0;
        }
        //
        //Utilisez ClassCleanup pour exécuter du code après que tous les tests ont été exécutés dans une classe
        [ClassCleanup()]
        public static void MyClassCleanup()
        {
            StreamWriter ficScore = new StreamWriter("../../../Score.txt");
            ficScore.Write(FrmPrincipal.APP_INFO + "\n");
            ficScore.Write(DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"));
            ficScore.Write("\nRésultat de la correction\nScore : " + m_totalScore + "/" + m_maxScore, Correcteur.m_version, MessageBoxButtons.OK, MessageBoxIcon.Information);
            ficScore.Close();
            //MessageBox.Show("Résultat de la correction\nScore : " + m_totalScore + "/" + m_maxScore, Correcteur.m_version, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        //
        //Utilisez TestInitialize pour exécuter du code avant d'exécuter chaque test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Utilisez TestCleanup pour exécuter du code après que chaque test a été exécuté
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion

        #region Tests classe CompteurHydro
#if TestsCompilationCompteurHydro

        /// <summary>
        ///Test la déclaration de différents éléments de la classe ClsCompteurHydro
        ///Les instructions du test de devraient pas provoquer d'exceptions
        ///Ici on ne test pas le fonctionnement des éléments.
        ///</summary>
        [TestMethod()]
        public void T01_CompilationCompteurHydro()
        {
            m_maxScore += 10;
            CompteurHydro target = null;   
            try
            {           
                //constructeur
                target = new CompteurHydro();

                // Les champs (variables privées) sont inaccessibles donc pas vérifiées ici

                //propriété get
                int varInt = target.ConsommationActuelle;

                // Méthode avec paramètre valide
                target.Consommer(10);
            }
            catch (Exception)
            {
                // Une exception a été levée dans le programme testé mais n'a pas de concéquence dans ce test
            }
            m_totalScore += 10;
        }
#endif
#if TestsFonctionementCompteurHydro        
        /// <summary>
        /// Test pour Constructeur CompteurHydro
        ///</summary>
        [TestMethod()]
        public void T02_CompteurHydroConstructeurEtPropriété()
        {
            m_maxScore += 5;
  
            CompteurHydro target = null;

            try
            {
                target = new CompteurHydro();
            }
            catch (Exception)
            {
                //Une exception a été levée dans le programme testé
                Assert.Fail("Une exception a été levée malgré un appel valide");
            }

            Assert.AreEqual(0, target.ConsommationActuelle, "Erreur d'initialisation de la propriété ConsommationActuelle");
             m_totalScore += 5;
        }

        /// <summary>
        /// Test pour vérifier la méthode Consommer().
        ///</summary>
        [TestMethod()]
        public void T03_CompteurHydroMéthodeConsommer()
        {
            m_maxScore += 5;

            CompteurHydro target = null;
            try
            {
                target = new CompteurHydro();
            }
            catch (Exception)
            {
                Assert.Fail("Une exception a été levée malgré un appel valide");
            }

            Assert.AreEqual(0, target.ConsommationActuelle);

            target.Consommer(10);
            Assert.AreEqual(10, target.ConsommationActuelle);

            target.Consommer(10);
            Assert.AreEqual(20, target.ConsommationActuelle);

            m_totalScore += 5;
        }

         /// <summary>
        /// Test pour vérifier la méthode Consommer() avec paramètre invalide.
        ///</summary>
        [TestMethod()]
        public void T04_CompteurHydroMéthodeConsommerParamInvalide()
        {
            m_maxScore += 5;

            CompteurHydro target = null;
            try
            {
                target = new CompteurHydro();
            }
            catch (Exception)
            {
                Assert.Fail("Une exception a été levée malgré un appel valide");
            }

            //Ce n'est pas une erreur de ne rien consommer
            target.Consommer(0);
            m_totalScore++;

            try
            {
                target.Consommer(-1);//Paramètre négatif pas permis
                Assert.Fail("ArgumentOutOfRangeException attendue");
            }
            catch (ArgumentOutOfRangeException)
            {
                m_totalScore+=4;
            }
            catch (Exception)
            {
                Assert.Fail("ArgumentOutOfRangeException attendue");
            }

            
        }
#endif
        #endregion

        #region Tests classe PriseDeCourant
        //************************************************************************************************
        //************************************************************************************************
#if TestsCompilationPriseDeCourant
        /// <summary>
        /// Test la déclaration de différents éléments de la classe ClsPriseDeCourant
        /// Ici on ne test pas le fonctionnement des éléments.
        ///</summary>
        [TestMethod()]
        public void T05_CompilationPriseDeCourant()
        {
            m_maxScore += 10;

            CompteurHydro objCompteurHydro = new CompteurHydro();
            PriseDeCourant target = null;
            // Test Constructeur------------------
            try
            {
                target = new PriseDeCourant(objCompteurHydro);
                // Vérifie l'accès aux propriétés get
                SorteAppareil enuVar = target.AppareilBranché;
                CompteurHydro objCompteur = target.CompteurHydro;

                // Vérifie l'accès aux méthodes
                target.ConsommationPrévue(10);
                target.Consommer(10);
                target.BrancherAppareil(SorteAppareil.Lampe);
            }
            catch (Exception)
            {
                //Une exception a été levée dans le programme testé mais la compilation passe donc OK
            }
            m_totalScore += 7;
            // Vérifie l'accès et la valeur des constantes
            Assert.AreEqual(330, PriseDeCourant.CONSOMMATION_ORDINATEUR);
            Assert.AreEqual(50, PriseDeCourant.CONSOMMATION_LAMPE);
            Assert.AreEqual(12, PriseDeCourant.CONSOMMATION_RASOIR);
            Assert.AreEqual(1500, PriseDeCourant.CONSOMMATION_SÉCHOIR);
            m_totalScore += 3;
        }
#endif
#if TestsFonctionnementPriseDeCourant
        /// <summary>
        /// Test pour Constructeur PriseDeCourant avec getter et setter
        ///</summary>
        [TestMethod()]
        public void T06_PriseDeCourantConstructeurEtPropriétés()
        {
            m_maxScore += 5;
            CompteurHydro objCompteurHydro = new CompteurHydro();
            // Test Constructeur avec valeur normale ----------------------------------------------------
            PriseDeCourant target = new PriseDeCourant(objCompteurHydro);

            // On test les propriétés avec get
            Assert.AreEqual(SorteAppareil.Aucun, target.AppareilBranché);
            Assert.AreSame(objCompteurHydro, target.CompteurHydro);

            m_totalScore += 5;
        }
        /// <summary>
        ///Test pour Constructeur PriseDeCourant
        ///</summary>
        [TestMethod()]
        public void T07_PriseDeCourantConstructeurException()
        {
            m_maxScore += 5;

            // Test Constructeur avec valeur null
            try
            {
                PriseDeCourant target = new PriseDeCourant(null);
                Assert.Fail("ArgumentNullException attendue");
            }
            catch (ArgumentNullException)
            {

                m_totalScore += 5;
            }
            catch (Exception)
            {
                Assert.Fail("ArgumentNullException attendue");
            }
        }

        /// <summary>
        /// Test pour le fonctionnement de BrancherAppareil à la prise de courant
        ///</summary>
        [TestMethod()]
        public void T08_PriseDeCourantBrancherAppareil()
        {
            m_maxScore += 3;

            CompteurHydro objCompteurHydro = new CompteurHydro();
            PriseDeCourant target = new PriseDeCourant(objCompteurHydro);

            //Attention:Cette boucle est hard codée pour suivre l'ordre du type par énumération
            //si on change l'ordre du premier et/ou du dernier , le test n'est plus valide
            for (SorteAppareil app = SorteAppareil.Aucun; app <= SorteAppareil.Séchoir; app++)
            {
                target.BrancherAppareil(app);
                Assert.AreEqual(app, target.AppareilBranché);
            }
            m_totalScore += 3;
        }

        private int[] tabC = { 0, 330, 50, 12, 1500 };
        /// <summary>
        /// Test la consommation prévue par la prise de courant selon l'appareil branchée
        /// Vérifie tous les appareils et plusieurs temps
        ///</summary>
        [TestMethod()]
        public void T09_PriseDeCourantConsommationPrévue()
        {
            m_maxScore += 10;

            CompteurHydro objCompteurHydro = new CompteurHydro();
            PriseDeCourant target = new PriseDeCourant(objCompteurHydro);

            for (int temps = 0; temps <= 50; temps += 5)
                for (SorteAppareil app = SorteAppareil.Aucun; app <= SorteAppareil.Séchoir; app++)
                {
                    target.BrancherAppareil(app);
                    Assert.AreEqual(tabC[(int)app + 1] * temps, target.ConsommationPrévue(temps));
                }

            m_totalScore += 10;
        }

        /// <summary>
        /// Test la consommation prévue par la prise de courant selon l'appareil branchée
        /// Vérifie l'exception 
        ///</summary>
        [TestMethod()]
        public void T10_PriseDeCourantConsommationPrévueException()
        {
            m_maxScore += 5;

            CompteurHydro objCompteurHydro = new CompteurHydro();
            PriseDeCourant target = new PriseDeCourant(objCompteurHydro);

            target.BrancherAppareil(SorteAppareil.Séchoir);

            try
            {
                target.ConsommationPrévue(-1);
                Assert.Fail("ArgumentOutOfRangeException attendue");
            }
            catch (ArgumentOutOfRangeException)
            {

                m_totalScore += 2;
            }
            catch (Exception)
            {
                Assert.Fail("ArgumentOutOfRangeException attendue");
            }

            m_totalScore += 3;
        }

        /// <summary>
        /// Test pour le fonctionnement des limites de Consommer des watts
        ///</summary>
        [TestMethod()]
        public void T11_PriseDeCourantConsommer()
        {
            m_maxScore += 5;

            CompteurHydro objCompteurHydro = new CompteurHydro();
            PriseDeCourant target = new PriseDeCourant(objCompteurHydro);
            target.BrancherAppareil(SorteAppareil.Séchoir);

            target.Consommer(0);
            Assert.AreEqual(0,target.CompteurHydro.ConsommationActuelle);

            target.Consommer(10);
            Assert.AreEqual(10, target.CompteurHydro.ConsommationActuelle);

            target.Consommer(10);
            Assert.AreEqual(20, target.CompteurHydro.ConsommationActuelle);

            target.Consommer(100);
            Assert.AreEqual(120, target.CompteurHydro.ConsommationActuelle);
            m_totalScore += 5;
        }

        /// <summary>
        ///Test pour le fonctionnement des limites de Consommer des watts
        ///</summary>
        [TestMethod()]
        public void T12_PriseDeCourantConsommerTestException()
        {
            m_maxScore += 2;

            CompteurHydro objCompteurHydro = new CompteurHydro();
            PriseDeCourant target = new PriseDeCourant(objCompteurHydro);
            target.BrancherAppareil(SorteAppareil.Séchoir);

            try
            {
                target.Consommer(-1);
                Assert.Fail("ArgumentOutOfRangeException attendue");
            }
            catch (ArgumentOutOfRangeException)
            {
                //Comportement attendu
                m_totalScore += 2;
            }
            catch (Exception)
            {
                Assert.Fail("ArgumentOutOfRangeException attendue");
            }
        }
#endif
        #endregion
    }
}
