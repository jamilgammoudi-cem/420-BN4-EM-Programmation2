﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Traitement_Liste
{
    /// <summary>
    /// Exercices sur la correction d'erreurs de logique.
    /// </summary>
    public partial class FrmPrincipal : Form
    {
        private List<int> m_colNombres = new List<int>();
        private Random m_objRandom = new Random();
        public const string APP_INFO = "(Démo)";
        public FrmPrincipal()
        {
            InitializeComponent();
            Text += APP_INFO;

            cboJeuxEssais.SelectedIndex = 0;
        }

        #region Traitement de liste (À RÉPARER...)
        /// <summary>
        /// Retire les nombres pairs de la la collection m_colNombres
        /// TODO 01 : Exécuter les jeux d'essais afin de valider le fonctionnement et corriger au besoin
        /// </summary>
        private void RetirerLesNombresPairs()
        {
            for (int index = m_colNombres.Count - 1; index >= 0; index--)
                if (m_colNombres[index] % 2 == 0)
                    m_colNombres.RemoveAt(index);
        }
        /// <summary>
        /// Inverse tous les éléments de la collection m_colNombres
        /// TODO 02 : Exécuter les jeux d'essais afin de valider le fonctionnement et corriger au besoin
        /// </summary>
        private void InverserListe()
        {
            for (int index = 0; index < m_colNombres.Count /2; index++)
            {
                int temp = m_colNombres[index];
                m_colNombres[index] = m_colNombres[m_colNombres.Count - 1 - index];
                m_colNombres[m_colNombres.Count - 1 - index] = temp;
            }
        }
        /// <summary>
        /// Mélange tous les éléments de la collection m_colNombres
        /// TODO 03 : Exécuter les jeux d'essais afin de valider le fonctionnement et corriger au besoin
        /// </summary>
        private void MélangerListe()
        {
            for (int cpt = 0; cpt < m_colNombres.Count * 4; cpt++)
            {
                int index1 = m_objRandom.Next(0, m_colNombres.Count);
                int index2 = m_objRandom.Next(0, m_colNombres.Count);
                int temp = m_colNombres[index1];
                m_colNombres[index1] = m_colNombres[index2];
                m_colNombres[index2] = temp;
            }
        }
        #endregion

        #region NE PAS MODIFIER
        private void JeuEssaisVersListe()
        {
            m_colNombres.Clear();
            string jeuEssaisCourant = cboJeuxEssais.SelectedItem.ToString();
            string[] tabNombreEnChaines = jeuEssaisCourant.Split(',');
            foreach (string chaine in tabNombreEnChaines)
                m_colNombres.Add(int.Parse(chaine));
        }

        private string ObtenirListeÀAfficher()
        {
            string chaine = "";

            foreach (int nombre in m_colNombres)
                chaine += nombre + ",";

            if (chaine.Length > 0)
                chaine = chaine.Substring(0, chaine.Length - 1);

            return chaine;
        }
        private void BtnRetirerPairs_Click(object sender, EventArgs e)
        {
            JeuEssaisVersListe();
            RetirerLesNombresPairs();
            txtListeSansPair.Text = ObtenirListeÀAfficher();
        }

        private void BtnInverserListe_Click(object sender, EventArgs e)
        {
            JeuEssaisVersListe();
            InverserListe();
            txtListeInverse.Text = ObtenirListeÀAfficher();
        }

        private void BtnMélangerListe_Click(object sender, EventArgs e)
        {
            JeuEssaisVersListe();
            MélangerListe();
            txtListeMélangée.Text = ObtenirListeÀAfficher();
        }
        #endregion
    } 
}
