﻿namespace Traitement_Liste
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnRetirerPairs = new System.Windows.Forms.Button();
            this.txtListeInverse = new System.Windows.Forms.TextBox();
            this.btnMélangerListe = new System.Windows.Forms.Button();
            this.btnInverserListe = new System.Windows.Forms.Button();
            this.txtListeSansPair = new System.Windows.Forms.TextBox();
            this.txtListeMélangée = new System.Windows.Forms.TextBox();
            this.lblJeuEssais = new System.Windows.Forms.Label();
            this.cboJeuxEssais = new System.Windows.Forms.ComboBox();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnRetirerPairs);
            this.groupBox2.Controls.Add(this.txtListeInverse);
            this.groupBox2.Controls.Add(this.btnMélangerListe);
            this.groupBox2.Controls.Add(this.btnInverserListe);
            this.groupBox2.Controls.Add(this.txtListeSansPair);
            this.groupBox2.Controls.Add(this.txtListeMélangée);
            this.groupBox2.Location = new System.Drawing.Point(12, 100);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(558, 267);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Traitement de liste";
            // 
            // btnRetirerPairs
            // 
            this.btnRetirerPairs.Location = new System.Drawing.Point(19, 34);
            this.btnRetirerPairs.Name = "btnRetirerPairs";
            this.btnRetirerPairs.Size = new System.Drawing.Size(261, 23);
            this.btnRetirerPairs.TabIndex = 7;
            this.btnRetirerPairs.Text = "Retirer les nombre pairs de la liste";
            this.btnRetirerPairs.UseVisualStyleBackColor = true;
            this.btnRetirerPairs.Click += new System.EventHandler(this.BtnRetirerPairs_Click);
            // 
            // txtListeInverse
            // 
            this.txtListeInverse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtListeInverse.Location = new System.Drawing.Point(19, 140);
            this.txtListeInverse.Name = "txtListeInverse";
            this.txtListeInverse.ReadOnly = true;
            this.txtListeInverse.Size = new System.Drawing.Size(518, 26);
            this.txtListeInverse.TabIndex = 8;
            // 
            // btnMélangerListe
            // 
            this.btnMélangerListe.Location = new System.Drawing.Point(19, 190);
            this.btnMélangerListe.Name = "btnMélangerListe";
            this.btnMélangerListe.Size = new System.Drawing.Size(261, 23);
            this.btnMélangerListe.TabIndex = 11;
            this.btnMélangerListe.Text = "Mélanger Liste";
            this.btnMélangerListe.UseVisualStyleBackColor = true;
            this.btnMélangerListe.Click += new System.EventHandler(this.BtnMélangerListe_Click);
            // 
            // btnInverserListe
            // 
            this.btnInverserListe.Location = new System.Drawing.Point(19, 111);
            this.btnInverserListe.Name = "btnInverserListe";
            this.btnInverserListe.Size = new System.Drawing.Size(261, 23);
            this.btnInverserListe.TabIndex = 9;
            this.btnInverserListe.Text = "Inverser la liste";
            this.btnInverserListe.UseVisualStyleBackColor = true;
            this.btnInverserListe.Click += new System.EventHandler(this.BtnInverserListe_Click);
            // 
            // txtListeSansPair
            // 
            this.txtListeSansPair.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtListeSansPair.Location = new System.Drawing.Point(19, 63);
            this.txtListeSansPair.Name = "txtListeSansPair";
            this.txtListeSansPair.ReadOnly = true;
            this.txtListeSansPair.Size = new System.Drawing.Size(518, 26);
            this.txtListeSansPair.TabIndex = 5;
            // 
            // txtListeMélangée
            // 
            this.txtListeMélangée.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtListeMélangée.Location = new System.Drawing.Point(19, 219);
            this.txtListeMélangée.Name = "txtListeMélangée";
            this.txtListeMélangée.ReadOnly = true;
            this.txtListeMélangée.Size = new System.Drawing.Size(518, 26);
            this.txtListeMélangée.TabIndex = 10;
            // 
            // lblJeuEssais
            // 
            this.lblJeuEssais.AutoSize = true;
            this.lblJeuEssais.Location = new System.Drawing.Point(28, 28);
            this.lblJeuEssais.Name = "lblJeuEssais";
            this.lblJeuEssais.Size = new System.Drawing.Size(70, 13);
            this.lblJeuEssais.TabIndex = 6;
            this.lblJeuEssais.Text = "Jeu d\'essais :";
            // 
            // cboJeuxEssais
            // 
            this.cboJeuxEssais.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboJeuxEssais.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboJeuxEssais.FormattingEnabled = true;
            this.cboJeuxEssais.Items.AddRange(new object[] {
            "10,15,20,25,30,35,40",
            "55,33,77,66,88,99,22,44,11",
            "10,20,30",
            "1,2"});
            this.cboJeuxEssais.Location = new System.Drawing.Point(31, 44);
            this.cboJeuxEssais.Name = "cboJeuxEssais";
            this.cboJeuxEssais.Size = new System.Drawing.Size(518, 28);
            this.cboJeuxEssais.TabIndex = 4;
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(591, 384);
            this.Controls.Add(this.lblJeuEssais);
            this.Controls.Add(this.cboJeuxEssais);
            this.Controls.Add(this.groupBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Traitement Liste ";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cboJeuxEssais;
        private System.Windows.Forms.Button btnRetirerPairs;
        private System.Windows.Forms.Label lblJeuEssais;
        private System.Windows.Forms.TextBox txtListeSansPair;
        private System.Windows.Forms.Button btnInverserListe;
        private System.Windows.Forms.TextBox txtListeInverse;
        private System.Windows.Forms.Button btnMélangerListe;
        private System.Windows.Forms.TextBox txtListeMélangée;
    }
}

