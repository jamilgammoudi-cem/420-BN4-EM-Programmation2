using System;

namespace Thermostat
{
    /// ------------------------------------------------------------------------------------
    /// <summary>
    /// Repr�sente un thermostat �lectronique contr�lant la temp�rature d'une 
    /// plinthe de chauffage,ce qui correspond g�n�ralement � une pi�ce d'un �tablissement.
    /// </summary>
    /// ------------------------------------------------------------------------------------
    public class Thermostat
    {
        #region Constantes
        /// ================================================================================
        /// <summary>
        /// Temp�rature minimale autoris�e par un Thermostat
        /// </summary>
        public const double MIN_TEMPERATURE = 5.0;
       
        /// ================================================================================
        /// <summary>
        /// Temp�rature maximale autoris�e par un Thermostat
        /// </summary>
        public const double MAX_TEMPERATURE = 35.0;
       
        /// ================================================================================
        /// <summary>
        /// Temp�rature initiale d'un Thermostat
        /// </summary>
        public const double TEMPERATURE_D�FAUT = 20.0;

        #endregion

        #region CHAMPS (variables membre) ET PROPRI�T�S
        ///==================================================================================
        private double m_temperature;
        /// ---------------------------------------------------------------------------------
        /// <summary>
        ///    Obtient la temp�rature actuelle du thermostat
        /// </summary>
        public double Temperature
        {
            get { return m_temperature; }

        }
        #endregion

        #region CONSTRUCTEUR
        ///======================================================================================
        /// <summary>
        ///   Initialise une nouvelle instance de la classe Thermostat � la temp�rature initiale. 
        /// </summary>
        ///--------------------------------------------------------------------------------------
        public Thermostat()
        {
            m_temperature = TEMPERATURE_D�FAUT;
        }

        #endregion

        #region M�THODES
        ///==================================================================================
        /// <summary>
        ///   Augmente la temp�rature d'un degr�.
        /// </summary>
        /// ---------------------------------------------------------------------------------
        public void AugmenterTemperature()
        {
            m_temperature++;

            if (m_temperature > MAX_TEMPERATURE)
                throw new ArgumentOutOfRangeException();
        }
        ///==================================================================================
        /// <summary>
        ///   Diminue la temp�rature d'un degr�.
        /// </summary>
        /// ---------------------------------------------------------------------------------
        public void DiminuerTemperature()
        {
            m_temperature--;

            if (m_temperature < MIN_TEMPERATURE)
                throw new ArgumentOutOfRangeException();
        }

        #endregion
    }
}
