﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;

namespace ListeEtFichier
{
    public partial class FrmPrincipal : Form
    {
        private const string APP_INFO = "(Matériel)";
        private const string LISTE_DES_PERSONNES = "Fichiers\\ListeDesPersonnes.txt";

        private List<Personne> m_colPersonnes = new List<Personne>();
        private bool m_listeEstModifiée = false;

        //=======================================================================================================
        public FrmPrincipal()
        {
            InitializeComponent();

            Text += APP_INFO;

            ChargerPersonnes(LISTE_DES_PERSONNES);
        }
        //======================================================================================================
        private void ChargerPersonnes(string pNomDuFichier)
        {
            if ( ! File.Exists(pNomDuFichier))
            {
                MessageBox.Show("Impossible de trouver la liste des personnes", 
                                Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //--------------------------------------------------------------------------------
            m_colPersonnes.Clear();

            //---- lecture dans le fichier ----------------------------------------------------
            StreamReader objStreamReader = new StreamReader(pNomDuFichier);
            while (!objStreamReader.EndOfStream)
            {
                string uneLigneLue = objStreamReader.ReadLine();
                string[] tabInfos = uneLigneLue.Split(',');
                Personne unePersonne = new Personne(tabInfos[0], tabInfos[1]);
                m_colPersonnes.Add(unePersonne);
            }
            objStreamReader.Close();

            // --- affiche la première personne de la liste
            Personne personne = m_colPersonnes[0];
            mtxNAS.Text = personne.Nas;
            txtNom.Text = personne.Nom;

        }
        //-----------------------------------------------------------------------------------
        private bool NASExiste(string pNAS)
        {
            foreach (Personne personne in m_colPersonnes)
            {
                if (personne.Nas == pNAS)
                {
                    return true;
                }
            }

            return false;
        }
        ///-----------------------------------------------------------------------------------
        private void btnAjouter_Click(object sender, EventArgs e)
        {
            string nas = mtxNAS.Text;
            string nom = txtNom.Text;

            //validation très simple, ne réflecte pas la réalité!
            if (nas.Length < 9 || nom.Length < 3)
            {
                return;
            }
            
            Personne unePersonne = new Personne(nas, nom);

            if (NASExiste(nas))
            {
                MessageBox.Show("Impossible d'ajouter cette personne car ce NAS existe déjà dans la liste ",
                                Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                m_colPersonnes.Add(unePersonne);

                m_listeEstModifiée = true;

                MessageBox.Show(m_colPersonnes[m_colPersonnes.Count - 1].Nom + " a été ajouté.", "Liste générique");
                txtNom.Clear();
                mtxNAS.Clear();
            }
        }
        /// ----------------------------------------------------------------------------------
        private int IndexPersonneSelonNas(string pNasRecherché)
        {
            for (int index = 0; index < m_colPersonnes.Count; index++)
            {
                if (m_colPersonnes[index].Nas == pNasRecherché)
                {
                    return index;  
                }
            }
            return -1;

        }
        ///-----------------------------------------------------------------------------------
        private void btnSupprimer_Click(object sender, EventArgs e)
        {
            string nasRecherché = mtxNAS.Text;

            int index = IndexPersonneSelonNas(nasRecherché);

            if (index != -1)
            {  
                MessageBox.Show(m_colPersonnes[index].Nom + " a été supprimé.", "Liste générique");
                m_colPersonnes.RemoveAt(index);
               
                m_listeEstModifiée = true;
                
                txtNom.Clear();
                mtxNAS.Clear();
            }
            else
                MessageBox.Show("Impossible de trouver le NAS : " + nasRecherché,
                                Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        ///--------------------------------------------------------------------------------------
        private void btnRechercher_Click(object sender, EventArgs e)
        {
            string nasRecherché = mtxNAS.Text;

            int index = IndexPersonneSelonNas(nasRecherché);

            if (index != -1)
            {
                txtNom.Text = m_colPersonnes[index].Nom;
            }
            else
            {
                txtNom.Clear();
                MessageBox.Show("Impossible de trouver le NAS : " + nasRecherché,
                                Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
         }
        //=================================================================================================
        private void SauvegarderListe()
        {
            StreamWriter objStreamWriter = new StreamWriter(LISTE_DES_PERSONNES);
            foreach (Personne objPersonne in m_colPersonnes)
            {
                objStreamWriter.Write(objPersonne.Nas + ",");
                objStreamWriter.WriteLine(objPersonne.Nom);
            }
            objStreamWriter.Close();
        }
        //=================================================================================================
        private void mnuFichierQuitter_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //==============================================================================================================
        private void FrmPrincipal_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (m_listeEstModifiée)
            {
                SauvegarderListe();
            }
        }
        //==============================================================================================================
        private void btnEffacerAffichage_Click(object sender, EventArgs e)
        {
            txtNom.Clear();
            mtxNAS.Clear();
        }
        //==============================================================================================================
        private void btnQuitter_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
