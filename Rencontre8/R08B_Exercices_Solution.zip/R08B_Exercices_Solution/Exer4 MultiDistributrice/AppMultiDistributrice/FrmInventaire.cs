﻿using System;
using System.Windows.Forms;

namespace AppMultiDistributrice
{
    public partial class FrmInventaire : Form
    {
        //-------------------------------------

        public FrmInventaire(string pInfosMachines)
        {
            InitializeComponent();
            //----------------------
            lstMachines.Items.Clear();

            string[] tabElements = pInfosMachines.Split('|');
            foreach (string uneMachine in tabElements)
            {
                lstMachines.Items.Add(uneMachine);
            }
        }
        //======================================================
        private void btnFermer_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
