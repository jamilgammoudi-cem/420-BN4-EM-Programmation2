﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace AppMultiDistributrice
{
    public partial class FrmListeMachines : Form
    {
        private List<Distributrice> m_colDistributrices;
        //-------------------------------------

        public FrmListeMachines(List<Distributrice> pcolDistributrice)
        {
            InitializeComponent();
            //----------------------
            m_colDistributrices = pcolDistributrice;
            AfficherInformations();
        }
        /// ----------------------------------------------------------------------------------------------------
        /// <summary>
        /// Affiche dans le sous-formulaire l'emplacement et la quantité totale de cannettes
        /// pour chacune des machines de la collection.
        /// </summary>
        /// ----------------------------------------------------------------------------------------------------
        private void AfficherInformations()
        {
            lstMachines.Items.Clear();
            int grandTotal = 0;
            foreach (Distributrice uneMachine in m_colDistributrices)
            {
                if (!chkMachinesPleines.Checked || uneMachine.EstPleine)
                {
                    lstMachines.Items.Add(uneMachine.Emplacement + " ----> " + uneMachine.QuantiteTotale.ToString());
                    grandTotal += uneMachine.QuantiteTotale;
                }
            }
            numTotalCannettes.Value = grandTotal;
        }
        //===================================================================================================
        private void btnFermer_Click(object sender, EventArgs e)
        {
            Close();
        }
        //===================================================================================================
        private void chkMachinesPleines_CheckedChanged(object sender, EventArgs e)
        {
            AfficherInformations();
        }
    }
}
