using System;

namespace ApplicationDistributrice
{
    /// ====================================================================================
    /// <summary>
    ///	�num�ration de diff�rents breuvages.
    /// </summary>
    /// ------------------------------------------------------------------------------------
    public enum SorteBreuvage { Coke = 0, SevenUp, JusDePommes, TheGlace };
    
    /// ===========================================================================
    /// <summary>
    ///  Mod�lise une machine distributrice offrant 4 breuvages diff�rents. 
    ///  On peut recharger la machine et obtenir des informations sur les quantit�s
    ///  de canettes restant dans la machine.
    /// </summary>
    /// ---------------------------------------------------------------------------
    public class Distributrice
    {
        #region CONSTANTE
        /// -------------------------------------------------------------
        /// <summary>
        /// Repr�sente la quantit� maximale d'un breuvage
        /// </summary>
        /// -------------------------------------------------------------
        private const int MAX_QUANTITE = 5;
        /// -------------------------------------------------------------
        /// <summary>
        /// Repr�sente le nombre de sortes de breuvages dans une machine
        /// </summary>
        private const int NB_SORTES_BREUVAGES = 4;
        #endregion

        #region CHAMPS et PROPRI�T�S
        /// -------------------------------------------------------------
        /// <summary>
        /// Tableau contenant la quantit� de chaque breuvage dans une machine
        /// </summary>
        private int[] m_tabQuantit�s = new int[NB_SORTES_BREUVAGES];

        //========================================================================================
        /// <summary>
        ///   Obtient si oui ou non la machine est vide.
        /// </summary>
        /// -------------------------------------------------------------------------------------
        public bool EstVide
        {
            get
            {
                foreach (int quantit� in m_tabQuantit�s)
                {
                    if (quantit� != 0)
                    {
                        return false;
                    }
                }
                return true;
            }
        }
        #endregion

        #region CONTRUCTEURS
        ///==============================================================
        /// <summary>
        ///  Initialise une nouvelle instance de la classe Machine 
        ///  avec un nombre maximum de canettes pour chacun des breuvages. 
        /// </summary>
        /// --------------------------------------------------------------
        public Distributrice()
        {
            Recharger();
        }
        ///==============================================================
        /// <summary>
        ///  Initialise une nouvelle instance de la classe Machine 
        ///  avec les nombres de canettes sp�cifi�s pour chacun des breuvage. 
        /// </summary>
        /// --------------------------------------------------------------
        public Distributrice(int pNbCoke, int pNb7Up, int pNbJusDePommme, int pNbTheGlace)
        {
            if (pNbCoke < 0 || pNbCoke > MAX_QUANTITE)
                throw new ArgumentOutOfRangeException("pNbCoke", pNbCoke, "doit �tre compris entre 0 et " + MAX_QUANTITE);

            if (pNb7Up < 0 || pNb7Up > MAX_QUANTITE)
                throw new ArgumentOutOfRangeException("pNb7Up", pNb7Up, "doit �tre compris entre 0 et " + MAX_QUANTITE);

            if (pNbJusDePommme < 0 || pNbJusDePommme > MAX_QUANTITE)
                throw new ArgumentOutOfRangeException("pNbJusDePommme", pNbJusDePommme, "doit �tre compris entre 0 et " + MAX_QUANTITE);

            if (pNbTheGlace < 0 || pNbTheGlace > MAX_QUANTITE)
                throw new ArgumentOutOfRangeException("pNbTheGlace", pNbTheGlace, "doit �tre compris entre 0 et " + MAX_QUANTITE);

            m_tabQuantit�s[(int)SorteBreuvage.Coke] = pNbCoke;
            m_tabQuantit�s[(int)SorteBreuvage.SevenUp] = pNb7Up;
            m_tabQuantit�s[(int)SorteBreuvage.JusDePommes] = pNbJusDePommme;
            m_tabQuantit�s[(int)SorteBreuvage.TheGlace] = pNbTheGlace;
        }
        #endregion

        #region M�THODES
        ///====================================================================================
        /// <summary>
        /// Recharge la machine en r�-initialisant les quantit�s de chaque breuvage au maximum.
        /// </summary>
        /// -----------------------------------------------------------------------------------
        public void Recharger()
        {
            for (int index = 0; index < m_tabQuantit�s.Length; index++)
            {
                m_tabQuantit�s[index] = MAX_QUANTITE;
            }
        }
        ///======================================================================
        /// <summary>
        ///  Obtient la quantit� de cannettes disponible du breuvage sp�cifi�.
        /// </summary>
        /// <param name="pBreuvage">breuvage � v�rifier</param>
        /// <returns>quantit� de canettes</returns>
        /// ---------------------------------------------------------------------
        public int Quantite(SorteBreuvage pBreuvage)
        {
            return m_tabQuantit�s[(int)pBreuvage];
        }
        //================================================================================
        /// <summary>
        ///  Ejecte le breuvage sp�cifi� , c'est-�-dire d�cr�mente le nombre de canettes
        ///  du breuvage sp�cifi� s'il en reste.
        /// </summary>
        /// <param name="pBreuvage">breuvage � modifier</param>
        /// ------------------------------------------------------------------------------
        public void Ejecter(SorteBreuvage pBreuvage)
        {
            if (!EstDisponible(pBreuvage))
            {
                throw new InvalidOperationException();
            }

            m_tabQuantit�s[(int)pBreuvage]--;
        }
         //=======================================================
        /// <summary>
        ///  Obtient si oui ou non s'il reste du breuvage sp�cifi�
        /// </summary>
        /// <param name="pBreuvage">breuvage � v�rifier</param>
        /// <returns>disponible ou non </returns>
        /// -----------------------------------------------------
        public bool EstDisponible(SorteBreuvage pBreuvage)
        {
            return m_tabQuantit�s[(int)pBreuvage] > 0;
        }
    }
    #endregion
}
