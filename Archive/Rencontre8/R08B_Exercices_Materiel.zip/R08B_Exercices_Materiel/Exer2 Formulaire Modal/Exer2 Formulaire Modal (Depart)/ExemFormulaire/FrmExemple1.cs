﻿using System;
using System.Windows.Forms;

namespace ExemFormulaire
{
    public partial class FrmExemple1 : Form
    {
        public FrmExemple1()
        {
            InitializeComponent();
        }

        private void btnFermer_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
