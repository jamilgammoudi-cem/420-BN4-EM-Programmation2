﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace GroupePersonnes
{
    /// <summary>
    /// Un formulaire qui affiche une sous-liste de personnes dont le nom débute par une certaine chaîne. 
    /// </summary>
    public partial class FrmListePartielle : Form
    {
       
        private List<Personne> m_colPersonnes;

        #region TODO 06 : Modifier le constructeur
        //---------------------------------------------------------------------------------------
        
        public FrmListePartielle(List<Personne> pListe)
        {
            InitializeComponent();
            this.Text += FrmPrincipal.APP_INFO;
            m_colPersonnes = pListe;
            //-----------------------------------------------------------------------------------

            // TODO 06  : Affichez le contenu de la collection m_colPersonnes lstPartielle
            //            Utilisez la tabulation "\t"  pour séparer les informations d'une personne
            // À COMPLÉTER...


        }
        #endregion

        #region TODO 07 : Compléter le gestionnaire d'événement TextChanged
        //=============================================================================
        // TODO 07 : Parcourir la collection m_colPersonnes et afficher dans le ListBox seulement les personnes dont le nom débute
        // par les caractères saisies dans la zone txtCritère.
        // N.B. Utiliser la méthode StartsWith qui fonctionne comme suit :
        // mot1.StartsWith(mot2) retourne true si le mot1 débute par mot2. Sinon, elle retourne false
        private void txtCritère_TextChanged(object sender, EventArgs e)
        {
            // À COMPLÉTER...
           
        }
        #endregion

        private void btnFermer_Click(object sender, EventArgs e)
        {
            Close();
        }

    }
}
