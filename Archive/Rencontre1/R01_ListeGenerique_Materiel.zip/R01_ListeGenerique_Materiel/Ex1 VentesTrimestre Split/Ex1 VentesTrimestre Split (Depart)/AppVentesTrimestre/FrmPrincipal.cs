﻿using System;
using System.Windows.Forms;
using System.IO;
using VisualArrays;

namespace AppVentesTrimestre
{
    /// <summary>
    /// Manipulation de tableaux à 2D
    ///              d'un fichier en lecture
    ///              d'un fichier en écriture
    /// </summary>
    // TODO 00 : Le programme ne compile pas ! Pourquoi ! 
    public partial class FrmPrincipal : Form
    {
        public const string APP_INFO = "(Matériel)";

        // tableau pré-initialisé à 1D des mois
        private string[] m_tabMois = { "Janvier", "Février", "Mars" };

        // tableau pré-initialisé à 1D des villes
        private string[] m_tabVilles = { "Boucherville", "Laval", "Longueuil", "Montréal" };


        //---------------------------------------------------------------------------------
        public FrmPrincipal()
        {
            InitializeComponent();
            Text += APP_INFO;
            PréparerLesEntêtesDesGrilles();
        }

        #region Préparation des grilles
        //---------------------------------------------------------------------------------
        /// <summary>
        /// Place, par programmation, les en-têtes des rangées et des colonnes
        /// vdaVentes.RowHeaderArray[index]
        /// vdaVentes.ColumnHeaderArray[index]
        /// </summary>
        private void PréparerLesEntêtesDesGrilles()
        {
            for (int index = 0; index < vdaVentes.RowCount; index++)
            {
                vdaVentes.RowHeaderArray[index] = m_tabVilles[index];
            }

            for (int index = 0; index < vdaVentes.ColumnCount; index++)
            {
                vdaVentes.ColumnHeaderArray[index] = m_tabMois[index];
            }

            vdaTotauxParMois.RowHeaderArray[0] = "Totaux / Mois";
            vdaTotauxVilles.ColumnHeaderArray[0] = "Totaux / Villes";
        }
        #endregion

        #region Options du menu Fichier
        //---------------------------------------------------------------------------------
        /// <summary>
        /// Vide le contenu de la grille des ventes
        /// </summary>		
        private void mnuFichierNouveau_Click(object sender, EventArgs e)
        {
            // TODO 01 : Vide le contenu de la grille des ventes
        }

        //====================================================================================
        /// <summary>
        ///  Enregistre le contenu de vdaVentes dans le fichier "Données.txt" 
        /// </summary>
        private void mnuFichierEnregistrer_Click(object sender, EventArgs e)
        {
            // TODO 05 : Enregistre le contenu de vdaVentes dans le fichier "Données.txt"

        }

        /// <summary>
        /// Charge le contenu du fichier "Données.txt" dans vdaVentes 
        /// </summary>
        private void mnuFichierCharger_Click(object sender, EventArgs e)
        {
            // TODO 06 : Charger le contenu du fichier "Données.txt" dans vdaVentes 

        }
        //---------------------------------------------------------------------------------
        private void mnuFichierQuitter_Click(object sender, EventArgs e)
        {
            Close();
        }
        #endregion

        #region Méthodes pour calculer les sommes
        //---------------------------------------------------------------------------------


        // TODO 02 : Définir une méthode appelée SommeDeLaColonne qui : 
        // - reçoit/accepte en paramètre un entier pColonne
        // - Clacule la somme des valeurs décimales de la colonne pColonne de la grille vdaVentes
        // - Retourne la somme calculée





        /// 

        //---------------------------------------------------------------------------------
        // TODO 03 : Définir une méthode appelée SommeDeLaRangee qui : 
        // - reçoit/accepte en paramètre un entier pRangee
        // - Clacule la somme des valeurs décimales de la rangée pRangee de la grille vdaVentes
        // - Retourne la somme calculée
         


        //---------------------------------------------------------------------------------
        // TODO 04 : Définir une méthode appelée GrandTotal qui : 
        // - ne reçoit/n'accepte aucun paramètre
        // - Clacule la somme de toutes les valeurs décimales de la grille vdaVentes
        // - Retourne la somme calculée
    





        #endregion

        #region Événement ValueChanged
        //---------------------------------------------------------------------------------
        // Mise à jour des totaux.
        // Deux origines possibles du ValueChanged:
        // Premier cas:  un clic (par l'utilisateur) dans une cellule pour modifier le contenu
        //               dans ce cas le paramètre e.Address aura une valeur autre que Address.Empty
        //               on mettra à jour seulement les totaux affectés par cette cellule.
        // Deuxième cas: un changement de valeur  par programmation par le programmeur
        private void vdaVentes_ValueChanged(object sender, ValueChangedEventArgs e)
        {
            if (e.Address != Address.Empty) //Valeur changée par un clic sur la cellule
            {
                vdaTotauxParMois[e.Column] = SommeDeLaColonne(e.Column);
                vdaTotauxVilles[e.Row] = SommeDeLaRangee(e.Row);
            }
            else // Valeur changée par programmation,
                // dans ce cas il faut tout mettre à jour
            {
                for (int rangée = 0; rangée < vdaVentes.RowCount; rangée++)
                {
                    vdaTotauxVilles[rangée] = SommeDeLaRangee(rangée);
                }
                for (int colonne = 0; colonne < vdaVentes.ColumnCount; colonne++)
                {
                    vdaTotauxParMois[colonne] = SommeDeLaColonne(colonne);
                }
            }

            vsdGrandTotal.Value = GrandTotal();
        }
        #endregion

    }
}
