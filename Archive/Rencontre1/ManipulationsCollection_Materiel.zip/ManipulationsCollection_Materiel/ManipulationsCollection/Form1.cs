﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ManipulationsCollection
{
    public partial class Form1 : Form
    {

        Random objRandom = new Random();
        List<int> m_colNombres = new List<int>();
        public Form1()
        {
            InitializeComponent();
        }
        #region Gestion du formulaire
        private void btnRemplir_Click(object sender, EventArgs e)
        {
            lstNombresFiltree.Items.Clear();
            // TODO 02 : Appeler la méthode RemplirAleatoirementUneCollection pour remplir la collection m_colNombres
            // Compléter ici



            // TODO 04 : Appeler la méthode AfficherCollectionDansListBox pour afficher le contenu de
            // la collection m_colNombres dans le ListBox lstNombres
            // Compléter ici



            
            // NE PAS MODIFIER
            AfficherStats();
        }

       

        private void btnFiltrer1_Click(object sender, EventArgs e)
        {

            // TODO 14 : Déclarer une collection d'entiers appelée colTemp
            // Compléter ici



            // TODO 15 : Appeler la méthode FiltrerSelonSeuilMinimalV1 pour filtrer la collection m_colNombres
            // dans la collection colTemp. Le seuil minimal est 50.
            // Compléter ici
            



            // TODO 16 : Appeler la méthode AfficherCollectionDansListBox pour afficher le contenu de la
            // collection colTemp dans le listBox lstNombresFiltree
            // Compléter ici
           


        }

        private void btnFiltrer2_Click(object sender, EventArgs e)
        {

            // TODO 18 : Appeler la méthode FiltrerSelonSeuilMinimalV2 pour filtrer la collection m_colNombres. Le seuil minimal est 50
            // Compléter ici




            // TODO 19 : Appeler la méthode AfficherCollectionDansListBox pour afficher le contenu de la
            // collection m_colNombres dans le listBox lstNombres
            // Compléter ici



            // TODO 20 : Appeler la méthode AfficherCollectionDansListBox pour afficher le contenu de la
            // collection m_colNombres dans le listBox lstNombresFiltree
            // Compléter ici

            
        }

        #region Afficher les statisques (NE PAS MODIFIER)
        /// <summary>
        /// Afficher les statistiques
        /// </summary>
        private void AfficherStats()
        {

            // TODO 06 : Décommenter la ligne de code et lancer l'application pour tester
            //txtTotal.Text = Total(m_colNombres).ToString();

            // TODO 08 : Décommenter la ligne de code et lancer l'application pour tester
            //txtMoyenne.Text = Moyenne(m_colNombres).ToString("F2");

            // TODO 10 : Décommenter la ligne de code et lancer l'application pour tester
            //txtValeurMaximale.Text = ValeurMaximale(m_colNombres).ToString();

            // TODO 12 : Décommenter la ligne de code et lancer l'application pour tester
            //txtNbValeursSupSeuil.Text = NombreDeValeursSupSeuil(m_colNombres, 50).ToString();
        }
        #endregion


        #endregion


        #region Méthodes pour remplir une collection et afficher son contenu dans un ListBox



        // TODO 01 : Définir une méthode appelée RemplirAleatoirementUneCollection qui :
        // - Reçoit/accepte en paramètre une collection d'entiers (vide)
        // - Remplit la collection par 10 entiers générés aléatoirement entre 0 et 100
        // Utiliser objRandom.Next(100) pour générer un entier entre 0 et 100
        // Compléter ici




        // TODO 03 : Définir une méthode appelée AfficherCollectionDansListBox qui :
        // - Reçoit/accepte en paramètre une collection d'entiers et un ListBox
        // - Affiche les éléments de la collection dans le ListBox
        // Compléter ici


        #endregion



        #region  Méthodes de calcul des statistiques

        // TODO 05 : Définir une méthode appelée Total qui :
        // - Reçoit/accepte en paramètre une collection d'entiers 
        // - Calcule et retourne la somme des éléments de la collection
        // Compléter ici


        // TODO 07 : Définir une méthode appelée Moyenne qui :
        // - Reçoit/accepte en paramètre une collection d'entiers 
        // - Calcule et retourne la moyenne (en double) des éléments de la collection
        // Vous pouvez utiliser la méthode Total définie plus haut!
        // Compléter ici



        // TODO 09 : Définir une méthode appelée ValeurMaximale qui :
        // - Reçoit/accepte en paramètre une collection d'entiers 
        // - Calcule et retourne la valeur maximale dans la collection
        // Compléter ici



        // TODO 11 : Définir une méthode appelée NombreDeValeursSupSeuil qui :
        // - Reçoit/accepte en paramètre une collection d'entiers et un entier pSeuilMinimal
        // - Calcule et retourne le nombre de valeurs de la collection qui sont au dessus ou égal à pSeuilMinimal
        // Compléter ici



        #endregion

        #region Méthodes pour filtrer une collection

        // TODO 13 : Définir une méthode appelée FiltrerSelonSeuilMinimalV1 qui :
        // - Reçoit/accepte en paramètre une collection d'entiers et un entier pSeuilMinimal
        // - Retourne dans une nouvelle collection les valeurs qui sont au dessus ou égal à pSeuilMinimal
        // Compléter ici


        // TODO 17 : Définir une méthode appelée FiltrerSelonSeuilMinimalV2 qui :
        // - Reçoit/accepte en paramètre une collection d'entiers et un entier pSeuilMinimal
        // - Enlève de la collection les éléments qui sont au dessous de pSeuilMinimal
        // Compléter ici
        


        #endregion
       
    }
}
