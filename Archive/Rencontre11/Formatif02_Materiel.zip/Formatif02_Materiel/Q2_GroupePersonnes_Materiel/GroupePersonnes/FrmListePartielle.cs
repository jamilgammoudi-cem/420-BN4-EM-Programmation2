﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace GroupePersonnes
{
    /// <summary>
    /// Un formulaire qui affiche une sous-liste de personnes dont le nom débute par une certaine chaîne. 
    /// </summary>
    public partial class FrmListePartielle : Form
    {
       
        private List<Personne> m_colPersonnes;

        #region TODO 06 : Modifier le constructeur

        // TODO 11 : Modifier le constructeur pour qu'il accepte une collection de personnes et l'affecter
        // à la collection locale m_colPersonnes

        public FrmListePartielle()
        {
            InitializeComponent();
            this.Text += FrmPrincipal.APP_INFO;
                  
            // À COMPLÉTER...
           




            //NE PAS MODIFIER -----------------------------------------------------------------------------------
            cboCritere.SelectedIndex = 0;
            cboAge.SelectedIndex = 0;

            AfficherPersonnesSelonFlitre();

        }
        #endregion

      

        private void btnFermer_Click(object sender, EventArgs e)
        {
            Close();
        }

        //=============================================================================
        // TODO 13 : Parcourir la collection m_colPersonnes et afficher dans le ListBox seulement les personnes
        // dont l'age répond aux critères de selection
       // Utilisez la tabulation "\t"  pour séparer les informations d'une personne
        private void AfficherPersonnesSelonFlitre()
        {
            lstPartielle.Items.Clear();

            // À COMPLÉTER...



        }

        private void cboCritere_SelectedIndexChanged(object sender, EventArgs e)
        {
            AfficherPersonnesSelonFlitre();
        }

        private void cboAge_SelectedIndexChanged(object sender, EventArgs e)
        {
            AfficherPersonnesSelonFlitre();
        }
    }
}
