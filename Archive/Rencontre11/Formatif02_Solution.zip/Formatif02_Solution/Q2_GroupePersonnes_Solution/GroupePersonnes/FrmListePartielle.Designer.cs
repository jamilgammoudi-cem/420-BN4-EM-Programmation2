﻿namespace GroupePersonnes
{
    partial class FrmListePartielle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstPartielle = new System.Windows.Forms.ListBox();
            this.btnFermer = new System.Windows.Forms.Button();
            this.lblCritere = new System.Windows.Forms.Label();
            this.cboCritere = new System.Windows.Forms.ComboBox();
            this.cboAge = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lstPartielle
            // 
            this.lstPartielle.FormattingEnabled = true;
            this.lstPartielle.Location = new System.Drawing.Point(15, 48);
            this.lstPartielle.Name = "lstPartielle";
            this.lstPartielle.Size = new System.Drawing.Size(347, 199);
            this.lstPartielle.TabIndex = 3;
            // 
            // btnFermer
            // 
            this.btnFermer.Location = new System.Drawing.Point(211, 259);
            this.btnFermer.Name = "btnFermer";
            this.btnFermer.Size = new System.Drawing.Size(89, 24);
            this.btnFermer.TabIndex = 4;
            this.btnFermer.Text = "Fermer";
            this.btnFermer.UseVisualStyleBackColor = true;
            this.btnFermer.Click += new System.EventHandler(this.btnFermer_Click);
            // 
            // lblCritere
            // 
            this.lblCritere.AutoSize = true;
            this.lblCritere.Location = new System.Drawing.Point(12, 15);
            this.lblCritere.Name = "lblCritere";
            this.lblCritere.Size = new System.Drawing.Size(32, 13);
            this.lblCritere.TabIndex = 1;
            this.lblCritere.Text = "Age :";
            // 
            // cboCritere
            // 
            this.cboCritere.FormattingEnabled = true;
            this.cboCritere.Items.AddRange(new object[] {
            "Supérieur",
            "Inférieur"});
            this.cboCritere.Location = new System.Drawing.Point(69, 10);
            this.cboCritere.Name = "cboCritere";
            this.cboCritere.Size = new System.Drawing.Size(121, 21);
            this.cboCritere.TabIndex = 5;
            this.cboCritere.SelectedIndexChanged += new System.EventHandler(this.cboCritere_SelectedIndexChanged);
            // 
            // cboAge
            // 
            this.cboAge.FormattingEnabled = true;
            this.cboAge.Items.AddRange(new object[] {
            "20",
            "30",
            "40",
            "50"});
            this.cboAge.Location = new System.Drawing.Point(196, 10);
            this.cboAge.Name = "cboAge";
            this.cboAge.Size = new System.Drawing.Size(121, 21);
            this.cboAge.TabIndex = 6;
            this.cboAge.SelectedIndexChanged += new System.EventHandler(this.cboAge_SelectedIndexChanged);
            // 
            // FrmListePartielle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(495, 295);
            this.Controls.Add(this.cboAge);
            this.Controls.Add(this.cboCritere);
            this.Controls.Add(this.lblCritere);
            this.Controls.Add(this.btnFermer);
            this.Controls.Add(this.lstPartielle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmListePartielle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Liste partielle ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstPartielle;
        private System.Windows.Forms.Button btnFermer;
        private System.Windows.Forms.Label lblCritere;
        private System.Windows.Forms.ComboBox cboCritere;
        private System.Windows.Forms.ComboBox cboAge;
    }
}