﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormatifQ1
{
    public class Billeterie
    {

        private TypeChalet m_chaletChoisi;
        public int m_nbVisiteursChoisi;
        public Camping CampingChoisi { get; set; }
        
        public TypeChalet ChaletChoisi
        {
            get { return m_chaletChoisi; }
            set 
            {
                if(value != TypeChalet.AUCUN && value != TypeChalet.COMPACT 
                    && value != TypeChalet.ECHO && value != TypeChalet.HORIZON 
                    && value != TypeChalet.NATURE && value != TypeChalet.OXYGENE)
                {
                    throw new ArgumentException();
                }
                m_chaletChoisi = value;
            }
        }
        public int NbVisiteursChoisi
        {
            get { return m_nbVisiteursChoisi; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentException();
                }
                m_nbVisiteursChoisi = value;
            }
            
        }
       

        public bool ChaletChoisiEstDisponible
        {
            get
            {
                return CampingChoisi.TypeChaletEstDisponible(ChaletChoisi);
            }
        }

       
        public decimal FraisChaletChoisi
        {
            get
            {
                return CampingChoisi.FraisParChalet(ChaletChoisi);
            }
        }
        public decimal FraisVisiteurs
        {
            get
            {
                return CampingChoisi.FraisVisiteurs(NbVisiteursChoisi);
            }
        }
        public decimal TotalAPayer
        {
            get
            {
                return CampingChoisi.TotalAPayer(ChaletChoisi, NbVisiteursChoisi);
            }
        }
        public Billeterie(Camping pObjCamping)
        {
            if (pObjCamping == null)
            {
                throw new ArgumentNullException();
            }
            CampingChoisi = pObjCamping;
            ChaletChoisi = TypeChalet.AUCUN;
            NbVisiteursChoisi = 0;

        }

        public void ReserverChaletChoisi()
        {
            CampingChoisi.ReserverChalet(ChaletChoisi);
        }
    }
}
