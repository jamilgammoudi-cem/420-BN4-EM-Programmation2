﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormatifQ1
{
    public partial class FrmPrincipal : Form
    {
        public const String APP_INFO = "(Matériel)";
        Camping m_objCamping;
        Billeterie m_objBilleterie1;
        Billeterie m_objBilleterie2;

        public FrmPrincipal()
        {
            InitializeComponent();

            m_objCamping = new Camping(90, 120, 150, 180, 210);
            m_objBilleterie1 = new Billeterie(m_objCamping);
            m_objBilleterie2 = new Billeterie(m_objCamping);
            AfficherDisponibilités();
            MettreAJourSelonContexte();

        }

        public void AfficherDisponibilités() 
        {
            txtNbCompact.Text = m_objCamping.NbChaletsDisponibles(TypeChalet.COMPACT).ToString();
            txtNbEcho.Text = m_objCamping.NbChaletsDisponibles(TypeChalet.ECHO).ToString();
            txtNbHorizon.Text = m_objCamping.NbChaletsDisponibles(TypeChalet.HORIZON).ToString();
            txtNbNature.Text = m_objCamping.NbChaletsDisponibles(TypeChalet.NATURE).ToString();
            txtNbOxygene.Text = m_objCamping.NbChaletsDisponibles(TypeChalet.OXYGENE).ToString();
        }

        private void cboBilleterie1Chalett_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_objBilleterie1.ChaletChoisi = (TypeChalet)cboBilleterie1Chalet.SelectedIndex;
            m_objBilleterie1.NbVisiteursChoisi = 0;
            numBilleterie1NbVisiteurs.Value = 0;
            txtBilleterie1FraisChalet.Text = m_objBilleterie1.FraisChaletChoisi.ToString();
            txtBilleterie1Total.Text = m_objBilleterie1.TotalAPayer.ToString();

            MettreAJourSelonContexte();
        }

        private void numBilleterie1NbVisiteurs_ValueChanged(object sender, EventArgs e)
        {
            m_objBilleterie1.NbVisiteursChoisi = (int)numBilleterie1NbVisiteurs.Value;
            //txtFraisChalet.Text = m_objBilleterie1.FraisParChalet.ToString();
            txtBilleterie1Total.Text = m_objBilleterie1.TotalAPayer.ToString();

            MettreAJourSelonContexte();
        }

        

        private void btnBilleterie1Reserver_Click(object sender, EventArgs e)
        {
            m_objBilleterie1.ReserverChaletChoisi();
            AfficherDisponibilités();
            MettreAJourSelonContexte();
        }

        private void btnBilleterie2Reserver_Click(object sender, EventArgs e)
        {
            m_objBilleterie2.ReserverChaletChoisi();
            AfficherDisponibilités();
            MettreAJourSelonContexte();
        }

        private void cboBilleterie2Chalet_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_objBilleterie2.ChaletChoisi = (TypeChalet)cboBilleterie2Chalet.SelectedIndex;
            m_objBilleterie2.NbVisiteursChoisi = 0;
            numBilleterie2NbVisiteurs.Value = 0;
            txtBilleterie2FraisChalet.Text = m_objBilleterie2.FraisChaletChoisi.ToString();
            txtBilleterie2Total.Text = m_objBilleterie2.TotalAPayer.ToString();
            MettreAJourSelonContexte();
        }

        private void numBilleterie2NbVisiteurs_ValueChanged(object sender, EventArgs e)
        {
            m_objBilleterie2.NbVisiteursChoisi = (int)numBilleterie2NbVisiteurs.Value;
            //txtFraisChalet.Text = m_objBilleterie1.FraisParChalet.ToString();
            txtBilleterie2Total.Text = m_objBilleterie2.TotalAPayer.ToString();
            MettreAJourSelonContexte();
        }
        private void MettreAJourSelonContexte()
        {
            numBilleterie1NbVisiteurs.Enabled = true;
            btnBilleterie1Reserver.Enabled = true;
            if (!m_objBilleterie1.ChaletChoisiEstDisponible)
            {
                numBilleterie1NbVisiteurs.Enabled = false;
                btnBilleterie1Reserver.Enabled = false;
            }

            numBilleterie2NbVisiteurs.Enabled = true;
            btnBilleterie2Reserver.Enabled = true;
            if (!m_objBilleterie2.ChaletChoisiEstDisponible)
            {
                numBilleterie2NbVisiteurs.Enabled = false;
                btnBilleterie2Reserver.Enabled = false;
            }

        }
    }
}
