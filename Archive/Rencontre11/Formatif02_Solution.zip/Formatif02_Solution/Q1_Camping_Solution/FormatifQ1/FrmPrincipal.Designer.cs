﻿
namespace FormatifQ1
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.panLigne2 = new System.Windows.Forms.Panel();
            this.panLigne1 = new System.Windows.Forms.Panel();
            this.panConsommation = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtNbCompact = new System.Windows.Forms.TextBox();
            this.txtNbOxygene = new System.Windows.Forms.TextBox();
            this.txtNbEcho = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNbNature = new System.Windows.Forms.TextBox();
            this.txtNbHorizon = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panPompes = new System.Windows.Forms.Panel();
            this.grpPrise2 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtBilleterie2FraisChalet = new System.Windows.Forms.TextBox();
            this.btnBilleterie2Reserver = new System.Windows.Forms.Button();
            this.lblBilleterie2Chalet = new System.Windows.Forms.Label();
            this.lblPrise2Qte = new System.Windows.Forms.Label();
            this.lblPrise2Durée = new System.Windows.Forms.Label();
            this.cboBilleterie2Chalet = new System.Windows.Forms.ComboBox();
            this.txtBilleterie2Total = new System.Windows.Forms.TextBox();
            this.numBilleterie2NbVisiteurs = new System.Windows.Forms.NumericUpDown();
            this.grpPrise1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtBilleterie1FraisChalet = new System.Windows.Forms.TextBox();
            this.lblBilleterie1Chalet = new System.Windows.Forms.Label();
            this.lblPrise1Qte = new System.Windows.Forms.Label();
            this.lblPrise1Durée = new System.Windows.Forms.Label();
            this.txtBilleterie1Total = new System.Windows.Forms.TextBox();
            this.btnBilleterie1Reserver = new System.Windows.Forms.Button();
            this.cboBilleterie1Chalet = new System.Windows.Forms.ComboBox();
            this.numBilleterie1NbVisiteurs = new System.Windows.Forms.NumericUpDown();
            this.mnuFichierQuitter = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFichier = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuPrincipal = new System.Windows.Forms.MenuStrip();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panConsommation.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panPompes.SuspendLayout();
            this.grpPrise2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numBilleterie2NbVisiteurs)).BeginInit();
            this.grpPrise1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numBilleterie1NbVisiteurs)).BeginInit();
            this.mnuPrincipal.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel2.Location = new System.Drawing.Point(109, 317);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(676, 10);
            this.panel2.TabIndex = 39;
            // 
            // panLigne2
            // 
            this.panLigne2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panLigne2.Location = new System.Drawing.Point(771, 276);
            this.panLigne2.Margin = new System.Windows.Forms.Padding(4);
            this.panLigne2.Name = "panLigne2";
            this.panLigne2.Size = new System.Drawing.Size(14, 44);
            this.panLigne2.TabIndex = 37;
            // 
            // panLigne1
            // 
            this.panLigne1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panLigne1.Location = new System.Drawing.Point(496, 276);
            this.panLigne1.Margin = new System.Windows.Forms.Padding(4);
            this.panLigne1.Name = "panLigne1";
            this.panLigne1.Size = new System.Drawing.Size(15, 45);
            this.panLigne1.TabIndex = 35;
            // 
            // panConsommation
            // 
            this.panConsommation.BackColor = System.Drawing.Color.Silver;
            this.panConsommation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panConsommation.Controls.Add(this.groupBox1);
            this.panConsommation.Controls.Add(this.panPompes);
            this.panConsommation.Location = new System.Drawing.Point(18, 49);
            this.panConsommation.Margin = new System.Windows.Forms.Padding(4);
            this.panConsommation.Name = "panConsommation";
            this.panConsommation.Size = new System.Drawing.Size(913, 290);
            this.panConsommation.TabIndex = 40;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtNbCompact);
            this.groupBox1.Controls.Add(this.txtNbOxygene);
            this.groupBox1.Controls.Add(this.txtNbEcho);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtNbNature);
            this.groupBox1.Controls.Add(this.txtNbHorizon);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(24, 16);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(224, 192);
            this.groupBox1.TabIndex = 48;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Chalets disponibles";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 17);
            this.label1.TabIndex = 40;
            this.label1.Text = "Chalet Compact :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(26, 164);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(116, 17);
            this.label6.TabIndex = 46;
            this.label6.Text = "Chalet Oxygene :";
            // 
            // txtNbCompact
            // 
            this.txtNbCompact.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNbCompact.Location = new System.Drawing.Point(141, 21);
            this.txtNbCompact.Margin = new System.Windows.Forms.Padding(4);
            this.txtNbCompact.Name = "txtNbCompact";
            this.txtNbCompact.ReadOnly = true;
            this.txtNbCompact.Size = new System.Drawing.Size(66, 23);
            this.txtNbCompact.TabIndex = 39;
            this.txtNbCompact.Text = "0";
            this.txtNbCompact.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNbOxygene
            // 
            this.txtNbOxygene.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNbOxygene.Location = new System.Drawing.Point(141, 160);
            this.txtNbOxygene.Margin = new System.Windows.Forms.Padding(4);
            this.txtNbOxygene.Name = "txtNbOxygene";
            this.txtNbOxygene.ReadOnly = true;
            this.txtNbOxygene.Size = new System.Drawing.Size(66, 23);
            this.txtNbOxygene.TabIndex = 45;
            this.txtNbOxygene.Text = "0";
            this.txtNbOxygene.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNbEcho
            // 
            this.txtNbEcho.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNbEcho.Location = new System.Drawing.Point(141, 57);
            this.txtNbEcho.Margin = new System.Windows.Forms.Padding(4);
            this.txtNbEcho.Name = "txtNbEcho";
            this.txtNbEcho.ReadOnly = true;
            this.txtNbEcho.Size = new System.Drawing.Size(66, 23);
            this.txtNbEcho.TabIndex = 39;
            this.txtNbEcho.Text = "0";
            this.txtNbEcho.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(26, 129);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 17);
            this.label4.TabIndex = 44;
            this.label4.Text = "Chalet Nature :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 61);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 17);
            this.label2.TabIndex = 40;
            this.label2.Text = "Chalet Echo :";
            // 
            // txtNbNature
            // 
            this.txtNbNature.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNbNature.Location = new System.Drawing.Point(141, 125);
            this.txtNbNature.Margin = new System.Windows.Forms.Padding(4);
            this.txtNbNature.Name = "txtNbNature";
            this.txtNbNature.ReadOnly = true;
            this.txtNbNature.Size = new System.Drawing.Size(66, 23);
            this.txtNbNature.TabIndex = 43;
            this.txtNbNature.Text = "0";
            this.txtNbNature.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNbHorizon
            // 
            this.txtNbHorizon.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNbHorizon.Location = new System.Drawing.Point(141, 89);
            this.txtNbHorizon.Margin = new System.Windows.Forms.Padding(4);
            this.txtNbHorizon.Name = "txtNbHorizon";
            this.txtNbHorizon.ReadOnly = true;
            this.txtNbHorizon.Size = new System.Drawing.Size(66, 23);
            this.txtNbHorizon.TabIndex = 41;
            this.txtNbHorizon.Text = "0";
            this.txtNbHorizon.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(26, 93);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 17);
            this.label3.TabIndex = 42;
            this.label3.Text = "Chalet Horizon :";
            // 
            // panPompes
            // 
            this.panPompes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.panPompes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panPompes.Controls.Add(this.grpPrise2);
            this.panPompes.Controls.Add(this.grpPrise1);
            this.panPompes.Location = new System.Drawing.Point(263, 7);
            this.panPompes.Margin = new System.Windows.Forms.Padding(4);
            this.panPompes.Name = "panPompes";
            this.panPompes.Size = new System.Drawing.Size(641, 237);
            this.panPompes.TabIndex = 2;
            // 
            // grpPrise2
            // 
            this.grpPrise2.Controls.Add(this.label8);
            this.grpPrise2.Controls.Add(this.txtBilleterie2FraisChalet);
            this.grpPrise2.Controls.Add(this.btnBilleterie2Reserver);
            this.grpPrise2.Controls.Add(this.lblBilleterie2Chalet);
            this.grpPrise2.Controls.Add(this.lblPrise2Qte);
            this.grpPrise2.Controls.Add(this.lblPrise2Durée);
            this.grpPrise2.Controls.Add(this.cboBilleterie2Chalet);
            this.grpPrise2.Controls.Add(this.txtBilleterie2Total);
            this.grpPrise2.Controls.Add(this.numBilleterie2NbVisiteurs);
            this.grpPrise2.Location = new System.Drawing.Point(334, 14);
            this.grpPrise2.Margin = new System.Windows.Forms.Padding(4);
            this.grpPrise2.Name = "grpPrise2";
            this.grpPrise2.Padding = new System.Windows.Forms.Padding(4);
            this.grpPrise2.Size = new System.Drawing.Size(293, 217);
            this.grpPrise2.TabIndex = 30;
            this.grpPrise2.TabStop = false;
            this.grpPrise2.Text = "Billeterie #2";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(92, 112);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 17);
            this.label8.TabIndex = 36;
            this.label8.Text = "Frais chalet :";
            // 
            // txtBilleterie2FraisChalet
            // 
            this.txtBilleterie2FraisChalet.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBilleterie2FraisChalet.Location = new System.Drawing.Point(207, 108);
            this.txtBilleterie2FraisChalet.Margin = new System.Windows.Forms.Padding(4);
            this.txtBilleterie2FraisChalet.Name = "txtBilleterie2FraisChalet";
            this.txtBilleterie2FraisChalet.ReadOnly = true;
            this.txtBilleterie2FraisChalet.Size = new System.Drawing.Size(66, 23);
            this.txtBilleterie2FraisChalet.TabIndex = 35;
            this.txtBilleterie2FraisChalet.Text = "0";
            this.txtBilleterie2FraisChalet.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnBilleterie2Reserver
            // 
            this.btnBilleterie2Reserver.Location = new System.Drawing.Point(89, 175);
            this.btnBilleterie2Reserver.Margin = new System.Windows.Forms.Padding(4);
            this.btnBilleterie2Reserver.Name = "btnBilleterie2Reserver";
            this.btnBilleterie2Reserver.Size = new System.Drawing.Size(140, 28);
            this.btnBilleterie2Reserver.TabIndex = 34;
            this.btnBilleterie2Reserver.Text = "Réserver";
            this.btnBilleterie2Reserver.UseVisualStyleBackColor = true;
            this.btnBilleterie2Reserver.Click += new System.EventHandler(this.btnBilleterie2Reserver_Click);
            // 
            // lblBilleterie2Chalet
            // 
            this.lblBilleterie2Chalet.AutoSize = true;
            this.lblBilleterie2Chalet.Location = new System.Drawing.Point(133, 25);
            this.lblBilleterie2Chalet.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBilleterie2Chalet.Name = "lblBilleterie2Chalet";
            this.lblBilleterie2Chalet.Size = new System.Drawing.Size(112, 17);
            this.lblBilleterie2Chalet.TabIndex = 33;
            this.lblBilleterie2Chalet.Text = "Choix de chalet :";
            // 
            // lblPrise2Qte
            // 
            this.lblPrise2Qte.AutoSize = true;
            this.lblPrise2Qte.Location = new System.Drawing.Point(71, 138);
            this.lblPrise2Qte.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPrise2Qte.Name = "lblPrise2Qte";
            this.lblPrise2Qte.Size = new System.Drawing.Size(119, 17);
            this.lblPrise2Qte.TabIndex = 32;
            this.lblPrise2Qte.Text = "Montant à payer :";
            // 
            // lblPrise2Durée
            // 
            this.lblPrise2Durée.AutoSize = true;
            this.lblPrise2Durée.Location = new System.Drawing.Point(71, 81);
            this.lblPrise2Durée.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPrise2Durée.Name = "lblPrise2Durée";
            this.lblPrise2Durée.Size = new System.Drawing.Size(110, 17);
            this.lblPrise2Durée.TabIndex = 31;
            this.lblPrise2Durée.Text = "Nb de visiteurs :";
            // 
            // cboBilleterie2Chalet
            // 
            this.cboBilleterie2Chalet.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboBilleterie2Chalet.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboBilleterie2Chalet.FormattingEnabled = true;
            this.cboBilleterie2Chalet.Items.AddRange(new object[] {
            "Compact",
            "Echo",
            "Horizon",
            "Nature",
            "Oxygene"});
            this.cboBilleterie2Chalet.Location = new System.Drawing.Point(132, 44);
            this.cboBilleterie2Chalet.Margin = new System.Windows.Forms.Padding(4);
            this.cboBilleterie2Chalet.Name = "cboBilleterie2Chalet";
            this.cboBilleterie2Chalet.Size = new System.Drawing.Size(139, 25);
            this.cboBilleterie2Chalet.TabIndex = 20;
            this.cboBilleterie2Chalet.SelectedIndexChanged += new System.EventHandler(this.cboBilleterie2Chalet_SelectedIndexChanged);
            // 
            // txtBilleterie2Total
            // 
            this.txtBilleterie2Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBilleterie2Total.Location = new System.Drawing.Point(192, 134);
            this.txtBilleterie2Total.Margin = new System.Windows.Forms.Padding(4);
            this.txtBilleterie2Total.Name = "txtBilleterie2Total";
            this.txtBilleterie2Total.ReadOnly = true;
            this.txtBilleterie2Total.Size = new System.Drawing.Size(80, 23);
            this.txtBilleterie2Total.TabIndex = 23;
            this.txtBilleterie2Total.Text = "0";
            this.txtBilleterie2Total.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numBilleterie2NbVisiteurs
            // 
            this.numBilleterie2NbVisiteurs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numBilleterie2NbVisiteurs.Location = new System.Drawing.Point(191, 78);
            this.numBilleterie2NbVisiteurs.Margin = new System.Windows.Forms.Padding(4);
            this.numBilleterie2NbVisiteurs.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.numBilleterie2NbVisiteurs.Name = "numBilleterie2NbVisiteurs";
            this.numBilleterie2NbVisiteurs.Size = new System.Drawing.Size(81, 23);
            this.numBilleterie2NbVisiteurs.TabIndex = 21;
            this.numBilleterie2NbVisiteurs.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numBilleterie2NbVisiteurs.ValueChanged += new System.EventHandler(this.numBilleterie2NbVisiteurs_ValueChanged);
            // 
            // grpPrise1
            // 
            this.grpPrise1.Controls.Add(this.label7);
            this.grpPrise1.Controls.Add(this.txtBilleterie1FraisChalet);
            this.grpPrise1.Controls.Add(this.lblBilleterie1Chalet);
            this.grpPrise1.Controls.Add(this.lblPrise1Qte);
            this.grpPrise1.Controls.Add(this.lblPrise1Durée);
            this.grpPrise1.Controls.Add(this.txtBilleterie1Total);
            this.grpPrise1.Controls.Add(this.btnBilleterie1Reserver);
            this.grpPrise1.Controls.Add(this.cboBilleterie1Chalet);
            this.grpPrise1.Controls.Add(this.numBilleterie1NbVisiteurs);
            this.grpPrise1.Location = new System.Drawing.Point(17, 14);
            this.grpPrise1.Margin = new System.Windows.Forms.Padding(4);
            this.grpPrise1.Name = "grpPrise1";
            this.grpPrise1.Padding = new System.Windows.Forms.Padding(4);
            this.grpPrise1.Size = new System.Drawing.Size(309, 217);
            this.grpPrise1.TabIndex = 29;
            this.grpPrise1.TabStop = false;
            this.grpPrise1.Text = "Billeterie #1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(126, 112);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 17);
            this.label7.TabIndex = 34;
            this.label7.Text = "Frais chalet :";
            // 
            // txtBilleterie1FraisChalet
            // 
            this.txtBilleterie1FraisChalet.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBilleterie1FraisChalet.Location = new System.Drawing.Point(241, 108);
            this.txtBilleterie1FraisChalet.Margin = new System.Windows.Forms.Padding(4);
            this.txtBilleterie1FraisChalet.Name = "txtBilleterie1FraisChalet";
            this.txtBilleterie1FraisChalet.ReadOnly = true;
            this.txtBilleterie1FraisChalet.Size = new System.Drawing.Size(66, 23);
            this.txtBilleterie1FraisChalet.TabIndex = 33;
            this.txtBilleterie1FraisChalet.Text = "0";
            this.txtBilleterie1FraisChalet.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblBilleterie1Chalet
            // 
            this.lblBilleterie1Chalet.AutoSize = true;
            this.lblBilleterie1Chalet.Location = new System.Drawing.Point(129, 25);
            this.lblBilleterie1Chalet.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBilleterie1Chalet.Name = "lblBilleterie1Chalet";
            this.lblBilleterie1Chalet.Size = new System.Drawing.Size(112, 17);
            this.lblBilleterie1Chalet.TabIndex = 32;
            this.lblBilleterie1Chalet.Text = "Choix de chalet :";
            // 
            // lblPrise1Qte
            // 
            this.lblPrise1Qte.AutoSize = true;
            this.lblPrise1Qte.Location = new System.Drawing.Point(122, 138);
            this.lblPrise1Qte.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPrise1Qte.Name = "lblPrise1Qte";
            this.lblPrise1Qte.Size = new System.Drawing.Size(119, 17);
            this.lblPrise1Qte.TabIndex = 31;
            this.lblPrise1Qte.Text = "Montant à payer :";
            // 
            // lblPrise1Durée
            // 
            this.lblPrise1Durée.AutoSize = true;
            this.lblPrise1Durée.Location = new System.Drawing.Point(129, 81);
            this.lblPrise1Durée.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPrise1Durée.Name = "lblPrise1Durée";
            this.lblPrise1Durée.Size = new System.Drawing.Size(90, 17);
            this.lblPrise1Durée.TabIndex = 30;
            this.lblPrise1Durée.Text = "Nb visiteurs :";
            // 
            // txtBilleterie1Total
            // 
            this.txtBilleterie1Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBilleterie1Total.Location = new System.Drawing.Point(241, 134);
            this.txtBilleterie1Total.Margin = new System.Windows.Forms.Padding(4);
            this.txtBilleterie1Total.Name = "txtBilleterie1Total";
            this.txtBilleterie1Total.ReadOnly = true;
            this.txtBilleterie1Total.Size = new System.Drawing.Size(66, 23);
            this.txtBilleterie1Total.TabIndex = 29;
            this.txtBilleterie1Total.Text = "0";
            this.txtBilleterie1Total.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnBilleterie1Reserver
            // 
            this.btnBilleterie1Reserver.Location = new System.Drawing.Point(149, 174);
            this.btnBilleterie1Reserver.Margin = new System.Windows.Forms.Padding(4);
            this.btnBilleterie1Reserver.Name = "btnBilleterie1Reserver";
            this.btnBilleterie1Reserver.Size = new System.Drawing.Size(107, 29);
            this.btnBilleterie1Reserver.TabIndex = 28;
            this.btnBilleterie1Reserver.Text = "Réserver";
            this.btnBilleterie1Reserver.UseVisualStyleBackColor = true;
            this.btnBilleterie1Reserver.Click += new System.EventHandler(this.btnBilleterie1Reserver_Click);
            // 
            // cboBilleterie1Chalet
            // 
            this.cboBilleterie1Chalet.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboBilleterie1Chalet.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboBilleterie1Chalet.FormattingEnabled = true;
            this.cboBilleterie1Chalet.Items.AddRange(new object[] {
            "Compact",
            "Echo",
            "Horizon",
            "Nature",
            "Oxygene"});
            this.cboBilleterie1Chalet.Location = new System.Drawing.Point(129, 44);
            this.cboBilleterie1Chalet.Margin = new System.Windows.Forms.Padding(4);
            this.cboBilleterie1Chalet.Name = "cboBilleterie1Chalet";
            this.cboBilleterie1Chalet.Size = new System.Drawing.Size(174, 25);
            this.cboBilleterie1Chalet.TabIndex = 26;
            this.cboBilleterie1Chalet.SelectedIndexChanged += new System.EventHandler(this.cboBilleterie1Chalett_SelectedIndexChanged);
            // 
            // numBilleterie1NbVisiteurs
            // 
            this.numBilleterie1NbVisiteurs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numBilleterie1NbVisiteurs.Location = new System.Drawing.Point(236, 77);
            this.numBilleterie1NbVisiteurs.Margin = new System.Windows.Forms.Padding(4);
            this.numBilleterie1NbVisiteurs.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.numBilleterie1NbVisiteurs.Name = "numBilleterie1NbVisiteurs";
            this.numBilleterie1NbVisiteurs.Size = new System.Drawing.Size(69, 23);
            this.numBilleterie1NbVisiteurs.TabIndex = 27;
            this.numBilleterie1NbVisiteurs.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numBilleterie1NbVisiteurs.ValueChanged += new System.EventHandler(this.numBilleterie1NbVisiteurs_ValueChanged);
            // 
            // mnuFichierQuitter
            // 
            this.mnuFichierQuitter.Name = "mnuFichierQuitter";
            this.mnuFichierQuitter.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Q)));
            this.mnuFichierQuitter.Size = new System.Drawing.Size(191, 26);
            this.mnuFichierQuitter.Text = "&Quitter";
            // 
            // mnuFichier
            // 
            this.mnuFichier.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFichierQuitter});
            this.mnuFichier.Name = "mnuFichier";
            this.mnuFichier.Size = new System.Drawing.Size(66, 24);
            this.mnuFichier.Text = "&Fichier";
            // 
            // mnuPrincipal
            // 
            this.mnuPrincipal.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.mnuPrincipal.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFichier});
            this.mnuPrincipal.Location = new System.Drawing.Point(0, 0);
            this.mnuPrincipal.Name = "mnuPrincipal";
            this.mnuPrincipal.Size = new System.Drawing.Size(935, 28);
            this.mnuPrincipal.TabIndex = 36;
            this.mnuPrincipal.Text = "menuStrip1";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel3.Location = new System.Drawing.Point(110, 265);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(13, 63);
            this.panel3.TabIndex = 42;
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(935, 341);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panLigne2);
            this.Controls.Add(this.panLigne1);
            this.Controls.Add(this.panConsommation);
            this.Controls.Add(this.mnuPrincipal);
            this.Name = "FrmPrincipal";
            this.Text = "Définition de classes";
            this.panConsommation.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panPompes.ResumeLayout(false);
            this.grpPrise2.ResumeLayout(false);
            this.grpPrise2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numBilleterie2NbVisiteurs)).EndInit();
            this.grpPrise1.ResumeLayout(false);
            this.grpPrise1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numBilleterie1NbVisiteurs)).EndInit();
            this.mnuPrincipal.ResumeLayout(false);
            this.mnuPrincipal.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panLigne2;
        private System.Windows.Forms.Panel panLigne1;
        private System.Windows.Forms.Panel panConsommation;
        private System.Windows.Forms.Panel panPompes;
        private System.Windows.Forms.GroupBox grpPrise2;
        private System.Windows.Forms.Label lblBilleterie2Chalet;
        private System.Windows.Forms.Label lblPrise2Qte;
        private System.Windows.Forms.Label lblPrise2Durée;
        private System.Windows.Forms.ComboBox cboBilleterie2Chalet;
        private System.Windows.Forms.TextBox txtBilleterie2Total;
        private System.Windows.Forms.NumericUpDown numBilleterie2NbVisiteurs;
        private System.Windows.Forms.GroupBox grpPrise1;
        private System.Windows.Forms.Label lblBilleterie1Chalet;
        private System.Windows.Forms.Label lblPrise1Qte;
        private System.Windows.Forms.Label lblPrise1Durée;
        private System.Windows.Forms.TextBox txtBilleterie1Total;
        private System.Windows.Forms.Button btnBilleterie1Reserver;
        private System.Windows.Forms.ComboBox cboBilleterie1Chalet;
        private System.Windows.Forms.NumericUpDown numBilleterie1NbVisiteurs;
        private System.Windows.Forms.ToolStripMenuItem mnuFichierQuitter;
        private System.Windows.Forms.ToolStripMenuItem mnuFichier;
        private System.Windows.Forms.MenuStrip mnuPrincipal;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtNbOxygene;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtNbNature;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNbHorizon;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNbEcho;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNbCompact;
        private System.Windows.Forms.Button btnBilleterie2Reserver;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtBilleterie1FraisChalet;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtBilleterie2FraisChalet;
        private System.Windows.Forms.Panel panel3;
    }
}

