﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormatifQ1
{
   
    public enum TypeChalet { AUCUN=-1, COMPACT, ECHO, HORIZON, NATURE, OXYGENE };

}
