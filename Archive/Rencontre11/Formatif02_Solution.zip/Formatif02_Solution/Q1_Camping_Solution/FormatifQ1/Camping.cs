﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormatifQ1
{
    public class Camping
    {
        #region Constantes
       
        public const decimal FRAIS_PAR_VISITEUR = 10;
        public const int NB_MAX_CHALETS_PAR_TYPE = 4;
        #endregion
        #region Champs
        private decimal m_fraisChaletCompact;
        private decimal m_fraisChaletEcho;
        private decimal m_fraisChaletHorizon;
        private decimal m_fraisChaletNature;
        private decimal m_fraisChaletOxygene;
        public int[] m_tabNbChaletsDisponibles = new int[5];
        #endregion
        #region Propriétés
        public decimal FraisChaletCompact
        {
            get
            {
                return m_fraisChaletCompact; 
            }
        }
        public decimal FraisChaletEcho
        {
            get
            {
                return m_fraisChaletEcho;
            }
        }
        public decimal FraisChaletHorizon
        {
            get
            {
                return m_fraisChaletHorizon;
            }
        }
        public decimal FraisChaletNature
        {
            get
            {
                return m_fraisChaletNature;
            }
        }
        public decimal FraisChaletOxygene
        {
            get
            {
                return m_fraisChaletOxygene;
            }
        }
        #endregion
        #region Constructeurs
        public Camping(decimal pFraisChaletCompact,
                      decimal pFraisChaletEcho,
                      decimal pFraisChaletHorizon,
                      decimal pFraisChaletNature,
                      decimal pFraisChaletOxygene)
        {
            // Validation des frais de chaque type de chalet
            if (pFraisChaletCompact <= 0 || pFraisChaletEcho <= 0 || pFraisChaletHorizon <= 0
                || pFraisChaletNature <= 0 || pFraisChaletOxygene <= 0)
            {
                throw new ArgumentOutOfRangeException();
            }
            
            m_fraisChaletCompact = pFraisChaletCompact;
            m_fraisChaletEcho = pFraisChaletEcho;
            m_fraisChaletHorizon = pFraisChaletHorizon;
            m_fraisChaletNature = pFraisChaletNature;
            m_fraisChaletOxygene = pFraisChaletOxygene;
            for (int index = 0; index < m_tabNbChaletsDisponibles.Length; index++)
            {
                m_tabNbChaletsDisponibles[index] = NB_MAX_CHALETS_PAR_TYPE;
            }
        }
        #endregion
        #region Méthodes
        public bool TypeChaletEstDisponible(TypeChalet pTypeChalet)
        {
            // Si pTypeChalet est TypeChalet.AUCUN ou il ne figure pas dans
            // la liste des types de chalet
            if (((int) pTypeChalet) <= -1 || ((int)pTypeChalet) > 4)
                return false;


            return m_tabNbChaletsDisponibles[(int)pTypeChalet] != 0;
        }
        public int NbChaletsDisponibles(TypeChalet pTypeChalet)
        {
            // Si pTypeChalet est TypeChalet.AUCUN ou il ne figure pas dans
            // la liste des types de chalet
            if (((int)pTypeChalet) <= -1 || ((int)pTypeChalet) > 4)
                return 0;


            return m_tabNbChaletsDisponibles[(int)pTypeChalet];
        }
        public decimal TotalAPayer(TypeChalet pTypeChalet, int pNbVisisteurs)
        {

            // Si pTypeChalet est TypeChalet.AUCUN ou il ne figure pas dans
            // la liste des types de chalet
            if (((int)pTypeChalet) <= -1 || ((int)pTypeChalet) > 4)
                return 0;

            // calcul et retour du total à payer                
            return FraisVisiteurs(pNbVisisteurs) + FraisParChalet(pTypeChalet);


        }
        public decimal FraisParChalet(TypeChalet pTypeChalet)
        {
            decimal frais = 0;
           
            switch (pTypeChalet)
            {
                case TypeChalet.AUCUN:
                    frais = 0;
                    break;
                case TypeChalet.COMPACT:
                    frais = m_fraisChaletCompact;
                    break;
                case TypeChalet.ECHO:
                    frais = m_fraisChaletEcho;
                    break;
                case TypeChalet.HORIZON:
                    frais = m_fraisChaletHorizon;
                    break;
                case TypeChalet.NATURE:
                    frais = m_fraisChaletNature;
                    break;
                case TypeChalet.OXYGENE:
                    frais = m_fraisChaletOxygene;
                    break;
                
            }
            return frais;
        }

        public decimal FraisVisiteurs(int pNbVisiteurs)
        {

            return pNbVisiteurs * FRAIS_PAR_VISITEUR;

           
        }

       
       
        public void ReserverChalet(TypeChalet pTypeChalet)
        {
            if (!TypeChaletEstDisponible(pTypeChalet))
            {
                throw new InvalidOperationException();
            }

            m_tabNbChaletsDisponibles[(int)pTypeChalet]--;
        }
        #endregion

    }
}
