﻿//===================================================================
// Pour activer une région de tests, enlever les deux // du commentaire
#define TestsCompilationCamping
#define TestsFonctionementCamping

#define TestsCompilationBilleterie
#define TestsFonctionnementBilleterie

using FormatifQ1;
using System.Windows.Forms;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.IO;
namespace TestAppCamping
{

    [TestClass()]
    public class Correcteur
    {
        public static string m_version = "Correcteur H21.1.1";

        #region Propriété et Attributs de tests supplémentaires
        private TestContext testContextInstance;

        /// <summary>
        ///Obtient ou définit le contexte de test qui fournit
        ///des informations sur la série de tests active ainsi que ses fonctionnalités.
        ///</summary>
        public TestContext TestContext
        {
            get { return testContextInstance; }
            set { testContextInstance = value; }
        }

        private static int m_totalScore;
        private static int m_maxScore;
        //private static System.Random m_objRandom = new System.Random();
        //Utilisez ClassInitialize pour exécuter du code avant d'exécuter le premier test dans la classe
        [ClassInitialize()]
        public static void MyClassInitialize(TestContext testContext)
        {
            m_totalScore = 0;
            m_maxScore = 0;
        }
        //
        //Utilisez ClassCleanup pour exécuter du code après que tous les tests ont été exécutés dans une classe
        [ClassCleanup()]
        public static void MyClassCleanup()
        {
            StreamWriter ficScore = new StreamWriter("../../../Score.txt");
            ficScore.Write(FrmPrincipal.APP_INFO + "\n");
            ficScore.Write(DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"));
            ficScore.Write("\nRésultat de la correction\nScore : " + m_totalScore + "/" + m_maxScore, Correcteur.m_version, MessageBoxButtons.OK, MessageBoxIcon.Information);
            ficScore.Close();
            //MessageBox.Show("Résultat de la correction\nScore : " + m_totalScore + "/" + m_maxScore, Correcteur.m_version, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        //
        //Utilisez TestInitialize pour exécuter du code avant d'exécuter chaque test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Utilisez TestCleanup pour exécuter du code après que chaque test a été exécuté
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion

        #region Tests classe Camping
#if TestsCompilationCamping

        /// <summary>
        ///Test la déclaration de différents éléments de la classe ClsCamping
        ///Les instructions du test de devraient pas provoquer d'exceptions
        ///Ici on ne test pas le fonctionnement des éléments.
        ///</summary>
        [TestMethod()]
        public void T01_CompilationCamping()
        {
            m_maxScore += 10;
            Camping target = null;   
            try
            {           
                //constructeur
                target = new Camping(90,110,130,150,170);

                // Les champs (variables privées) sont inaccessibles donc pas vérifiées ici
                // Constantes
                int nombre = Camping.NB_MAX_CHALETS_PAR_TYPE;
                decimal fraisParVisiteur = Camping.FRAIS_PAR_VISITEUR;
                int[] tab = target.m_tabNbChaletsDisponibles;

                //propriété get
                decimal varDecimal = target.FraisChaletCompact;
                varDecimal = target.FraisChaletEcho;
                varDecimal = target.FraisChaletHorizon;
                varDecimal = target.FraisChaletNature;
                varDecimal = target.FraisChaletOxygene;

                // Méthode avec paramètre valide

                bool estDisponible = target.TypeChaletEstDisponible(TypeChalet.COMPACT);
                int nbChalets = target.NbChaletsDisponibles(TypeChalet.COMPACT);
                decimal total = target.TotalAPayer(TypeChalet.COMPACT, 2);

                decimal frais = target.FraisParChalet(TypeChalet.COMPACT);
                decimal fraisVisiteurs = target.FraisVisiteurs(2);
                target.ReserverChalet(TypeChalet.COMPACT);

            }
            catch (Exception)
            {
                // Une exception a été levée dans le programme testé mais n'a pas de concéquence dans ce test
            }
            m_totalScore += 10;
        }




#endif
#if TestsFonctionementCamping
        /// <summary>
        /// Test pour Constructeur Camping avec getter et setter
        ///</summary>
        [TestMethod()]
        public void T02_CampingConstructeurEtPropriétés()
        {
            m_maxScore += 5;
            Camping target = new Camping(90, 110, 130, 150, 170);
            // Test Constructeur avec valeur normale ----------------------------------------------------
            //PriseDeCourant target = new PriseDeCourant(objCompteurHydro);

            // On test les propriétés avec get
            Assert.AreEqual(90, target.FraisChaletCompact);
            Assert.AreEqual(110, target.FraisChaletEcho);
            Assert.AreEqual(130, target.FraisChaletHorizon);
            Assert.AreEqual(150, target.FraisChaletNature);
            Assert.AreEqual(170, target.FraisChaletOxygene);

            Assert.AreEqual(4, Camping.NB_MAX_CHALETS_PAR_TYPE);
            for (int index = 0; index < target.m_tabNbChaletsDisponibles.Length; index++)
            {
                Assert.AreEqual(Camping.NB_MAX_CHALETS_PAR_TYPE, target.m_tabNbChaletsDisponibles[index]);
            }




            m_totalScore += 5;
        }
        /// <summary>
        ///Test pour Constructeur Camping avec Exception
        ///</summary>
        [TestMethod()]
        public void T03_CampingConstructeurExceptionFrais()
        {
            m_maxScore += 5;


            for (int index = 0; index < 5; index++)
            {
                int[] tabFrais = { 100, 100, 100, 100, 100 };
                tabFrais[index] = -100;
                try
                {
                    Camping target = new Camping(tabFrais[0], tabFrais[1], tabFrais[2], tabFrais[3], tabFrais[4]);
                    Assert.Fail("ArgumentOutOfRangeException attendue");
                }
                catch (ArgumentOutOfRangeException)
                {

                    m_totalScore += 1;
                }
                catch (Exception)
                {
                    Assert.Fail("ArgumentOutOfRangeException attendue");
                }
            }


        }
        /// <summary>
        ///Test pour la méthode FraisParChalet
        ///</summary>
        [TestMethod()]
        public void T04_CampingFraisParChalet()
        {
            m_maxScore += 5;
            Camping target = new Camping(90, 110, 130, 150, 170);
           
            
            Assert.AreEqual(0, target.FraisParChalet(TypeChalet.AUCUN));
            Assert.AreEqual(90, target.FraisParChalet(TypeChalet.COMPACT));
            Assert.AreEqual(110, target.FraisParChalet(TypeChalet.ECHO));
            Assert.AreEqual(130, target.FraisParChalet(TypeChalet.HORIZON));
            Assert.AreEqual(150, target.FraisParChalet(TypeChalet.NATURE));
            Assert.AreEqual(170, target.FraisParChalet(TypeChalet.OXYGENE));
            Assert.AreEqual(0, target.FraisParChalet((TypeChalet)9));


            m_totalScore += 5;

        }
        /// <summary>
        ///Test pour la méthode FraisVisisteurs
        ///</summary>
        [TestMethod()]
        public void T05_CampingFraisVisiteurs()
        {
            m_maxScore += 5;
            Camping target = new Camping(90, 110, 130, 150, 170);
         
            Assert.AreEqual(Camping.FRAIS_PAR_VISITEUR * 1, target.FraisVisiteurs(1));

            Assert.AreEqual(Camping.FRAIS_PAR_VISITEUR * 10, target.FraisVisiteurs(10));



            m_totalScore += 5;

        }
        /// <summary>
        ///Test pour la méthode NbChaletsDisponibles
        ///</summary>
        [TestMethod()]
        public void T06_CampingNbChaletsDisponibles()
        {
            m_maxScore += 5;
            Camping target = new Camping(90, 110, 130, 150, 170);
            
            Assert.AreEqual(0, target.NbChaletsDisponibles(TypeChalet.AUCUN));
            Assert.AreEqual(Camping.NB_MAX_CHALETS_PAR_TYPE, target.NbChaletsDisponibles(TypeChalet.COMPACT));
            Assert.AreEqual(Camping.NB_MAX_CHALETS_PAR_TYPE, target.NbChaletsDisponibles(TypeChalet.ECHO));
            Assert.AreEqual(Camping.NB_MAX_CHALETS_PAR_TYPE, target.NbChaletsDisponibles(TypeChalet.HORIZON));
            Assert.AreEqual(Camping.NB_MAX_CHALETS_PAR_TYPE, target.NbChaletsDisponibles(TypeChalet.NATURE));
            Assert.AreEqual(Camping.NB_MAX_CHALETS_PAR_TYPE, target.NbChaletsDisponibles(TypeChalet.OXYGENE));




            m_totalScore += 5;

        }
        /// <summary>
        ///Test pour la méthode TypeChaletEstDisponible
        ///</summary>
        [TestMethod()]
        public void T07_CampingTypeChaletEstDisponible()
        {
            m_maxScore += 5;
            Camping target = new Camping(90, 110, 130, 150, 170);
           
            Assert.AreEqual(false, target.TypeChaletEstDisponible(TypeChalet.AUCUN));
            Assert.AreEqual(true, target.TypeChaletEstDisponible(TypeChalet.COMPACT));
            Assert.AreEqual(true, target.TypeChaletEstDisponible(TypeChalet.ECHO));
            Assert.AreEqual(true, target.TypeChaletEstDisponible(TypeChalet.HORIZON));
            Assert.AreEqual(true, target.TypeChaletEstDisponible(TypeChalet.NATURE));
            Assert.AreEqual(true, target.TypeChaletEstDisponible(TypeChalet.OXYGENE));
            Assert.AreEqual(false, target.TypeChaletEstDisponible((TypeChalet) 9));


            m_totalScore += 5;

        }

        /// <summary>
        ///Test pour la méthode TotalAPayer
        ///</summary>
        [TestMethod()]
        public void T08_CampingTotalAPayer()
        {
            m_maxScore += 5;
            Camping target = new Camping(90, 110, 130, 150, 170);
            
            decimal total = target.TotalAPayer(TypeChalet.COMPACT, 2);

            Assert.AreEqual(target.FraisChaletCompact + Camping.FRAIS_PAR_VISITEUR * 2, total);

            total = target.TotalAPayer(TypeChalet.ECHO, 2);

            Assert.AreEqual(target.FraisChaletEcho + Camping.FRAIS_PAR_VISITEUR * 2, total);

            total = target.TotalAPayer(TypeChalet.HORIZON, 2);

            Assert.AreEqual(target.FraisChaletHorizon + Camping.FRAIS_PAR_VISITEUR * 2, total);

            total = target.TotalAPayer(TypeChalet.NATURE, 2);

            Assert.AreEqual(target.FraisChaletNature + Camping.FRAIS_PAR_VISITEUR * 2, total);

            total = target.TotalAPayer(TypeChalet.OXYGENE, 2);

            Assert.AreEqual(target.FraisChaletOxygene + Camping.FRAIS_PAR_VISITEUR * 2, total);

            total = target.TotalAPayer(TypeChalet.AUCUN, 2);

            Assert.AreEqual(0, total);

            total = target.TotalAPayer((TypeChalet) 9, 2);

            Assert.AreEqual(0, total);


            m_totalScore += 5;

        }


        /// <summary>
        ///Test pour la méthode ReserverChalet
        ///</summary>
        [TestMethod()]
        public void T09_CampingReserverChalet()
        {
            m_maxScore += 5;
            Camping target = new Camping(90, 110, 130, 150, 170);
           
            target.ReserverChalet(TypeChalet.COMPACT);

            Assert.AreEqual(Camping.NB_MAX_CHALETS_PAR_TYPE - 1, target.NbChaletsDisponibles(TypeChalet.COMPACT));
            target.ReserverChalet(TypeChalet.ECHO);

            Assert.AreEqual(Camping.NB_MAX_CHALETS_PAR_TYPE - 1, target.NbChaletsDisponibles(TypeChalet.ECHO));
            target.ReserverChalet(TypeChalet.HORIZON);

            Assert.AreEqual(Camping.NB_MAX_CHALETS_PAR_TYPE - 1, target.NbChaletsDisponibles(TypeChalet.HORIZON));

            target.ReserverChalet(TypeChalet.NATURE);

            Assert.AreEqual(Camping.NB_MAX_CHALETS_PAR_TYPE - 1, target.NbChaletsDisponibles(TypeChalet.NATURE));

            target.ReserverChalet(TypeChalet.OXYGENE);

            Assert.AreEqual(Camping.NB_MAX_CHALETS_PAR_TYPE - 1, target.NbChaletsDisponibles(TypeChalet.OXYGENE));




            m_totalScore += 5;

        }

        /// <summary>
        ///Test pour la méthode ReserverChalet
        ///</summary>
        [TestMethod()]
        public void T10_CampingReserverChaletException()
        {
            m_maxScore += 5;
            Camping target = new Camping(90, 110, 130, 150, 170);
          

            try
            {
                target.ReserverChalet((TypeChalet) 9);
                Assert.Fail("InvalidOperationException attendue");
            }
            catch (InvalidOperationException)
            {

                m_totalScore += 1;
            }
            catch (Exception)
            {
                Assert.Fail("InvalidOperationException attendue");
            }

            try
            {
                target.ReserverChalet((TypeChalet.AUCUN));
                Assert.Fail("InvalidOperationException attendue");
            }
            catch (InvalidOperationException)
            {

                m_totalScore += 1;
            }
            catch (Exception)
            {
                Assert.Fail("InvalidOperationException attendue");
            }

           
            target.ReserverChalet(TypeChalet.COMPACT);
            target.ReserverChalet(TypeChalet.COMPACT);
            target.ReserverChalet(TypeChalet.COMPACT);
            target.ReserverChalet(TypeChalet.COMPACT);
            Assert.AreEqual(false, target.TypeChaletEstDisponible(TypeChalet.COMPACT));
            try
            {
                target.ReserverChalet(TypeChalet.COMPACT);
                Assert.Fail("InvalidOperationException attendue");
            }
            catch (InvalidOperationException)
            {

                m_totalScore += 1;
            }
            catch (Exception)
            {
                Assert.Fail("InvalidOperationException attendue");
            }

            target.ReserverChalet(TypeChalet.ECHO);
            target.ReserverChalet(TypeChalet.ECHO);
            target.ReserverChalet(TypeChalet.ECHO);
            target.ReserverChalet(TypeChalet.ECHO);
            Assert.AreEqual(false, target.TypeChaletEstDisponible(TypeChalet.ECHO));
            try
            {
                target.ReserverChalet(TypeChalet.ECHO);
                Assert.Fail("InvalidOperationException attendue");
            }
            catch (InvalidOperationException)
            {

                m_totalScore += 1;
            }
            catch (Exception)
            {
                Assert.Fail("InvalidOperationException attendue");
            }
            target.ReserverChalet(TypeChalet.HORIZON);
            target.ReserverChalet(TypeChalet.HORIZON);
            target.ReserverChalet(TypeChalet.HORIZON);
            target.ReserverChalet(TypeChalet.HORIZON);
            Assert.AreEqual(false, target.TypeChaletEstDisponible(TypeChalet.HORIZON));
            try
            {
                target.ReserverChalet(TypeChalet.HORIZON);
                Assert.Fail("InvalidOperationException attendue");
            }
            catch (InvalidOperationException)
            {

                m_totalScore += 1;
            }
            catch (Exception)
            {
                Assert.Fail("InvalidOperationException attendue");
            }
            target.ReserverChalet(TypeChalet.NATURE);
            target.ReserverChalet(TypeChalet.NATURE);
            target.ReserverChalet(TypeChalet.NATURE);
            target.ReserverChalet(TypeChalet.NATURE);
            Assert.AreEqual(false, target.TypeChaletEstDisponible(TypeChalet.NATURE));
            try
            {
                target.ReserverChalet(TypeChalet.NATURE);
                Assert.Fail("InvalidOperationException attendue");
            }
            catch (InvalidOperationException)
            {

                m_totalScore += 1;
            }
            catch (Exception)
            {
                Assert.Fail("InvalidOperationException attendue");
            }

            target.ReserverChalet(TypeChalet.OXYGENE);
            target.ReserverChalet(TypeChalet.OXYGENE);
            target.ReserverChalet(TypeChalet.OXYGENE);
            target.ReserverChalet(TypeChalet.OXYGENE);
            Assert.AreEqual(false, target.TypeChaletEstDisponible(TypeChalet.OXYGENE));
            try
            {
                target.ReserverChalet(TypeChalet.OXYGENE);
                Assert.Fail("InvalidOperationException attendue");
            }
            catch (InvalidOperationException)
            {

                m_totalScore += 1;
            }
            catch (Exception)
            {
                Assert.Fail("InvalidOperationException attendue");
            }

            try
            {
                target.ReserverChalet(TypeChalet.AUCUN);
                Assert.Fail("InvalidOperationException attendue");
            }
            catch (InvalidOperationException)
            {

                m_totalScore += 1;
            }
            catch (Exception)
            {
                Assert.Fail("InvalidOperationException attendue");
            }

            m_totalScore += 5;

        }
#endif
        #endregion

        #region Tests classe Billeterie
        //************************************************************************************************
        //************************************************************************************************
#if TestsCompilationBilleterie
        /// <summary>
        /// Test la déclaration de différents éléments de la classe ClsBilleterie
        /// Ici on ne test pas le fonctionnement des éléments.
        ///</summary>
        [TestMethod()]
        public void T11_CompilationBilleterie()
        {
            m_maxScore += 10;

            Camping objCamping = new Camping(90,110,130,150,170);
            Billeterie target = null;
            // Test Constructeur------------------
            try
            {
                target = new Billeterie(objCamping);
                // Vérifie l'accès aux propriétés get
                TypeChalet  enuChalet = target.ChaletChoisi;
                Camping objCampingTest = target.CampingChoisi;
                int nbVisiteurs = target.NbVisiteursChoisi;
                bool Estdisponible = target.ChaletChoisiEstDisponible;
                decimal frais = target.FraisChaletChoisi;
                frais = target.FraisVisiteurs;
                decimal total = target.TotalAPayer;

                // Vérifie l'accès aux propriétés set
                target.ChaletChoisi = TypeChalet.COMPACT;
                target.CampingChoisi = objCamping;
                target.NbVisiteursChoisi = 5;


                // Vérifie l'accès aux méthodes
                

                target.ReserverChaletChoisi();
                

               
            }
            catch (Exception)
            {
                //Une exception a été levée dans le programme testé mais la compilation passe donc OK
            }
            m_totalScore += 7;
           
        }
#endif

#if TestsFonctionnementBilleterie
       

        /// <summary>
        /// Test pour le constructeur de Billeterie
        ///</summary>
        [TestMethod()]
        public void T12_BilleterieConstructeur()
        {
            m_maxScore += 3;

            Camping objCamping = new Camping(90, 110, 130, 150, 170);
            Billeterie target = new Billeterie(objCamping);

            Assert.AreSame(objCamping, target.CampingChoisi);
            Assert.AreEqual(TypeChalet.AUCUN, target.ChaletChoisi);
            Assert.AreEqual(0, target.NbVisiteursChoisi);
            m_totalScore += 3;
        }
        /// <summary>
        /// Test pour le constructeur de Billeterie
        ///</summary>
        [TestMethod()]
        public void T13_BilleterieConstructeurException()
        {
            m_maxScore += 3;

            try
            {
                Billeterie target = new Billeterie(null);
                Assert.Fail("ArgumentNullException attendue");
            }
            catch (ArgumentNullException)
            {

                m_totalScore += 3;
            }
            catch (Exception)
            {
                Assert.Fail("ArgumentNullException attendue");
            }
           

           
            m_totalScore += 3;
        }
        /// <summary>
        /// Test pour le constructeur de Billeterie
        ///</summary>
        [TestMethod()]
        public void T14_BilleterieChaletChoisi()
        {
            m_maxScore += 3;
            Camping objCamping = new Camping(90, 110, 130, 150, 170);
            Billeterie target = new Billeterie(objCamping);
            target.ChaletChoisi = TypeChalet.COMPACT;

            Assert.AreEqual(TypeChalet.COMPACT, target.ChaletChoisi);
            
            try
            {
                target.ChaletChoisi = (TypeChalet)9;
                Assert.Fail("ArgumentException attendue");
            }
            catch (ArgumentException)
            {

                m_totalScore += 3;
            }
            catch (Exception)
            {
                Assert.Fail("ArgumentException attendue");
            }



            m_totalScore += 3;
        }
        /// <summary>
        /// Test pour le constructeur de Billeterie
        ///</summary>
        [TestMethod()]
        public void T15_BilleterieNbVisiteursChoisi()
        {
            m_maxScore += 3;
            Camping objCamping = new Camping(90, 110, 130, 150, 170);
            Billeterie target = new Billeterie(objCamping);
            target.NbVisiteursChoisi = 5;

            Assert.AreEqual(5, target.NbVisiteursChoisi);

            try
            {
                target.NbVisiteursChoisi = -10;
                Assert.Fail("ArgumentException attendue");
            }
            catch (ArgumentException)
            {

                m_totalScore += 3;
            }
            catch (Exception)
            {
                Assert.Fail("ArgumentException attendue");
            }



            m_totalScore += 3;
        }
        /// <summary>
        /// Test pour le constructeur de Billeterie
        ///</summary>
        [TestMethod()]
        public void T16_BilleterieChaletChoisiEstDisponible()
        {
            m_maxScore += 3;
            Camping objCamping = new Camping(90, 110, 130, 150, 170);
            Billeterie target = new Billeterie(objCamping);
            target.ChaletChoisi = TypeChalet.AUCUN;
            Assert.AreEqual(false, target.ChaletChoisiEstDisponible);
            target.ChaletChoisi = TypeChalet.COMPACT;
            Assert.AreEqual(true, target.ChaletChoisiEstDisponible);
            target.ChaletChoisi = TypeChalet.ECHO;
            Assert.AreEqual(true, target.ChaletChoisiEstDisponible);
            target.ChaletChoisi = TypeChalet.HORIZON;
            Assert.AreEqual(true, target.ChaletChoisiEstDisponible);
            target.ChaletChoisi = TypeChalet.NATURE;
            Assert.AreEqual(true, target.ChaletChoisiEstDisponible);
            target.ChaletChoisi = TypeChalet.OXYGENE;
            Assert.AreEqual(true, target.ChaletChoisiEstDisponible);



            m_totalScore += 3;
        }
        /// <summary>
        /// Test pour le constructeur de Billeterie
        ///</summary>
        [TestMethod()]
        public void T17_BilleterieFraisChaletChoisi()
        {
            m_maxScore += 3;
            Camping objCamping = new Camping(90, 110, 130, 150, 170);
            Billeterie target = new Billeterie(objCamping);
            target.ChaletChoisi = TypeChalet.AUCUN;
            Assert.AreEqual(0, target.FraisChaletChoisi);
            target.ChaletChoisi = TypeChalet.COMPACT;
            Assert.AreEqual(objCamping.FraisChaletCompact, target.FraisChaletChoisi);
            target.ChaletChoisi = TypeChalet.ECHO;
            Assert.AreEqual(objCamping.FraisChaletEcho, target.FraisChaletChoisi);
            target.ChaletChoisi = TypeChalet.HORIZON;
            Assert.AreEqual(objCamping.FraisChaletHorizon, target.FraisChaletChoisi);
            target.ChaletChoisi = TypeChalet.NATURE;
            Assert.AreEqual(objCamping.FraisChaletNature, target.FraisChaletChoisi);
            target.ChaletChoisi = TypeChalet.OXYGENE;
            Assert.AreEqual(objCamping.FraisChaletOxygene, target.FraisChaletChoisi);
           


            m_totalScore += 3;
        }

        /// <summary>
        /// Test pour le constructeur de Billeterie
        ///</summary>
        [TestMethod()]
        public void T18_BilleterieFraisVisiteurs()
        {
            m_maxScore += 3;
            Camping objCamping = new Camping(90, 110, 130, 150, 170);
            Billeterie target = new Billeterie(objCamping);
            target.m_nbVisiteursChoisi = 0;
            Assert.AreEqual(0, target.FraisVisiteurs);
            target.m_nbVisiteursChoisi = 2;
            Assert.AreEqual(Camping.FRAIS_PAR_VISITEUR*2, target.FraisVisiteurs);



            m_totalScore += 3;
        }
        /// <summary>
        /// Test pour le constructeur de Billeterie
        ///</summary>
        [TestMethod()]
        public void T19_BilleterieTotalAPayer()
        {
            m_maxScore += 3;
            Camping objCamping = new Camping(90, 110, 130, 150, 170);
            Billeterie target = new Billeterie(objCamping);
            target.ChaletChoisi = TypeChalet.AUCUN;
            target.m_nbVisiteursChoisi = 2;
            Assert.AreEqual(0, target.TotalAPayer);

            target.ChaletChoisi = TypeChalet.COMPACT;
            target.m_nbVisiteursChoisi = 2;
            Assert.AreEqual(objCamping.FraisChaletCompact+Camping.FRAIS_PAR_VISITEUR*2, target.TotalAPayer);

            target.ChaletChoisi = TypeChalet.ECHO;
            target.m_nbVisiteursChoisi = 2;
            Assert.AreEqual(objCamping.FraisChaletEcho + Camping.FRAIS_PAR_VISITEUR * 2, target.TotalAPayer);

            target.ChaletChoisi = TypeChalet.HORIZON;
            target.m_nbVisiteursChoisi = 2;
            Assert.AreEqual(objCamping.FraisChaletHorizon + Camping.FRAIS_PAR_VISITEUR * 2, target.TotalAPayer);

            target.ChaletChoisi = TypeChalet.NATURE;
            target.m_nbVisiteursChoisi = 2;
            Assert.AreEqual(objCamping.FraisChaletNature + Camping.FRAIS_PAR_VISITEUR * 2, target.TotalAPayer);

            target.ChaletChoisi = TypeChalet.OXYGENE;
            target.m_nbVisiteursChoisi = 2;
            Assert.AreEqual(objCamping.FraisChaletOxygene + Camping.FRAIS_PAR_VISITEUR * 2, target.TotalAPayer);


            m_totalScore += 3;
        }

        /// <summary>
        ///Test pour la méthode ReserverChaletChoisi
        ///</summary>
        [TestMethod()]
        public void T20_CampingReserverChaletChoisi()
        {
            m_maxScore += 5;
            Camping objCamping = new Camping(90, 110, 130, 150, 170);
            Billeterie target = new Billeterie(objCamping);


            target.ChaletChoisi = TypeChalet.COMPACT;
            target.ReserverChaletChoisi();
            Assert.AreEqual(Camping.NB_MAX_CHALETS_PAR_TYPE - 1, objCamping.NbChaletsDisponibles(TypeChalet.COMPACT));

            target.ChaletChoisi = TypeChalet.ECHO;
            target.ReserverChaletChoisi();
            Assert.AreEqual(Camping.NB_MAX_CHALETS_PAR_TYPE - 1, objCamping.NbChaletsDisponibles(TypeChalet.ECHO));

            target.ChaletChoisi = TypeChalet.HORIZON;
            target.ReserverChaletChoisi();
            Assert.AreEqual(Camping.NB_MAX_CHALETS_PAR_TYPE - 1, objCamping.NbChaletsDisponibles(TypeChalet.HORIZON));

            target.ChaletChoisi = TypeChalet.NATURE;
            target.ReserverChaletChoisi();
            Assert.AreEqual(Camping.NB_MAX_CHALETS_PAR_TYPE - 1, objCamping.NbChaletsDisponibles(TypeChalet.NATURE));

            target.ChaletChoisi = TypeChalet.OXYGENE;
            target.ReserverChaletChoisi();
            Assert.AreEqual(Camping.NB_MAX_CHALETS_PAR_TYPE - 1, objCamping.NbChaletsDisponibles(TypeChalet.OXYGENE));


            m_totalScore += 5;

        }
        /// <summary>
        ///Test pour la méthode ReserverChaletChoisi
        ///</summary>
        [TestMethod()]
        public void T21_CampingReserverChaletChoisiException()
        {
            m_maxScore += 5;
            Camping objCamping = new Camping(90, 110, 130, 150, 170);
            Billeterie target = new Billeterie(objCamping);


            target.ChaletChoisi = TypeChalet.COMPACT;
            target.ReserverChaletChoisi();
            target.ReserverChaletChoisi();
            target.ReserverChaletChoisi();
            target.ReserverChaletChoisi();
            try
            {
                target.ReserverChaletChoisi();
                Assert.Fail("InvalidOperationException attendue");
            }
            catch (InvalidOperationException)
            {

                m_totalScore += 1;
            }
            catch (Exception)
            {
                Assert.Fail("InvalidOperationException attendue");
            }

            target.ChaletChoisi = TypeChalet.ECHO;
            target.ReserverChaletChoisi();
            target.ReserverChaletChoisi();
            target.ReserverChaletChoisi();
            target.ReserverChaletChoisi();
            try
            {
                target.ReserverChaletChoisi();
                Assert.Fail("InvalidOperationException attendue");
            }
            catch (InvalidOperationException)
            {

                m_totalScore += 1;
            }
            catch (Exception)
            {
                Assert.Fail("InvalidOperationException attendue");
            }
            target.ChaletChoisi = TypeChalet.HORIZON;
            target.ReserverChaletChoisi();
            target.ReserverChaletChoisi();
            target.ReserverChaletChoisi();
            target.ReserverChaletChoisi();
            try
            {
                target.ReserverChaletChoisi();
                Assert.Fail("InvalidOperationException attendue");
            }
            catch (InvalidOperationException)
            {

                m_totalScore += 1;
            }
            catch (Exception)
            {
                Assert.Fail("InvalidOperationException attendue");
            }
            target.ChaletChoisi = TypeChalet.NATURE;
            target.ReserverChaletChoisi();
            target.ReserverChaletChoisi();
            target.ReserverChaletChoisi();
            target.ReserverChaletChoisi();
            try
            {
                target.ReserverChaletChoisi();
                Assert.Fail("InvalidOperationException attendue");
            }
            catch (InvalidOperationException)
            {

                m_totalScore += 1;
            }
            catch (Exception)
            {
                Assert.Fail("InvalidOperationException attendue");
            }
            target.ChaletChoisi = TypeChalet.OXYGENE;
            target.ReserverChaletChoisi();
            target.ReserverChaletChoisi();
            target.ReserverChaletChoisi();
            target.ReserverChaletChoisi();
            try
            {
                target.ReserverChaletChoisi();
                Assert.Fail("InvalidOperationException attendue");
            }
            catch (InvalidOperationException)
            {

                m_totalScore += 1;
            }
            catch (Exception)
            {
                Assert.Fail("InvalidOperationException attendue");
            }


            target.ChaletChoisi = (TypeChalet.AUCUN);
            try
            {
                target.ReserverChaletChoisi();
                Assert.Fail("InvalidOperationException attendue");
            }
            catch (InvalidOperationException)
            {

                m_totalScore += 1;
            }
            catch (Exception)
            {
                Assert.Fail("InvalidOperationException attendue");
            }
            m_totalScore += 5;

        }
#endif
        #endregion
    }
}
