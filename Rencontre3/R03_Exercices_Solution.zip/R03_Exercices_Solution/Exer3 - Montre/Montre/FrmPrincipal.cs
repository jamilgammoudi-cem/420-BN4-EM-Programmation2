﻿using Librairie1N6;
using System.Windows.Forms;

namespace ApplicationMontre
{
    public partial class FrmPrincipal : Form
    {
        public const string APP_INFO = "(DÉMO)";

        // TODO 01 : Définir une variable pour un objet Montre
        private Montre m_objMontre;

        public FrmPrincipal()
        {
            InitializeComponent();
            Text += APP_INFO;

            // TODO 02A : Instancier une Montre à 10 heures, 45 minutes et 52 secondes
            m_objMontre = new Montre(10, 45, 52);

            // TODO 02B : Afficher le temps courant de la Montre
            lblTemps.Text = m_objMontre.TempsCourant;
        }
        //============================================================================
        private void mnuFichierQuitter_Click(object sender, System.EventArgs e)
        {
            Close();
        }
        //============================================================================
        private void MnuSpcialAvancerDuneSeconde_Click(object sender, System.EventArgs e)
        {
            // TODO 03A : Avancer le temps de la Montre d'une seconde
            m_objMontre.AvancerUneSeconde();
            // TODO 03B : Afficher le temps courant de la Montre
            lblTemps.Text = m_objMontre.TempsCourant;
        }
        //============================================================================
        private void MnuSpécialSynchroniser_Click(object sender, System.EventArgs e)
        {
            // TODO 04A : Synchroniser le temps de la Montre à l'aide de la méthode AjusterAutomatiquement
            m_objMontre.AjusterAutomatiquement();
            // TODO 04B : Afficher le temps courant de la Montre
            lblTemps.Text = m_objMontre.TempsCourant;
        }
        //============================================================================
        private void MnuSpécialDémarrer_Click(object sender, System.EventArgs e)
        {
            // TODO 05 : Modifier le texte du menu mnuSpécialDémarrer pour indiquer 
            //           "Démarrer" ou "Arrêter"
            //         : Démarrer ou arrêter le minuteur de l'horloge (tmrHorloge) en conséquence
            if (mnuSpécialDémarrer.Text == "Arrêter Horloge")
            {
                mnuSpécialDémarrer.Text = "Démarrer Horloge";
                tmrHorloge.Stop();
            }
            else
            {
                mnuSpécialDémarrer.Text = "Arrêter Horloge";
                tmrHorloge.Start();
            }
        }
        //============================================================================
        private void MnuSpécialFixer_Click(object sender, System.EventArgs e)
        {
            // TODO 06A : Modifier les propriétés appropriées 
            m_objMontre.Heures = 20;
            m_objMontre.Minutes = 45;
            m_objMontre.Secondes = 55;
            // TODO 06B : Afficher le temps courant de la Montre 
            lblTemps.Text = m_objMontre.TempsCourant;
        }
    }
}
