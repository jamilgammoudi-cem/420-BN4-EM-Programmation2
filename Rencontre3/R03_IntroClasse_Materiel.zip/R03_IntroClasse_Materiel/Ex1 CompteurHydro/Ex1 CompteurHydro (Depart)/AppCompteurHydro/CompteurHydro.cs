namespace AppCompteurHydro
{
    /// ------------------------------------------------------------------------------------
    /// <summary>
    /// Repr�sente un compteur hydro �lectrique 
    /// </summary>
    /// ------------------------------------------------------------------------------------
    public class CompteurHydro
    {
        // TODO 01 : Compl�ter cette classe en se basant sur le diagramme "Ex1 CompteurHydro.png"

    }
}
