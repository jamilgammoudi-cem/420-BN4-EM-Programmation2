﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace EditeurListeMots
{
    /// <summary>
    /// Concept : liste générique.
    /// Propriété : Count
    /// Méthode   : Add
    /// Cet exemple illustre comment stocker des mots dans une liste dynamique en utilisant un objet de type liste générique.
    /// </summary>
    public partial class FrmPrincipal : Form
    {
        //--- Les constantes ---
        const String NOM_ETUDIANT = "(Matériel)";

        //--- Les variables membres ---
        // m_colMots est une liste dynamique de string
        private List<String> m_colMots = new List<String>(); 

        private int m_indexMotCourant = -1;   // Au départ, il n'y a aucun mot dans la collection de mots m_colMots

        //==============================================================================================
        public FrmPrincipal()
        {
            InitializeComponent();
            Text += NOM_ETUDIANT;
            //---
            // TODO 01 : Ajouter les éléments suivants à la liste m_colMots
            //        "1- Auto","2- Avion","3- Camion","4- Train"





            // TODO 02 : Faites en sorte que le mot courant soit le premier mot de la liste et afficher-le à l'aide de la méthode AfficherMotCourant du TODO 3 


        }

        //==============================================================================================
        // TODO 03 : Afficher le mot courant et indiquer son index dans la zone numérique
        private void AfficherMotCourant()
        {


        }

        //==============================================================================================
        // TODO 04 : Afficher le mot suivant
        // Le suivant du dernier est le premier.
        private void btnSuivant_Click(object sender, EventArgs e)
        {


        }

        //==============================================================================================
        // TODO 05 : Afficher le mot précédent
        // Le précédent du premier est le dernier
        private void btnPrécédent_Click(object sender, EventArgs e)
        {


        }
        //==============================================================================================
        private void mnuFichierQuitter_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
