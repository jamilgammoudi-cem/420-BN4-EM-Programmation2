﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;

namespace EditeurListeMots
{
    /// <summary>
    /// Cet exemple est la suite de l'exemple précédent dans lequel on mémorise une liste de mots dans une liste dynamique.
    /// On ajoute les fonctionnalités suivantes :
    ///     - Ajout d'un mot
    ///     - Suppression d'un mot
    ///     - Vider la liste de mots
    ///     - Charger une liste de mots
    ///     - Enregistrer la liste des mots
    /// </summary>
    public partial class FrmPrincipal : Form
    {
        const String APP_INFO = "(Matériel)";
        const String NOM_FICHIER_DE_MOTS = "ListeDeMots.txt";

        private List<String> m_colMots = new List<String>(); // une liste dynamique de String
        private int m_indexMotCourant = -1;

        //==============================================================================================
        public FrmPrincipal()
        {
            InitializeComponent();
            Text += APP_INFO;
        }


        #region Code pour ajouter ou supprimer un mot
        //==============================================================================================
        // TODO 01 : Ajouter le mot en minuscule dans la liste dynamique.
        // Contraintes: Le mot est unique. Le mot est non vide.
        // Vous utiliserez des points d'arrêt pour vérifier le contenu de m_ColMots
        private void btnAjouterMot_Click(object sender, EventArgs e)
        {
            
        }
        //==============================================================================================
        // TODO 02 : Supprimer le mot de la liste et affiche le suivant ou le dernier
        //          Attention à la suppression du dernier élément
        //Vous utiliserez des points d'arrêt pour vérifier le contenu de m_ColMots
        private void btnSupprimerMot_Click(object sender, EventArgs e)
        {


        }

        //==============================================================================================
        private void numIndexMotCourant_ValueChanged(object sender, EventArgs e)
        {
            btnSupprimerMot.Enabled = numIndexMotCourant.Value != -1;
        }
        #endregion

        #region Code pour Charger,Vider et Enregistrer une liste de mots
        //==============================================================================================
        // TODO 03 : Vider la liste de mots en mémoire et ajuster l'affichage
        private void mnuFichierViderListeDeMots_Click(object sender, EventArgs e)
        {


        }

        //==============================================================================================
        // TODO 04 : Charger la liste dynamique m_colMots à partir du fichier  NOM_FICHIER_DE_MOTS
        // Vous utiliserez des points d'arrêt pour vérifier le contenu de m_ColMots
        private void mnuFichierChargerListeDeMots_Click(object sender, EventArgs e)
        {

        }

        //==============================================================================================
        // TODO 05 : Enregistrer la liste dynamique dans le fichier  NOM_FICHIER_DE_MOTS
        private void mnuFichierEnregistrerListeDeMots_Click(object sender, EventArgs e)
        {

        }
        #endregion

        #region Affichage et boutons Suivant Précédent
        //==============================================================================================
        // TODO 06 : Afficher le mot courant et indiquer son index dans la zone numérique
        //Vérifiez que les TODO1 jusqu'à TODO4 appellent bien la méthode AfficherMotCourant et que le tout fonctionne correctement
        private void AfficherMotCourant()
        {

        }

        //==============================================================================================
        // TODO 07 : Afficher le mot suivant
        // Remarque, le suivant du dernier est le premier.
        // Attention à la liste vide et n'oubliez pas de rafraichir l'affichage
        private void btnSuivant_Click(object sender, EventArgs e)
        {


        }

        //==============================================================================================
        // TODO 08 : Afficher le mot précédent
        // Remarque, le précédent du premier est le dernier
        // Attention à la liste vide et n'oubliez pas de rafraichir l'affichage
        private void btnPrécédent_Click(object sender, EventArgs e)
        {

        }

        //==============================================================================================
        private void mnuFichierQuitter_Click(object sender, EventArgs e)
        {
            Close();
        }
        #endregion

        
    }
}
