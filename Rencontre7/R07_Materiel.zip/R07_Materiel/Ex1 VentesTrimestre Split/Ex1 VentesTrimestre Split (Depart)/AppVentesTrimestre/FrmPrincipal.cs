﻿using System;
using System.Windows.Forms;
using System.IO;
using VisualArrays;

namespace AppVentesTrimestre
{
    /// <summary>
    /// Manipulation de tableaux à 2D
    ///              d'un fichier en lecture
    ///              d'un fichier en écriture
    /// </summary>
    public partial class FrmPrincipal : Form
    {
        public const string APP_INFO = "(Matériel)";

        // tableau pré-initialisé à 1D des mois
        private string[] m_tabMois = { "Janvier", "Février", "Mars" };

        // tableau pré-initialisé à 1D des villes
        private string[] m_tabVilles = { "Boucherville", "Laval", "Longueuil", "Montréal" };


        //---------------------------------------------------------------------------------
        public FrmPrincipal()
        {
            InitializeComponent();
            Text += APP_INFO;
            PréparerLesEntêtesDesGrilles();
        }

        #region Préparation des grilles
        //---------------------------------------------------------------------------------
        /// <summary>
        /// Place, par programmation, les en-têtes des rangées et des colonnes
        /// vdaVentes.RowHeaderArray[index]
        /// vdaVentes.ColumnHeaderArray[index]
        /// </summary>
        private void PréparerLesEntêtesDesGrilles()
        {
            for (int index = 0; index < vdaVentes.RowCount; index++)
            {
                vdaVentes.RowHeaderArray[index] = m_tabVilles[index];
            }

            for (int index = 0; index < vdaVentes.ColumnCount; index++)
            {
                vdaVentes.ColumnHeaderArray[index] = m_tabMois[index];
            }

            vdaTotauxParMois.RowHeaderArray[0] = "Totaux / Mois";
            vdaTotauxVilles.ColumnHeaderArray[0] = "Totaux / Villes";
        }
        #endregion

        #region Options du menu Fichier
        //---------------------------------------------------------------------------------
        /// <summary>
        /// TODO 01: Vide le contenu de la grille des ventes
        /// </summary>		
        private void mnuFichierNouveau_Click(object sender, EventArgs e)
        {

        }

        //====================================================================================
        /// <summary>
        /// TODO 02: Enregistre le contenu de vdaVentes dans le fichier "Données.txt" 
        /// </summary>
        private void mnuFichierEnregistrer_Click(object sender, EventArgs e)
        {


        }

        /// <summary>
        /// TODO 03: Charge le contenu du fichier "Données.txt" dans vdaVentes 
        /// </summary>
        private void mnuFichierCharger_Click(object sender, EventArgs e)
        {


        }
        //---------------------------------------------------------------------------------
        private void mnuFichierQuitter_Click(object sender, EventArgs e)
        {
            Close();
        }
        #endregion

        #region Méthodes pour calculer les sommes
        //---------------------------------------------------------------------------------
        /// <summary>
        /// TODO 04: Calcule la somme d'une colonne de vdaVentes
        /// </summary>
        /// <param name="pColonne">index de la colonne à traiter</param>
        /// <returns>Retourne la somme de la colonne</returns>
        private decimal SommeDeLaColonne(int pColonne)
        {

            return 0;
        }
        //---------------------------------------------------------------------------------
        /// <summary>
        /// TODO 05: Calcule la somme d'une rangée de vdaVentes
        /// </summary>
        /// <param name="pRangée">index de la rangée à traiter</param>
        /// <returns>Retourne la somme de la rangée</returns>
        private decimal SommeDeLaRangée(int pRangée)
        {

            return 0;
        }
        //---------------------------------------------------------------------------------
        /// <summary>
        /// TODO 06: Calcule le grand total de toutes les ventes dans vdaVentes
        /// </summary>
        /// <returns>Retourne la somme de toutes les cases de vdaVentes </returns>
        private decimal GrandTotal()
        {

            return 0;
        }
        #endregion

        #region Événement ValueChanged
        //---------------------------------------------------------------------------------
        // Mise à jour des totaux.
        // Deux origines possibles du ValueChanged:
        // Premier cas:  un clic (par l'utilisateur) dans une cellule pour modifier le contenu
        //               dans ce cas le paramètre e.Address aura une valeur autre que Address.Empty
        //               on mettra à jour seulement les totaux affectés par cette cellule.
        // Deuxième cas: un changement de valeur  par programmation par le programmeur
        private void vdaVentes_ValueChanged(object sender, ValueChangedEventArgs e)
        {
            if (e.Address != Address.Empty) //Valeur changée par un clic sur la cellule
            {
                vdaTotauxParMois[e.Column] = SommeDeLaColonne(e.Column);
                vdaTotauxVilles[e.Row] = SommeDeLaRangée(e.Row);
            }
            else // Valeur changée par programmation,
                // dans ce cas il faut tout mettre à jour
            {
                for (int rangée = 0; rangée < vdaVentes.RowCount; rangée++)
                {
                    vdaTotauxVilles[rangée] = SommeDeLaRangée(rangée);
                }
                for (int colonne = 0; colonne < vdaVentes.ColumnCount; colonne++)
                {
                    vdaTotauxParMois[colonne] = SommeDeLaColonne(colonne);
                }
            }

            vsdGrandTotal.Value = GrandTotal();
        }
        #endregion

    }
}
