﻿using System;
using System.Windows.Forms;
using System.IO;

namespace EditeurListeMots
{
    /// <summary>
    /// Introduction au ListBox 
    ///     - Propriétés Items et méthodes Add, Remove, Contains
    ///     - Propriété SelectedIndex et événement SelectedIndexChanged
    /// </summary>
    public partial class FrmPrincipal : Form
    {
        const string APP_INFOS = "(DÉMO)";
        //==============================================================================================
        public FrmPrincipal()
        {
            InitializeComponent();
            Text += APP_INFOS;
        }

        //==============================================================================================
        //TODO 1: Ajouter un mot , en caractères minuscules, dans le listBox
        //Le mot doit être unique
        private void btnAjouterMot_Click(object sender, EventArgs e)
        {
            string nouveauMot = txtNouveauMot.Text.ToLower();
            if (nouveauMot.Length > 0 && !lstMots.Items.Contains(nouveauMot)) // Pour ne pas ajouter le même mot plusieurs fois
            {
                lstMots.Items.Add(nouveauMot);

                txtNouveauMot.Clear();
                txtNouveauMot.Select();
            }
        }
        //==============================================================================================
        //TODO 2 : Retirer le mot sélectionné du listBox
        private void btnSupprimerMot_Click(object sender, EventArgs e)
        {
            lstMots.Items.Remove(lstMots.SelectedItem);
        }

        //==============================================================================================
        //TODO 3: Rendre disponible le bouton btnSupprimerMot selon le contexte.
        private void lstMots_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnSupprimerMot.Enabled = lstMots.SelectedIndex != -1;
            txtSelectedIndex.Text = lstMots.SelectedIndex.ToString();
        }

        //==============================================================================================
        private void mnuFichierQuitter_Click(object sender, EventArgs e)
        {
            Close();
        }
        //==============================================================================================
        private void BtnViderListe_Click(object sender, EventArgs e)
        {
            lstMots.Items.Clear();
        }
        //==============================================================================================
        private void BtnLireListe_Click(object sender, EventArgs e)
        {
            StreamReader objFichier = new StreamReader("ListeDeMots.txt");

            lstMots.Items.Clear(); // pour vider la liste

            while (!objFichier.EndOfStream)
            {
                string ligne = objFichier.ReadLine();
                lstMots.Items.Add(ligne);
            }
            objFichier.Close();
        }

        //==============================================================================================
        private void BtnEnregistrerListe_Click(object sender, EventArgs e)
        {
            StreamWriter objFichier = new StreamWriter("ListeDeMots.txt");

            for (int index = 0; index < lstMots.Items.Count; index++)
            {
                objFichier.WriteLine(lstMots.Items[index]);
            }

            objFichier.Close();
        }
    }
}
