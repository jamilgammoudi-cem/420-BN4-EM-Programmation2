﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ManipulationsCollection
{
    public partial class Form1 : Form
    {

        Random objRandom = new Random();
        List<int> m_colNombres = new List<int>();
        public Form1()
        {
            InitializeComponent();
        }
        #region Gestion du formulaire NE PAS MODIFIER
        private void btnRemplir_Click(object sender, EventArgs e)
        {
            lstNombresFiltree.Items.Clear();
            RemplirAleatoirementUneCollection(m_colNombres);
            AfficherCollectionDansListBox(m_colNombres, lstNombres);

            AfficherStats();
        }

       

        private void btnFiltrer1_Click(object sender, EventArgs e)
        {
           

            List<int> liste = FiltrerSelonSeuilMinimalV1(m_colNombres, 50);
            AfficherCollectionDansListBox(liste, lstNombresFiltree);
        }

        private void btnFiltrer2_Click(object sender, EventArgs e)
        {
            FiltrerSelonSeuilMinimalV2(m_colNombres, 50);
            AfficherCollectionDansListBox(m_colNombres, lstNombresFiltree);
            AfficherCollectionDansListBox(m_colNombres, lstNombres);
        }
        private void AfficherStats()
        {
            txtValeurMaximale.Text = ValeurMaximale(m_colNombres).ToString();
            txtTotal.Text = Total(m_colNombres).ToString();
            txtMoyenne.Text = Moyenne(m_colNombres).ToString("F2");
            txtNbValeursSupSeuil.Text = NombreDeValeursSupSeuil(m_colNombres, 50).ToString();
        }

        #endregion


        #region Méthodes pour remplir une collection et afficher son contenu dans un ListBox
        // TODO 01 : Définir une méthode appelée RemplirAleatoirementUneCollection qui :
        // - Reçoit/accepte en paramètre une collection d'entiers (vide)
        // - Remplit la collection par 10 entiers générés aléatoirement entre 0 et 100
        // Utiliser objRandom.Next(100) pour générer un entier entre 0 et 100
        private void RemplirAleatoirementUneCollection(List<int> pColNombres)
        {
           
            m_colNombres.Clear();
            for (int index = 0; index < 10; index++)
            {
                int nombreAleatoire = objRandom.Next(100);
                pColNombres.Add(nombreAleatoire);
            }

        }

        // TODO 02 : Définir une méthode appelée AfficherCollectionDansListBox qui :
        // - Reçoit/accepte en paramètre une collection d'entiers et un ListBox
        // - Affiche les éléments de la collection dans le ListBox
       

        private void AfficherCollectionDansListBox(List<int> pColNombres, ListBox pListBox)
        {
            
            pListBox.Items.Clear();
            foreach (int nombre in pColNombres)
            {

                pListBox.Items.Add(nombre.ToString());
            }

        }
        #endregion



        #region  Méthodes de calcul des statistiques

        // TODO 03 : Définir une méthode appelée Total qui :
        // - Reçoit/accepte en paramètre une collection d'entiers 
        // - Calcule et retourne la somme des éléments de la collection

        private int Total(List<int> pColNombres)
        {
            int somme = 0;
            foreach (int nombre in pColNombres)
            {
                somme += nombre;
            }
            return somme;
        }

        // TODO 04 : Définir une méthode appelée Moyenne qui :
        // - Reçoit/accepte en paramètre une collection d'entiers 
        // - Calcule et retourne la moyenne (en double) des éléments de la collection
        // Vous pouvez utiliser la méthode Total définie plus haut!
        private double Moyenne(List<int> pColNombres)
        {
            int somme = Total(pColNombres);
           
            double moyenne = (double)somme / pColNombres.Count;
            return moyenne;
        }

        // TODO 05 : Définir une méthode appelée ValeurMaximale qui :
        // - Reçoit/accepte en paramètre une collection d'entiers 
        // - Calcule et retourne la valeur maximale dans la collection
       
        private int ValeurMaximale(List<int> pColNombres)
        {
            int max = int.MinValue;
            foreach (int nombre in pColNombres)
            {
                if (nombre > max)
                {
                    max = nombre;
                }
            }
            return max;
        }

        // TODO 06 : Définir une méthode appelée NombreDeValeursSupSeuil qui :
        // - Reçoit/accepte en paramètre une collection d'entiers et un entier pSeuilMinimal
        // - Calcule et retourne le nombre de valeurs de la collection qui sont au dessus ou égal à pSeuilMinimal

        private int NombreDeValeursSupSeuil(List<int> pColNombres, int pSeuilMinimal)
        {
            int nbValeurs = 0;
            foreach (int nombre in pColNombres)
            {
                if (nombre >= pSeuilMinimal)
                {
                    nbValeurs++;
                }
            }
            return nbValeurs;
        }

        #endregion

        #region Méthodes pour filtrer une collection

        // TODO 07 : Définir une méthode appelée FiltrerSelonSeuilMinimalV1 qui :
        // - Reçoit/accepte en paramètre une collection d'entiers et un entier pSeuilMinimal
        // - Retourne dans une nouvelle collection les valeurs qui sont au dessus ou égal à pSeuilMinimal
        private List<int> FiltrerSelonSeuilMinimalV1(List<int> pColNombres, int pSeuilMinimal)
        {
            List<int> listeFiltree = new List<int>();
            foreach (int nombre in pColNombres)
            {
                if (nombre >= pSeuilMinimal)
                {
                    listeFiltree.Add(nombre);
                }
            }
            return listeFiltree;
        }
        // TODO 08 : Définir une méthode appelée FiltrerSelonSeuilMinimalV2 qui :
        // - Reçoit/accepte en paramètre une collection d'entiers et un entier pSeuilMinimal
        // - Enlève de la collection les éléments qui sont au dessous de pSeuilMinimal
        private void FiltrerSelonSeuilMinimalV2(List<int> pColNombres, int pSeuilMinimal)
        {
            
            for (int index = pColNombres.Count - 1; index >= 0; index--)
            {
                if (pColNombres[index] < pSeuilMinimal)
                {
                    pColNombres.RemoveAt(index);
                }
            }
           
        }
        #endregion
       
    }
}
