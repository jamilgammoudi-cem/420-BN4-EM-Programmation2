﻿using System;
using System.Windows.Forms;
using System.IO;

namespace AppSudoku
{
    /// <summary>
    /// Une application capable de lire un fichier texte contenant les informations pour un jeu de Sudoku
    /// </summary>
    public partial class FrmPrincipal : Form
    {
        public const string APP_INFO = "(DÉMO)";

        #region NE PAS MODIFIER
        //================================================================================================
        public FrmPrincipal()
        {
            InitializeComponent();
            Text += APP_INFO;
        }
        #endregion

        //================================================================================================
        private void MnuFichierNouvelleGrilleVide_Click(object sender, EventArgs e)
        {
            vcaGrilleCarac.Clear();
        }
        //================================================================================================
        private void MnuFichierChargerLesCaractères_Click(object sender, EventArgs e)
        {
            vcaGrilleCarac.Clear(); // Ne pas modifier

            // Ouvrir en mode lecture un fichier texte appelé GrilleDeCaractères.txt
            StreamReader objStreamReader = new StreamReader("GrilleDeCaractères.txt");

            // Lire le fichier et transposer chaque caractère dans la grille vcaGrilleCarac
            int row = 0;
            while (!objStreamReader.EndOfStream)
            {
                string uneLigne = objStreamReader.ReadLine();
                for (int index = 0; index < uneLigne.Length; index++)
                {
                    char carac = uneLigne[index];
                    {
                        vcaGrilleCarac[row, index] = carac;
                    }
                }
                row++;
            }
            objStreamReader.Close();
        }
        //================================================================================================
        private void MnuFichierEnregistrerCaractères_Click(object sender, EventArgs e)
        {
            // Ouvrir en mode écriture un fichier texte appelé GrilleDeCaractères.txt
            StreamWriter objFichier = new StreamWriter("GrilleDeCaractères.txt");

            // Passez à travers la grille vcaGrilleCarac et copiez son contenu dans le fichier
            //    Quand vous écrivez un caractère sur une même ligne du fichier, utilisez .Write
            //    Quand vous vous voulez signifier la fin de la ligne du fichier, utilisez .WriteLn
            for (int rangée = 0; rangée < vcaGrilleCarac.RowCount; rangée++)
            {
                for (int colonne = 0; colonne < vcaGrilleCarac.ColumnCount; colonne++)
                {
                    char caractère = vcaGrilleCarac[rangée, colonne];
                    objFichier.Write(caractère);
                }
                objFichier.WriteLine();
            }

            objFichier.Close();
        }
        //================================================================================================
        private void MnuFichierQuitter_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
