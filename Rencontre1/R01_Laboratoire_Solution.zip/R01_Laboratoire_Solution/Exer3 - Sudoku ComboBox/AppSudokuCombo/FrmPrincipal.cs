﻿using System;
using System.Windows.Forms;
using System.IO;

namespace AppSudoku
{
    public partial class FrmPrincipal : Form
    {
        public const string APP_INFO = "(DÉMO)";

        //================================================================================================
        public FrmPrincipal()
        {
            InitializeComponent();
            Text += APP_INFO;
            cboSudoku.SelectedIndex = 0;
            PréparerNouvellePartie();
        }

        #region ChargerSudoku (À COMPLÉTER)
        //================================================================================================
        /// <summary>
        /// Charge un fichier contenant les caractères pour un jeu de Sudoku et les affichent dans une 
        /// grille de caractères.
        /// </summary>
        private void ChargerSudoku()
        {
            vcaSudoku.Clear(); // Ne pas modifier
            // lire le nom du fichier dans la liste déroulante cboSudoku
            string nomDuFichier = "Sudoku\\" + cboSudoku.Text + ".txt";


            StreamReader objStreamReader = new StreamReader(nomDuFichier);
            int row = 0;
            while (!objStreamReader.EndOfStream)
            {
                string uneLigne = objStreamReader.ReadLine();
                for (int index = 0; index < uneLigne.Length; index++)
                {
                    char carac = uneLigne[index];
                    { // montrer la solution du sudoku
                        if (carac >= 'A')
                            vcaSudoku[row, index] = carac;
                        else
                        {
                            vcaSudoku[row, index] = carac;
                            vcaSudoku.DisableCell(row, index);
                        }
                    }
                }
                row++;
            }
            objStreamReader.Close();
        }
        #endregion

        #region Gestionnaires d'événements (NE PAS MODIFIER)

        //================================================================================================
        /// <summary>
        /// Prépare une nouvelle partie, charge le fichier sélectionné et affiche le sudoku de départ
        /// </summary>
        private void PréparerNouvellePartie()
        {
            vcaSudoku.Enabled = true;
            ChargerSudoku();
        }

        //================================================================================================

        /// <summary>
        /// Démarre une nouvelle partie
        /// </summary>
        private void mnuFichierNouvellePartie_Click(object sender, EventArgs e)
        {
            PréparerNouvellePartie();
        }

        //================================================================================================
        /// <summary>
        /// Provoque le démarrage d'une nouvelle partie
        /// </summary>
        private void cboSudoku_SelectedIndexChanged(object sender, EventArgs e)
        {
            PréparerNouvellePartie();
        }

        //================================================================================================
        private void mnuFichierQuitter_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion

    }
}
