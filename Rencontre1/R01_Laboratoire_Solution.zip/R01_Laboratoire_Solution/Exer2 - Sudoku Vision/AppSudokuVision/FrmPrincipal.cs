﻿using System;
using System.Windows.Forms;
using System.IO;

namespace AppSudoku
{
    /// <summary>
    /// Une application capable de lire un fichier texte contenant les informations pour un jeu de Sudoku
    /// </summary>
    public partial class FrmPrincipal : Form
    {
        public const string APP_INFO = "(DÉMO)";

        #region NE PAS MODIFIER
        //================================================================================================
        public FrmPrincipal()
        {
            InitializeComponent();
            Text += APP_INFO;
            ChargerSudoku();
        }
        //================================================================================================
        private void mnuFichierQuitter_Click(object sender, EventArgs e)
        {
            Close();
        }
        #endregion

        #region ChargerSudoku (À COMPLÉTER)
        //================================================================================================
        /// <summary>
        /// Charge un fichier contenant les caractères pour un jeu de Sudoku et les affichent dans une 
        /// grille de caractères.
        /// </summary>
        private void ChargerSudoku()
        {
            vcaSudoku.Clear(); // 
            string nomDuFichier = "Sudoku.txt";
            StreamReader objStreamReader = new StreamReader(nomDuFichier);
            int row = 0;

            // TODO 01 : Compléter le code pour afficher uniquement la première rangée dans la grille de Sudoku
            // TODO 02 : Améliorer votre code afin d'afficher toutes les valeurs dans la grille
            // TODO 03 : Désactiver les cellules contenant un caractère entre '1' et '9' inclusivement

            while (!objStreamReader.EndOfStream)
            {
                string uneLigne = objStreamReader.ReadLine();
                for (int index = 0; index < uneLigne.Length; index++)
                {
                    char carac = uneLigne[index];
                    { // montrer la solution du sudoku
                        vcaSudoku[row, index] = carac;
                        if (carac >= '1' && carac <= '9')
                        { 
                            vcaSudoku.DisableCell(row, index);
                        }
                    }
                }
                row++;
            }
            objStreamReader.Close();
        }
        #endregion
    }
}
