﻿using System;
using Librairie1N6;
namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            // TODO 01A : Instancier un objet de la classe Personne
          

            // TODO 01B : Afficher le nom de la personne dans la console
           

            // TODO 01C : Afficher le prénom de la personne dans la console
          

            // TODO 01D : Afficher le numéro d'assurance sociale de la personne dans la console
           



            // TODO 02A : Instancier un objet de la classe Thermostat à la température 25
           

            // TODO 02B : Augmenter la température du Thermostat d'un degré
          

            // TODO 02C : Afficher la température courante du Thermostat dans la console
          



            // TODO 03A : Instancier un objet de la classe Montre à 12:15:59
         

            // TODO 03B : Avancer le temps courant d'une seconde en utilisant la méthode appropriée
           

            // TODO 03C : Afficher le temps courant de la montre dans la console
           


            // TODO 03D : Synchroniser la montre avec l'heure du système en utilisant la méthode AjusterAutomatiquement
           

            // TODO 03E : Afficher le temps courant de la montre dans la console
           

        }
    }
}
