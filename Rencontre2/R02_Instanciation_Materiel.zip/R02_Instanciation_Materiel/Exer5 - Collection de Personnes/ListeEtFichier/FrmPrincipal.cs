﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;

namespace ListeEtFichier
{
    public partial class FrmPrincipal : Form
    {
        private const string APP_INFO = "(Matériel)";
        private const string LISTE_DES_PERSONNES = "Fichiers\\ListeDesPersonnes.txt";

        //----------- variables membres ----------------------------------------------------------
        private List<Personne> m_colPersonnes = new List<Personne>();
        private bool m_listeEstModifiée = false;

        //=======================================================================================================
        public FrmPrincipal()
        {
            InitializeComponent();

            Text += APP_INFO;

            ChargerPersonnes(LISTE_DES_PERSONNES);
        }
        //======================================================================================================
        /// <summary>
        /// TODO 01 : Lire les informations dans le fichier et les charger en mémoire dans la liste générique.
        ///           S'assurer que le fichier existe sur le disque, sinon afficher un message dans un MessageBox.
        ///           Afficher la première personne de la liste.
        /// </summary>
        /// <param name="pNomDuFichier">nom du fichier à lire</param>
        /// ----------------------------------------------------------------------------------------------------
        private void ChargerPersonnes(string pNomDuFichier)
        {

        }
        //-----------------------------------------------------------------------------------
        /// <summary>
        /// TODO 02 : Vérifie si une personne avec ce NAS existe dans la collection
        /// </summary>
        /// <param name="pNAS">Numéro assurance sociale recherché</param>
        /// <returns>Retourne true si le NAS existe dans la collection, sinon retourne false</returns>
        private bool NASExiste(string pNAS)
        {
            return false;
        }
        ///-----------------------------------------------------------------------------------
        /// <summary>
        /// TODO 03 : Ajoute une personne à la fin de la liste générique.
        ///           On ne fait aucune validation sur le format du NAS mais on vérifie qu'il n'existe pas déjà dans la liste
		///           Voir la démo sur les messages à écrire.        
		///           Si vous modifiez la liste, faites en sorte que la variable booléene m_listeEstModifiée l'indique
		/// </summary>
        /// ----------------------------------------------------------------------------------
        private void btnAjouter_Click(object sender, EventArgs e)
        {


        }
        /// ----------------------------------------------------------------------------------
        /// <summary>
        /// TODO 04 : Recherche dans la liste générique, l'index de la personne dont le nas est spécifié.
        /// </summary>
        /// <param name="pNasRecherché">Nas à rechercher dans la liste</param>
        /// <returns>position de la personne, -1 si non trouvée</returns>
        /// ---------------------------------------------------------------------------------
        private int IndexPersonneSelonNas(string pNasRecherché)
        {
            return 0;

        }
        ///-----------------------------------------------------------------------------------
        /// <summary>
        /// TODO 05 : Supprimer la personne affichée de la liste générique.
		///           Si vous modifiez la liste, faites en sorte que la variable booléene m_listeEstModifiée l'indique
        /// </summary>
        ///-----------------------------------------------------------------------------------
        private void btnSupprimer_Click(object sender, EventArgs e)
        {

        }
        ///--------------------------------------------------------------------------------------
        /// <summary>
        /// TODO 06 : Recherche et affiche la personne dont le NAS (numéro d'assurance sociale) est indiqué.
        /// </summary>
        ///--------------------------------------------------------------------------------------
        private void btnRechercher_Click(object sender, EventArgs e)
        {


        }
        //=================================================================================================
        /// <summary>
        /// TODO 07 :  Sauvegarde la liste de personnes dans le fichier texte.
        ///            On sépare les données d'une personne par une virgule.
        ///            Voici un exemple: 205456789,Hector Larivière
        /// </summary>
        /// -----------------------------------------------------------------------------------------------
        private void SauvegarderListe()
        {

        }
        //================================================================
        private void mnuFichierQuitter_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //==============================================================================================================
       /// <summary>
       /// TODO 08 : Au moment de quitter, s'il y a eu des modifications à la liste, on la sauvegarde dans un fichier.
       /// </summary>
       /// ------------------------------------------------------------------------------------------------------------
        private void FrmPrincipal_FormClosing(object sender, FormClosingEventArgs e)
        {

        }
        //==============================================================================================================
        private void btnEffacerAffichage_Click(object sender, EventArgs e)
        {
            txtNom.Clear();
            mtxNAS.Clear();
        }
        //==============================================================================================================
        private void btnQuitter_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
