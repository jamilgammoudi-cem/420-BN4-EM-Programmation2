﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ListeEtFichier
{
    /// -----------------------------------------------------------------------------------------------------
    /// <summary>
    ///	 Représente une personne : son numéro d'assurance sociale et son nom.
    /// </summary>
    /// -----------------------------------------------------------------------------------------------------
    public class Personne
    {
        // TODO 01 : Utiliser uniquement des propriétés automatiques dans cette classe

        #region Propriétés

        //------------------------------------------------------
        private string m_nas;
        /// ----------------------------------------------------
        /// <summary>
        /// Obtient le numéro d'assurance sociale d'une personne.
        /// </summary>
        /// ----------------------------------------------------
        public string Nas
        {
            get { return m_nas; }
        }

        //------------------------------------------------------
        private string m_nom;
        /// ----------------------------------------------------
        /// <summary>
        /// Obtient le nom prénom d'une personne.
        /// </summary>
        /// ----------------------------------------------------
        public string Nom
        {
            get { return m_nom; }
        }

        #endregion

        #region Constructeur
        //---------------------------------------------------------------
        /// <summary>
        /// Instancie une personne avec les données passées en paramètre.
        /// </summary>
        /// <param name="pNas">nas de la personne à créer</param>
        /// <param name="pNom">nom de la personne à créer</param>
        /// -------------------------------------------------------------
        public Personne(string pNas, string pNom)
        {
            m_nas = pNas;
            m_nom = pNom;
        }
        #endregion
    }
}
