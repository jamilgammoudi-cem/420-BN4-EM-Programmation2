﻿using System;
using Librairie1N6;
namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            // TODO 01A : Instancier un objet de la classe Personne
            Personne objPersonne = new Personne("Lapointe", "Jean-Pierre", "456123789");

            // TODO 01B : Afficher le nom de la personne dans la console
            Console.WriteLine(objPersonne.Nom);
            // TODO 01C : Afficher le prénom de la personne dans la console
            Console.WriteLine(objPersonne.Prénom);
            // TODO 01D : Afficher le numéro d'assurance sociale de la personne dans la console
            Console.WriteLine(objPersonne.Nas);


            // TODO 02A : Instancier un objet de la classe Thermostat à la température 25
            Thermostat objThermostat = new Thermostat(25);
            // TODO 02B : Augmenter la température du Thermostat d'un degré
            objThermostat.AugmenterTemperature();
            // TODO 02C : Afficher la température courante du Thermostat dans la console
            Console.WriteLine(objThermostat.Température);


            // TODO 03A : Instancier un objet de la classe Montre à 12:15:59
            Montre objMontre = new Montre(12, 15, 59);
            // TODO 03B : Avancer le temps courant d'une seconde en utilisant la méthode appropriée
            objMontre.AvancerUneSeconde();
            // TODO 03C : Afficher le temps courant de la montre dans la console
            Console.WriteLine(objMontre.TempsCourant);

            // TODO 03D : Synchroniser la montre avec l'heure du système en utilisant la méthode AjusterAutomatiquement
            objMontre.AjusterAutomatiquement();
            // TODO 03E : Afficher le temps courant de la montre dans la console
            Console.WriteLine(objMontre.TempsCourant);

            while (true) ;
        }
    }
}
