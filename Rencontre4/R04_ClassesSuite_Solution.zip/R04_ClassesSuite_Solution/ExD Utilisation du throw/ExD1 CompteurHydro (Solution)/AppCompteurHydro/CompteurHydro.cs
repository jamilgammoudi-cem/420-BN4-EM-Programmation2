using System;

namespace AppCompteurHydro
{
    /// ------------------------------------------------------------------------------------
    /// <summary>
    /// Repr�sente un compteur hydro �lectrique 
    /// </summary>
    /// ------------------------------------------------------------------------------------
    public class CompteurHydro
    {

        #region CHAMPS (variable membre) ET PROPRI�T�

        ///==================================================================================
        private int m_consommationActuelle;
        /// ---------------------------------------------------------------------------------
        /// <summary>
        ///    Obtient la consommation totale actuelle 
        /// </summary>
        public int ConsommationActuelle
        {
            get { return m_consommationActuelle; }
        }

        #endregion

        #region CONSTRUCTEUR

        ///==================================================================================
        /// <summary>
        ///   Initialise une nouvelle instance. 
        /// </summary>
        public CompteurHydro()
        {
            m_consommationActuelle = 0;
        }

        #endregion

        #region M�THODE

        ///==================================================================================
        /// <summary>
        /// Augmente la quantit� d'�lectricit� consomm�e.
        /// </summary>
        /// <param name="pQuantit�Kwh">Quantit� d'�lectricit� � ajouter au compteur</param>
        public void Consommer(int pQuantit�Kwh)
        {
            // TODO 01 : Ajouter le code n�cessaire pour lancer une exception lorsque pQuantit�Kwh est n�gatif.
            // L'exception � lancer est ArgumentOutOfRangeException

            if (pQuantit�Kwh < 0)
            {
                throw new ArgumentOutOfRangeException();
            }

            m_consommationActuelle += pQuantit�Kwh;
        }

        #endregion
    }
}
