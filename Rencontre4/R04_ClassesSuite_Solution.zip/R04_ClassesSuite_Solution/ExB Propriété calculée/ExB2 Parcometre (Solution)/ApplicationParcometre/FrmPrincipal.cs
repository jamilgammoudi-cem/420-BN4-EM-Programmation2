﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ApplicationParcometre
{
    public partial class FrmPrincipal : Form
    {
        public const string APP_INFO = "(Solution)";

        // TODO 01 : Remplacer la méthode ObtenirTempsRestant() par une propriété calculée nommée TempsRestant
        // TODO 02 : Remplacer la méthode EstEnInfraction() par une propriété calculée nommée EnInfraction

        private Parcometre m_objParcometre;

        //====================
        public FrmPrincipal()
        {
            InitializeComponent();
            Text += APP_INFO;
            //----------------------------------------------------------------

            m_objParcometre = new Parcometre();

            lblCoutParMinutes.Text = Parcometre.COUT_PAR_MINUTE + "c/Min.";
            cboMontant.SelectedIndex = 0;
        }
        //============================================================================
        private void mnuFichierQuitter_Click(object sender, System.EventArgs e)
        {
            Close();
        }
        //============================================================================
        private void tmrTemps_Tick(object sender, EventArgs e)
        {
            m_objParcometre.ConsommerUneMinuteDeTemps();
            MettreAJourSelonContexte();
        }
        // ======================================================================
        private void btnAjouterMontant_Click(object sender, EventArgs e)
        {
            m_objParcometre.InsererMonnaie(int.Parse(cboMontant.Text));
            MettreAJourSelonContexte();
            tmrTemps.Start();
        }
        // ======================================================================
        /// <summary>
        /// Mettre à jour l'interface graphique de l'application.
        /// txtTempsRestant, txtMontantTotal, panÉtat.BackColor et arrête le timer si nécessaire.
        /// </summary>
        private void MettreAJourSelonContexte()
        {
            txtTempsRestant.Text = m_objParcometre.TempsRestant;
            txtMontantTotal.Text = ((decimal)m_objParcometre.MontantTotal / 100).ToString("C2");

            if (m_objParcometre.EnInfraction)
            {
                panÉtat.BackColor = Color.Red;
                tmrTemps.Stop();
            }
            else
                panÉtat.BackColor = Color.Green;
        }


        #region NE PAS MODIFIER (Pour gérer le menu temps)
        // ======================================================================
        private void mnuTemps_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem itemCourant = (ToolStripMenuItem)sender;
            foreach (ToolStripMenuItem item in mnuTemps.DropDownItems)
                item.Checked = false;
            itemCourant.Checked = true;
            tmrTemps.Interval = int.Parse(itemCourant.Tag.ToString());

        }
        #endregion
    }
}