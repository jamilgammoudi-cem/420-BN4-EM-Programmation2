﻿using System;
using System.Collections.Generic;

namespace ClasseGroupe
{
    /// <summary>
    /// Réprésente un groupe de membres abonnés pour un sujet donné
    /// </summary>
    public class Groupe
    {
        #region Constantes
        public const int MAX_MEMBRES = 3;

        #endregion
        #region Champs
        private string m_nom;
        private DateTime m_dateDeCréation;
        private List<string> m_colMembres;
        #endregion
        #region Propriétés

        /// <summary>
        /// Obtient le nom du groupe.
        /// </summary>
        public string Nom { 
            get { 
                return m_nom; 
            }
            private set
            {
                m_nom = value;
            }

        }

        /// <summary>
        /// Obtient la date de création du groupe.
        /// </summary>
        public DateTime DateDeCréation 
        { 
            get { return m_dateDeCréation; }
            private set { m_dateDeCréation = value; }
        }

        /// <summary>
        /// Obtient la collection des membres du groupe
        /// </summary>
        public List<string> ColMembres { 
            get { return m_colMembres; }
           
        }


        /// <summary>
        /// Obtient la collection des membres du groupe
        /// </summary>
        public int NombreDeMembres { get { return m_colMembres.Count; } }

        #endregion

        

        #region Constructeurs et méthodes
       
        ///===============================================================================================
        /// <summary>
        /// Initialise un groupe 
        /// </summary>
        /// <param name="pNom">nom du groupe</param>
        /// <param name="pDateCréation">date de création du groupe</param>
        public Groupe(string pNom,DateTime pDateCréation)
        {
            Nom = pNom;
            DateDeCréation = pDateCréation;
            m_colMembres = new List<string>();                        
        }
       
        /// <summary>
        /// Ajouter un membre s'il n'existe pas
        /// </summary>
        /// <param name="pNom"></param>
        public void AjouterMembre(string pNom)
        {
            if (m_colMembres.Count == MAX_MEMBRES)
            {
                throw new InvalidOperationException();

            }
            m_colMembres.Add(pNom);
        }
        /// <summary>
        /// Retirer un membre à une position donnée
        /// </summary>
        /// <param name="position"></param>
        public void RetirerMembre(int position)
        {
            if (position < 0 || position >= m_colMembres.Count)
            {
                throw new ArgumentOutOfRangeException();

            }
            m_colMembres.RemoveAt(position);
        }
        #endregion
    }
}
