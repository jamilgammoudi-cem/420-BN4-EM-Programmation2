﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ManipulationsCollection
{
    public partial class Form1 : Form
    {
        string[] m_tabFruits = {"fraise","banane","raisin","kiwi","pomme","tomate","ananas","avocat", "framboise", "cerise" };
        int[] m_tabNombres = { 30, 20, -15, -10, 9, 25,75, 40, 88, 13 };


        
        List<string> m_colFruits = new List<string>();
        static List<int> m_colNombres = new List<int>();
        
       
        public Form1()
        {
            InitializeComponent();

            // TODO 02 : Utiliser la méthode GenererCollectionDeFruits pour remplir la collection
            // m_colFruits à partir du tableau m_tabFruits 
            // Compléter ici

            m_colFruits = GenererCollectionDeFruits(m_tabFruits);

            // TODO 04 : Utiliser la méthode AfficherCollectionDeMotsDansListBox pour afficher le contenu de la collection
            // m_colFruits dans lstFruits
            // Compléter ici

            AfficherCollectionDeMotsDansListBox(m_colFruits,lstFruits);

            // TODO 09 : Utiliser la méthode RemplirCollectionDeNombres pour remplir la collection
            // m_tabNombres 
            // Compléter ici

            RemplirCollectionDeNombres(m_tabNombres);

            // TODO 11 : Utiliser la méthode AfficherCollectionDeNombresDansListBox pour afficher le contenu de la collection 
            // m_colNombres dans lstNombres
            // Compléter ici

            AfficherCollectionDeNombresDansListBox();

            // TODO 20 : Utiliser la méthode CalculerNombreMaximal pour trouver le nombre maximal dans la collection m_colNombres
            // et l'afficher dans vsiMax
            // Compléter ici

            vsiMax.Value =  CalculerNombreMaximal(m_colNombres);


        }
       
       
        /// <summary>
        /// Copier le contenu d'un tableau dans une collection et la retourner 
        /// </summary>
        /// <param name="pTabMots"></param>
        /// <returns></returns>
        private List<string> GenererCollectionDeFruits(string[] pTabMots)
        {
            // TODO 01 : Copier le contenu de pTabMots dans une nouvelle collection puis la retourner
            // Compléter ici
            List<string> collectionMots = new List<string>();
            for (int index = 0; index < pTabMots.Length; index++)
            {

                collectionMots.Add(pTabMots[index]);

            }

            return collectionMots;

        }
        
        /// <summary>
        /// Afficher le contenu d'une collection dans un ListBox
        /// </summary>
        /// <param name="pCollectionMots"></param>
        /// <param name="plistMots"></param>
        private void AfficherCollectionDeMotsDansListBox(List<string> pCollectionMots, ListBox plistMots)
        {
            // TODO 03 : Afficher le contenu de la collection pCollectionMots dans le ListBox plistMots
            // Compléter ici

            plistMots.Items.Clear();

            foreach (string mot in pCollectionMots)
            {
                plistMots.Items.Add(mot);
            }


        }
        
      /// <summary>
      /// Filtrer le contenu d'une collection en fonction de la taille de ses éléments
      /// </summary>
      /// <param name="pCollectionMots"></param>
      /// <param name="pTaille"></param>
        private void FiltrerCollectionDeMotsSelonLaTaille(List<string> pCollectionMots, int pTaille)
        {
            // TODO 05 : Enlever de la collection pCollectionMots les éléments ayant une taille égale à pTaille
            // Compléter ici
            for (int index = pCollectionMots.Count - 1; index >= 0; index--)
            {
                if (pCollectionMots[index].Length == pTaille)
                {
                    pCollectionMots.RemoveAt(index);
                }
            }



        }
        /// <summary>
        /// Copier le contenu d'un tableau dans une collection
        /// </summary>
        /// <param name="pTaNombres"></param>
        private void RemplirCollectionDeNombres(int[] pTaNombres)
        {
            // TODO 08 : Copier le contenu du tableau pTaNombres dans la collection m_colNombres
            // Compléter ici

            m_colNombres.Clear();
            for (int index = 0; index < pTaNombres.Length; index++)
            {
                m_colNombres.Add(pTaNombres[index]);

            }

        }
        /// <summary>
        /// Afficher le contenu d'une collection dans un ListBox
        /// </summary>
        private void AfficherCollectionDeNombresDansListBox()
        {
            // TODO 10 : Afficher le contenu de la collection m_colNombres dans le listBox lstNombres
            lstNombres.Items.Clear();

            foreach (int nombre in m_colNombres)
            {
                lstNombres.Items.Add(nombre);
            }


        }
        /// <summary>
        /// Filtrer une collection selon la taille de chaque élément et afficher son contenu dans un ListBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnFiltrer1_Click(object sender, EventArgs e)
        {

            // TODO 06 : Utiliser la méthode FiltrerCollectionDeMotsSelonLaTaille pour enlever de la collection m_colFruits les éléments
            // dont la taille est spécifiée dans vsiTaille
            // Compléter ici

            FiltrerCollectionDeMotsSelonLaTaille(m_colFruits, vsiTaille.Value);


            // TODO 07 : Utiliser la méthode AfficherCollectionDeMotsDansListBox pour afficher le contenu de la collection
            // m_colFruits dans le ListBox lstFruits
            // Compléter ici

            AfficherCollectionDeMotsDansListBox(m_colFruits, lstFruits);
        }
        /// <summary>
        /// Filtrer une collection selon la valeur de chaque élément et afficher son contenu dans un ListBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnFiltrer2_Click(object sender, EventArgs e)
        {

            // TODO 13 : Utiliser la méthode ConserverNombresEntreMinEtMax pour enlever de la collection m_colNombres les éléments
            // qui ne sont pas entre les deux bornes spécifiées dans vsiNombreMin et vsiNombreMax
            // Compléter ici

            ConserverNombresEntreMinEtMax(m_colNombres, vsiNombreMin.Value, vsiNombreMax.Value);

            // TODO 14 : Utiliser la méthode AfficherCollectionDeNombresDansListBox pour afficher le contenu de la collection
            // m_colNombres dans le ListBox lstNombres
            // Compléter ici

            AfficherCollectionDeNombresDansListBox();
            
            
            // NE PAS MODIFIER
            vsiMax.Value = CalculerNombreMaximal(m_colNombres);

        }


        
        
        /// <summary>
        /// Filtrer une collection selon la valeur de chaque élément
        /// </summary>
        /// <param name="pColNombres"></param>
        /// <param name="pMin"></param>
        /// <param name="pMax"></param>
        private void ConserverNombresEntreMinEtMax(List<int> pColNombres, int pMin, int pMax)
        {
            // TODO 12 : Enlever de la collection pColNombres les éléments qui ne sont pas entre pMin et pMax
            // Compléter ici
            for (int index = pColNombres.Count - 1; index >= 0; index--)
            {
                if (pColNombres[index] < pMin || pColNombres[index] > pMax)
                  
                {
                    pColNombres.RemoveAt(index);
                }
            }
           
        }

        /// <summary>
        /// Remplic une collection et afficher son contenu dans un ListBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRemplir_Click(object sender, EventArgs e)
        {
            
            // TODO 15 : Utiliser la méthode RemplirCollectionDeNombres pour remplir la collection
            // m_tabNombres 
            // Compléter ici

            RemplirCollectionDeNombres(m_tabNombres);

            // TODO 16 : Utiliser la méthode AfficherCollectionDeNombresDansListBox pour afficher le contenu de la collection 
            // m_colNombres dans le ListBox lstNombres
            // Compléter ici

            AfficherCollectionDeNombresDansListBox();

            // NE PAS MODIFIER
            vsiMax.Value = CalculerNombreMaximal(m_colNombres);


        }

        /// <summary>
        /// Remplic une collection et afficher son contenu dans un ListBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {

            // TODO 17 : Utiliser la méthode GenererCollectionDeFruits pour remplir la collection m_colFruits
            // à partir du tableau m_tabFruits
            // Compléter ici
            m_colFruits = GenererCollectionDeFruits(m_tabFruits);


            // TODO 18 : Utiliser la méthode AfficherCollectionDeMotsDansListBox pour afficher la collection m_colFruits
            // dans le ListBox lstFruits
            // Compléter ici
            AfficherCollectionDeMotsDansListBox(m_colFruits, lstFruits);
        }

        /// <summary>
        /// Trouver et retourner la valeur maximale dans une collection
        /// </summary>
        /// <param name="pCollection"></param>
        /// <returns></returns>
        private int CalculerNombreMaximal(List<int> pCollection)
        {
            // TODO 19 : Trouver et retourner la valeur maximale dans la collection pCollection
            // Compléter ici
            int max = int.MinValue;
            foreach (int nombre in pCollection)
            {

                if (nombre > max)
                {
                    max = nombre;
                }

            }

            return max;

        }
       
    }
}
