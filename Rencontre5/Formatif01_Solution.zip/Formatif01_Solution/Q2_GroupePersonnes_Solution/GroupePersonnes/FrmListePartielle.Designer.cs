﻿namespace GroupePersonnes
{
    partial class FrmListePartielle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstPartielle = new System.Windows.Forms.ListBox();
            this.btnFermer = new System.Windows.Forms.Button();
            this.txtCritère = new System.Windows.Forms.TextBox();
            this.lblCritere = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lstPartielle
            // 
            this.lstPartielle.FormattingEnabled = true;
            this.lstPartielle.Location = new System.Drawing.Point(15, 48);
            this.lstPartielle.Name = "lstPartielle";
            this.lstPartielle.Size = new System.Drawing.Size(285, 199);
            this.lstPartielle.TabIndex = 3;
            // 
            // btnFermer
            // 
            this.btnFermer.Location = new System.Drawing.Point(211, 259);
            this.btnFermer.Name = "btnFermer";
            this.btnFermer.Size = new System.Drawing.Size(89, 24);
            this.btnFermer.TabIndex = 4;
            this.btnFermer.Text = "Fermer";
            this.btnFermer.UseVisualStyleBackColor = true;
            this.btnFermer.Click += new System.EventHandler(this.btnFermer_Click);
            // 
            // txtCritère
            // 
            this.txtCritère.Location = new System.Drawing.Point(169, 12);
            this.txtCritère.Name = "txtCritère";
            this.txtCritère.Size = new System.Drawing.Size(131, 20);
            this.txtCritère.TabIndex = 2;
            this.txtCritère.TextChanged += new System.EventHandler(this.txtCritère_TextChanged);
            // 
            // lblCritere
            // 
            this.lblCritere.AutoSize = true;
            this.lblCritere.Location = new System.Drawing.Point(12, 15);
            this.lblCritere.Name = "lblCritere";
            this.lblCritere.Size = new System.Drawing.Size(117, 13);
            this.lblCritere.TabIndex = 1;
            this.lblCritere.Text = "Nom commençant par :";
            // 
            // FrmListePartielle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(315, 295);
            this.Controls.Add(this.txtCritère);
            this.Controls.Add(this.lblCritere);
            this.Controls.Add(this.btnFermer);
            this.Controls.Add(this.lstPartielle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmListePartielle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Liste partielle ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstPartielle;
        private System.Windows.Forms.Button btnFermer;
        private System.Windows.Forms.TextBox txtCritère;
        private System.Windows.Forms.Label lblCritere;
    }
}