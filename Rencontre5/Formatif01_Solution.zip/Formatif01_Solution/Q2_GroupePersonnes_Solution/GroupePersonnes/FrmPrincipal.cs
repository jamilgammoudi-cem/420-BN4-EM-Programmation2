﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;

namespace GroupePersonnes
{
    public partial class FrmPrincipal : Form
    {
        #region Variables membres, constructeur et ChargerPersonnes (NE PAS modifier)

        public const string APP_INFO = "(Matériel)";
        //----------- variables membre -------------------------------------------------------------------------
        private const string LISTE_DES_PERSONNES = "Fichiers\\ListeDesPersonnes.txt";

        private List<Personne> m_colPersonnes = new List<Personne>();

        private bool m_estModifié = false;

        //=======================================================================================================
        public FrmPrincipal()
        {
            InitializeComponent();
            this.Text += APP_INFO;
            //----------------------
            ChargerPersonnes(LISTE_DES_PERSONNES);
        }

        //======================================================================================================
        /// <summary>
        /// Lit les informations dans le fichier, les charge en mémoire dans la liste générique.
        /// S'assurer que le fichier exite sur le disque, sinon affiche un message Box.
        /// Affiche la première personne de la liste.
        /// </summary>
        /// <param name="pNomDuFichier">nom du fichier à lire</param>
        /// ----------------------------------------------------------------------------------------------------
        private void ChargerPersonnes(string pNomDuFichier)
        {
            if (!File.Exists(pNomDuFichier))
            {
                MessageBox.Show("Impossible de trouver la liste des personnes",
                                Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //--------------------------------------------------------------------------------
            m_colPersonnes.Clear();

            //---- lecture dans le fichier ----------------------------------------------------
            // TODO 00 : Remplir la collection m_colPersonnes à partir du fichier texte pNomDuFichier
            
            StreamReader objStreamReader = new StreamReader(pNomDuFichier);
            while (!objStreamReader.EndOfStream)
            {
                string uneLigneLue = objStreamReader.ReadLine();
                Personne unePersonne = new Personne(uneLigneLue);
                m_colPersonnes.Add(unePersonne);
            }
            objStreamReader.Close();
        }
        //================================================================
        private void mnuFichierQuitter_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //==============================================================================================================
        /// <summary>
        /// Au moment de quitter, s'il y a eu des modifications à la liste, on la sauvegarde dans un fichier.
        /// </summary>
        /// ------------------------------------------------------------------------------------------------------------
        private void FrmPrincipal_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (m_estModifié)
            {
                SauvegarderListe();
            }
        }
        #endregion

        #region TODO 01 : méthode Sauvegarder la collection dans un fichier Texte
        //==================================================================================
        /// <summary>
        /// TODO 01  : Sauvegarde la liste de personnes dans le fichier Texte.
        ///            On sépare les données d'une personne par une virgule.
        ///            Voici un exemple: 205456789,Robert,TREMBLAY
        ///                              nas,prénom,nom em majuscules
        /// </summary>
        /// --------------------------------------------------------------------------------
        private void SauvegarderListe()
        {
            // À COMPLÉTER...
            StreamWriter objStreamWriter = new StreamWriter(LISTE_DES_PERSONNES);
            foreach (Personne objPersonne in m_colPersonnes)
            {
                objStreamWriter.Write(objPersonne.Nas + ",");
                objStreamWriter.Write(objPersonne.Prenom + ",");
                objStreamWriter.WriteLine(objPersonne.Nom.ToUpper());

            }
            objStreamWriter.Close();
        }

        #endregion

        #region TODO 02 à 05 : méthodes IndexPersonneSelon... et bouton Rechercher
        /// ------------------------------------------------------------------------------------------------
        /// <summary>
        /// TODO 02 : Recherche dans la liste générique, l'index de la personne dont le NAS est spécifié.
        /// </summary>
        /// <param name="pNasRecherché">Nas à rechercher dans la liste</param>
        /// <returns>index de la personne trouvée, -1 si non trouvée</returns>
        /// ------------------------------------------------------------------------------------------------
        private int IndexPersonneSelonNas(string pNasRecherché)
        {
            // À COMPLÉTER...
            for (int index = 0; index < m_colPersonnes.Count; index++)
            {
                Personne personneCourante = m_colPersonnes[index];
                if (personneCourante.Nas == pNasRecherché)
                {
                    return index;
                }
            }
            return -1;
        }
        /// --------------------------------------------------------------------------------------------------
        /// <summary>
        /// TODO 03 : Recherche dans la liste générique, l'index de la personne dont le PRENOM est spécifié.
        /// </summary>
        /// <param name="pPrenomRecherché">prénom à rechercher dans la liste</param>
        /// <returns>index de la personne trouvée, -1 si non trouvée</returns>
        /// --------------------------------------------------------------------------------------------------
        private int IndexPersonneSelonPrenom(string pPrenomRecherché)
        {
            // À COMPLÉTER...
            pPrenomRecherché = pPrenomRecherché.ToUpper();
            for (int index = 0; index < m_colPersonnes.Count; index++)
            {
                Personne personneCourante = m_colPersonnes[index];
                if (personneCourante.Prenom.ToUpper() == pPrenomRecherché)
                {
                    return index;
                }
            }
            return -1;
        }
        /// ------------------------------------------------------------------------------------------------
        /// <summary>
        /// TODO 04 : Recherche dans la liste générique, l'index de la personne dont le NOM est spécifié.
        /// </summary>
        /// <param name="pNomRecherché">nom à rechercher dans la liste</param>
        /// <returns>index de la personne trouvée, -1 si non trouvée</returns>
        /// ------------------------------------------------------------------------------------------------
        private int IndexPersonneSelonNom(string pNomRecherché)
        {
            // À COMPLÉTER...
            pNomRecherché = pNomRecherché.ToUpper();
            for (int index = 0; index < m_colPersonnes.Count; index++)
            {
                if (m_colPersonnes[index].Nom.ToUpper() == pNomRecherché)
                {
                    return index;
                }
            }
            return -1;
        }
        ///-------------------------------------------------------------------------------------------
        /// <summary>
        /// TODO 05 : Recherche et affiche la personne dont le NAS ou le NOM ou le PRENOM est indiqué.
        /// </summary>
        ///-------------------------------------------------------------------------------------------
        private void btnRechercher_Click(object sender, EventArgs e)
        {
            // À COMPLÉTER..
            int indexNAS = IndexPersonneSelonNas(mtxNAS.Text);
            int indexPrenom = IndexPersonneSelonPrenom(txtPrenom.Text);
            int indexNom = IndexPersonneSelonNom(txtNom.Text);

            int index = -1;

            if (indexNAS != -1)
            {
                index = indexNAS;
            }
            else if (indexPrenom != -1)
            {
                index = indexPrenom;
            }
            else if (indexNom != -1)
            {
                index = indexNom;
            }

            if (index != -1)
            {
                mtxNAS.Text = m_colPersonnes[index].Nas;
                txtNom.Text = m_colPersonnes[index].Nom;
                txtPrenom.Text = m_colPersonnes[index].Prenom;
                txtIndex.Text = index.ToString();
            }
            else
            {
                txtIndex.Clear();
                MessageBox.Show("Impossible de trouver cette personne : ",
                                Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion

        #region TODO 08 : Afficher la liste dans un sous-formulaire
        //======================================================================================================
        /// <summary>
        /// TODO 08 (déja fait) : Instancier le sous-formulaire et l'afficher
        /// </summary>
        /// ---------------------------------------------------------------------------------------------------
        private void mnuAffichageListe_Click(object sender, EventArgs e)
        {
            // À COMPLÉTER...
            FrmListePartielle frmListe = new FrmListePartielle(m_colPersonnes);
            frmListe.ShowDialog();
        }
        #endregion

        #region TODO 09 : bouton ajouter une personne 

        ///-------------------------------------------------------------------------------------------
        /// <summary>
        /// TODO 09 : Ajouter une personne à la fin de la liste générique. 
        /// Les NAS qui ont moins de 9 caractères ne sont pas acceptés
        /// Les noms qui ont moins de 3 caractères ne sont pas acceptés
        /// </summary>
        /// ------------------------------------------------------------------------------------------
        private void btnAjouter_Click(object sender, EventArgs e)
        {
            // À COMPLÉTER...
            string nas = mtxNAS.Text;

            int indexNASDéjàLà = IndexPersonneSelonNas(nas);
            if (indexNASDéjàLà != -1)
            {
                MessageBox.Show("Il y a déjà une personne avec ce NAS.",
                                Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            string nom = txtNom.Text.ToUpper(); 
            string prenom = txtPrenom.Text;

            //condition de garde
            if (nas.Length < 11 || nom.Length < 3)
            {
                MessageBox.Show("Aucun élément n'a été ajouté à la liste",
                                Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Personne unePersonne = new Personne(nas, prenom, nom);
            m_colPersonnes.Add(unePersonne);

            m_estModifié = true;

            MessageBox.Show(m_colPersonnes[m_colPersonnes.Count - 1].Nom + " a été ajouté.", "Liste générique");
            txtNom.Clear();
            txtPrenom.Clear();
            mtxNAS.Clear();
            txtIndex.Clear();
        }

        #endregion

        #region TODO 10 : bouton supprimer une personne
        ///-----------------------------------------------------------------------------------
        /// <summary>
        /// TODO 10 : Supprimer la personne affichée de la liste générique.
        /// </summary>
        ///-----------------------------------------------------------------------------------
        private void btnSupprimer_Click(object sender, EventArgs e)
        {
            // À COMPLÉTER...
            //condition de garde avec message
            if (txtIndex.Text == "")
            {
                MessageBox.Show("Aucun élément n'a été supprimé", "Liste générique",
                                 MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }


            int index = int.Parse(txtIndex.Text);

            MessageBox.Show(m_colPersonnes[index].Nom + " a été supprimé.", "Liste générique");
            m_colPersonnes.RemoveAt(index);

            m_estModifié = true;

            txtNom.Clear();
            txtPrenom.Clear();
            mtxNAS.Clear();
            txtIndex.Clear();
        }
        #endregion

        #region TODO 11 à 13 : boutons suivant et précédent

        //==================================================================================
        /// <summary>
        /// TODO 11 : Afficher dans les différents TextBox, les infos concernant la personne
        ///           dont l'index est fourni en paramètre.
        /// </summary>
        /// <param name="pIndex">index de la personne à afficher</param>
        /// --------------------------------------------------------------------------------
        private void AfficherElementCourant(int pIndex)
        {
            // À COMPLÉTER...
            txtIndex.Text = pIndex.ToString();
            mtxNAS.Text = m_colPersonnes[pIndex].Nas;
            txtNom.Text = m_colPersonnes[pIndex].Nom;
            txtPrenom.Text = m_colPersonnes[pIndex].Prenom;
        }

        //==================================================================================
        /// <summary>
        /// TODO 12 : Avancer d'une position dans la collection et afficher l'élément courant.
        /// </summary>
        /// --------------------------------------------------------------------------------
        private void btnSuivant_Click(object sender, EventArgs e)
        {
            // À COMPLÉTER...
            //condition de garde
            if (txtIndex.Text == "")
                return;
            //condition de garde
            int index = int.Parse(txtIndex.Text);
            if (index >= m_colPersonnes.Count - 1)
                return;

            index++;
            AfficherElementCourant(index);
        }

        //=====================================================================================
        /// <summary>
        /// TODO 13 : Reculer d'une position dans la collection et afficher l'élément courant.
        /// </summary>
        /// -----------------------------------------------------------------------------------
        private void btnPrecedent_Click(object sender, EventArgs e)
        {
            // À COMPLÉTER...
            //condition de garde

            if (txtIndex.Text == "")
                return;
            //condition de garde
            int index = int.Parse(txtIndex.Text);
            if (index <= 0)
                return;

            index--;
            AfficherElementCourant(index);
        }
        #endregion
    }
}
