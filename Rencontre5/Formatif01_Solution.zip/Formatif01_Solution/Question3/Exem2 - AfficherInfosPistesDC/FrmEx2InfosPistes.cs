using System.Windows.Forms;
using Librairie1N6;

namespace AfficherInfosPistes
{
    /// <summary>
    /// Description :   Afficher les informations sur les pistes d'un  disque Compact.
    /// </summary>
    public partial class FrmEx2InfosPistes : Form
    {
        public const string APP_INFO = "(D�MO)";

        DisqueCompact m_objDisqueCourant = null;

        #region NE PAS MODIFIER
        ///--------------------------------------------------------------------------------
        public FrmEx2InfosPistes()
        {
            InitializeComponent();
            Text += APP_INFO;
            //----------------------------  
            vsaGrilleInfosPistes.ColumnHeaderArray[0] = "Dur�e";
        }
        ///--------------------------------------------------------------------------------
        private void mnuFichierQuitter_Click(object sender, System.EventArgs e)
        {
            Close();
        }
        #endregion

        #region AfficherInfosDisque
        /// <summary>
        /// Affiche les informations du disque courant (sauf les pistes)
        /// </summary>
        private void AfficherInfosDisque()
        {
            // Compl�ter le code pour afficher : le nombre de pistes et le genre de musique

            txtNbPistes.Text = m_objDisqueCourant.Pistes.Length.ToString();
            txtGenre.Text = m_objDisqueCourant.Genre.ToString();

            // / Compl�ter le code pour afficher : la dur�e totale et la dur�e moyenne des pistes
            txtDureeTotale.Text = DisqueCompact.FormatMMSS(m_objDisqueCourant.Dur�e);
            txtDureeMoyenne.Text = DisqueCompact.FormatMMSS(m_objDisqueCourant.Dur�e / m_objDisqueCourant.Pistes.Length);
        }
        #endregion

        #region AfficherInfosPistes
        /// <summary>
        /// Affiche les informations des pistes du disque courant
        /// </summary>
        private void AfficherInfosPistes()
        {
            vsaGrilleInfosPistes.Clear();
            vsaGrilleInfosPistes.RowCount = m_objDisqueCourant.Pistes.Length;

            // / Afficher dans la grille vsaGrilleInfosPistes, la dur�e de chacune des pistes
            for (int index = 0; index < m_objDisqueCourant.Pistes.Length; index++)
            {
                int dureePiste = m_objDisqueCourant.Pistes[index];
                vsaGrilleInfosPistes[index] = DisqueCompact.FormatMMSS(dureePiste);
            }

            // TODO 02 : Afficher dans la zone de texte, le nombre de pistes sup�rieures � 5 minutes.
            // Utilisez la m�thode NbPistesDur�eSup�rieure�PSecondes
            //---------------------------------------------------------------------------------------------------------
            txtNbPistesSupA5Min.Text = NbPistesDur�eSup�rieure�PSecondes(300).ToString();

            //  Afficher dans la zone de texte, la dur�e en MM:SS de la piste la plus longue.
            // --------------------------------------------------------------------------------------------------------
            txtDureeMaximum.Text = DisqueCompact.FormatMMSS(DureeMaximum());


            //  TODO 04 : Afficher dans la zone de texte, la position du piste de dur�e minimum
            // --------------------------------------------------------------------------------------------------------

            txtPositionDureeMin.Text = PositionPisteDeDureeMinimum().ToString();

            //  TODO 06 : Afficher dans la zone de texte, la dur�e totale des pistes ayant une position paires
            // --------------------------------------------------------------------------------------------------------
            txtDureePistesPositionPaire.Text = DisqueCompact.FormatMMSS( SommeDureeAPositionPaire());


        }
        #endregion

        #region Instancier un disque Normal
        /// ----------------------------------------------------------------------------     
        private void BtnInstancierUnDisqueNormal_Click(object sender, System.EventArgs e)
        {
            //  Instancier un disque et conserver sa r�f�rence dans la variable m_objDisqueCourant
            m_objDisqueCourant = new DisqueCompact();

            //  Appeler les m�thodes AfficherInfosDisque et AfficherInfosPistes
            AfficherInfosDisque();
            AfficherInfosPistes();
        }

        #endregion

        #region Instancier un disque Test1, Test2 ou Test3
        private void BtnInstancierUnDisqueTest1_Click(object sender, System.EventArgs e)
        {
            //  Instancier un disque Test1 et conserver sa r�f�rence dans la variable m_objDisqueCourant
            m_objDisqueCourant = new DisqueCompact(SorteDeDisque.Test1);
            //  Appeler les m�thodes AfficherInfosDisque et AfficherInfosPistes
            AfficherInfosDisque();
            AfficherInfosPistes();
        }
        private void BtnInstancierUnDisqueTest2_Click(object sender, System.EventArgs e)
        {
            //  Instancier un disque Test2 et conserver sa r�f�rence dans la variable m_objDisqueCourant
            m_objDisqueCourant = new DisqueCompact(SorteDeDisque.Test2);
            //  Appeler les m�thodes AfficherInfosDisque et AfficherInfosPistes
            AfficherInfosDisque();
            AfficherInfosPistes();
        }
        private void BtnInstancierUnDisqueTest3_Click(object sender, System.EventArgs e)
        {
            //  Instancier un disque Test3 et conserver sa r�f�rence dans la variable m_objDisqueCourant
            m_objDisqueCourant = new DisqueCompact(SorteDeDisque.Test3);
            //  Appeler les m�thodes AfficherInfosDisque et AfficherInfosPistes
            AfficherInfosDisque();
            AfficherInfosPistes();
        }
        #endregion

        #region NbPistesDureeSupA5Min

        /// ------------------------------------------------------------------------------------------
        /// <summary>
        /// Compte le nombre de pistes sur le disque courant dont la dur�e est sup�rieure � pSecondes.
        /// </summary>
        /// <param name="pSecondes"></param>
        /// <returns>Le nombre de pistes dont la dur�e est sup�rieure � pSecondes.</returns>
        private int NbPistesDur�eSup�rieure�PSecondes(int pSecondes)
        {
            // TODO 01 : Compl�ter le code de cette m�thode
            int nombrePistes = 0;

            for(int index = 0; index < m_objDisqueCourant.Pistes.Length; index++)
            {
                if (m_objDisqueCourant.Pistes[index] > pSecondes)
                {
                    nombrePistes++;
                }
            }

            return nombrePistes;
        }
        #endregion

        #region DureeMaximum
        /// -----------------------------------------------------------------------------------
        /// <summary>
        /// Parcourt la collection de pistes du disque courant afin de d�terminer celle ayant 
        /// la dur�e plus grande.
        /// </summary>
        /// <returns>Dur�e en secondes de la piste la plus longue.</returns>
        /// -----------------------------------------------------------------------------------
        private int DureeMaximum()
        {
            //  Compl�ter le code de cette m�thode
            int dureeMaximum = m_objDisqueCourant.Pistes[0];

            for (int index = 1; index < m_objDisqueCourant.Pistes.Length; index++)
            {
                if (dureeMaximum < m_objDisqueCourant.Pistes[index])
                {
                    dureeMaximum = m_objDisqueCourant.Pistes[index];
                }
            }
            return dureeMaximum;
        }
        #endregion

        #region Position de DureeMinimum
        /// -----------------------------------------------------------------------------------
        /// <summary>
        /// Parcourt la collection de pistes du disque courant afin de d�terminer la position du piste ayant 
        /// la dur�e la plus petite.
        /// </summary>
        /// <returns>Position du piste de dur�e minumum.</returns>
        /// -----------------------------------------------------------------------------------
        private int PositionPisteDeDureeMinimum()
        {
            // TODO 03 : Compl�ter le code de cette m�thode
            int dureeMin = int.MaxValue;
            int positionDureeMin = -1;
            for (int index = 0; index < m_objDisqueCourant.Pistes.Length; index++)
            {
                if (m_objDisqueCourant.Pistes[index] < dureeMin)
                {
                    dureeMin = m_objDisqueCourant.Pistes[index];
                    positionDureeMin = index;
                }
            }

            return positionDureeMin+1;
        }
        #endregion


        #region Somme des pistes d'une position paires
        /// -----------------------------------------------------------------------------------
        /// <summary>
        /// Parcourt la collection de pistes du disque courant afin de d�terminer la dur�e totale des pistes ayant une position paires
        /// 
        /// </summary>
        /// <returns>dur�e totale des pistes ayant une position paires.</returns>
        /// -----------------------------------------------------------------------------------
        private int SommeDureeAPositionPaire()
        {
            // TODO 05 : Compl�ter le code de cette m�thode
            int somme = 0;
           
            for (int index = 0; index < m_objDisqueCourant.Pistes.Length; index+=2)
            {
                somme += m_objDisqueCourant.Pistes[index];
                 
            }
            return somme;
        }
        #endregion
    }

}