﻿namespace AppBanque
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.panConsommation = new System.Windows.Forms.Panel();
            this.panPompes = new System.Windows.Forms.Panel();
            this.grpPrise1 = new System.Windows.Forms.GroupBox();
            this.btnRetirer = new System.Windows.Forms.Button();
            this.cboMontant = new System.Windows.Forms.ComboBox();
            this.txtSolde = new System.Windows.Forms.TextBox();
            this.lblMontant = new System.Windows.Forms.Label();
            this.lblPrise1Durée = new System.Windows.Forms.Label();
            this.btnDeposer = new System.Windows.Forms.Button();
            this.panConsommation.SuspendLayout();
            this.panPompes.SuspendLayout();
            this.grpPrise1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panConsommation
            // 
            this.panConsommation.BackColor = System.Drawing.Color.Silver;
            this.panConsommation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panConsommation.Controls.Add(this.panPompes);
            this.panConsommation.Location = new System.Drawing.Point(67, 23);
            this.panConsommation.Name = "panConsommation";
            this.panConsommation.Size = new System.Drawing.Size(388, 186);
            this.panConsommation.TabIndex = 34;
            // 
            // panPompes
            // 
            this.panPompes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panPompes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panPompes.Controls.Add(this.grpPrise1);
            this.panPompes.Location = new System.Drawing.Point(12, 9);
            this.panPompes.Name = "panPompes";
            this.panPompes.Size = new System.Drawing.Size(362, 172);
            this.panPompes.TabIndex = 2;
            // 
            // grpPrise1
            // 
            this.grpPrise1.Controls.Add(this.btnRetirer);
            this.grpPrise1.Controls.Add(this.cboMontant);
            this.grpPrise1.Controls.Add(this.txtSolde);
            this.grpPrise1.Controls.Add(this.lblMontant);
            this.grpPrise1.Controls.Add(this.lblPrise1Durée);
            this.grpPrise1.Controls.Add(this.btnDeposer);
            this.grpPrise1.Location = new System.Drawing.Point(13, 11);
            this.grpPrise1.Name = "grpPrise1";
            this.grpPrise1.Size = new System.Drawing.Size(375, 151);
            this.grpPrise1.TabIndex = 29;
            this.grpPrise1.TabStop = false;
            this.grpPrise1.Text = "Compte bancaire";
            // 
            // btnRetirer
            // 
            this.btnRetirer.Location = new System.Drawing.Point(148, 89);
            this.btnRetirer.Name = "btnRetirer";
            this.btnRetirer.Size = new System.Drawing.Size(105, 23);
            this.btnRetirer.TabIndex = 35;
            this.btnRetirer.Text = "Retirer";
            this.btnRetirer.UseVisualStyleBackColor = true;
            this.btnRetirer.Click += new System.EventHandler(this.btnRetirer_Click);
            // 
            // cboMontant
            // 
            this.cboMontant.FormattingEnabled = true;
            this.cboMontant.Items.AddRange(new object[] {
            "10",
            "20",
            "50",
            "100"});
            this.cboMontant.Location = new System.Drawing.Point(74, 60);
            this.cboMontant.Name = "cboMontant";
            this.cboMontant.Size = new System.Drawing.Size(68, 21);
            this.cboMontant.TabIndex = 34;
            // 
            // txtSolde
            // 
            this.txtSolde.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSolde.Location = new System.Drawing.Point(78, 34);
            this.txtSolde.Name = "txtSolde";
            this.txtSolde.ReadOnly = true;
            this.txtSolde.Size = new System.Drawing.Size(61, 23);
            this.txtSolde.TabIndex = 33;
            this.txtSolde.Text = "0";
            this.txtSolde.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblMontant
            // 
            this.lblMontant.AutoSize = true;
            this.lblMontant.Location = new System.Drawing.Point(22, 63);
            this.lblMontant.Name = "lblMontant";
            this.lblMontant.Size = new System.Drawing.Size(58, 15);
            this.lblMontant.TabIndex = 31;
            this.lblMontant.Text = "Montant :";
            // 
            // lblPrise1Durée
            // 
            this.lblPrise1Durée.AutoSize = true;
            this.lblPrise1Durée.Location = new System.Drawing.Point(30, 37);
            this.lblPrise1Durée.Name = "lblPrise1Durée";
            this.lblPrise1Durée.Size = new System.Drawing.Size(45, 15);
            this.lblPrise1Durée.TabIndex = 30;
            this.lblPrise1Durée.Text = "Solde :";
            // 
            // btnDeposer
            // 
            this.btnDeposer.Location = new System.Drawing.Point(25, 89);
            this.btnDeposer.Name = "btnDeposer";
            this.btnDeposer.Size = new System.Drawing.Size(117, 23);
            this.btnDeposer.TabIndex = 28;
            this.btnDeposer.Text = "Déposer";
            this.btnDeposer.UseVisualStyleBackColor = true;
            this.btnDeposer.Click += new System.EventHandler(this.btnDeposer_Click);
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(521, 251);
            this.Controls.Add(this.panConsommation);
            this.Name = "FrmPrincipal";
            this.Text = "Instanciation de classes";
            this.panConsommation.ResumeLayout(false);
            this.panPompes.ResumeLayout(false);
            this.grpPrise1.ResumeLayout(false);
            this.grpPrise1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panConsommation;
        private System.Windows.Forms.Panel panPompes;
        private System.Windows.Forms.GroupBox grpPrise1;
        private System.Windows.Forms.Button btnRetirer;
        private System.Windows.Forms.ComboBox cboMontant;
        private System.Windows.Forms.TextBox txtSolde;
        private System.Windows.Forms.Label lblMontant;
        private System.Windows.Forms.Label lblPrise1Durée;
        private System.Windows.Forms.Button btnDeposer;
    }
}

