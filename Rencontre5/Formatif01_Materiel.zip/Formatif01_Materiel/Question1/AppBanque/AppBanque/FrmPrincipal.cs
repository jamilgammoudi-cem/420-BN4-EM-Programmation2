﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppBanque
{
    // TODO 00 : Observer la classe Compte 
    public partial class FrmPrincipal : Form
    {
        #region Champs
        // TODO 01 : Déclarer une variable membre nommée m_compte de type Compte 
       
        #endregion
        public FrmPrincipal()
        {
            InitializeComponent();

            // TODO 02 : Instancier un objet de la classe Compte avec un solde initial égal à 100
            // et l'affecter à la variable membre m_compte
           

            #region // NE PAS MODIFIER
            AfficherSoldeCourant();
            MettreAJourSelonContexte();
            #endregion

        }
        //=================================================================================================
        private void AfficherSoldeCourant()
        {
            // TODO 03 : Afficher le solde courant
           
        }
        //=================================================================================================
        private void btnDeposer_Click(object sender, EventArgs e)
        {
            // TODO 04 : Déposer dans le compte le montant selectionné 
           
              
               
           
           

            #region // NE PAS MODIFIER
            AfficherSoldeCourant();
            MettreAJourSelonContexte();
            #endregion

        }


        private void btnRetirer_Click(object sender, EventArgs e)
        {
            // TODO 05 : Retirer du compte le montant selectionné 


           

            #region // NE PAS MODIFIER
            AfficherSoldeCourant();
            MettreAJourSelonContexte();
            #endregion

        }

        private void MettreAJourSelonContexte()
        {
            // TODO 06 : Activer/Désactiver le bouton Retirer en fonction du solde courant
         
            
           


        }
        #region // NE PAS MODIFIER
        //=================================================================================================
        private void mnuFichierQuitter_Click(object sender, EventArgs e)
        {
            Close();
        }
        #endregion


    }
}
