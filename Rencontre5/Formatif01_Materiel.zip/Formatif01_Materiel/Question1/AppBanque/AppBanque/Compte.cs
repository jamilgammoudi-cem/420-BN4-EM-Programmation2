﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppBanque
{
    public class Compte
    {

        public int Solde { get; set; }

        public Compte(int pMontant)
        {
            Solde = pMontant;
        }
        public void Deposer(int pMontant)
        {
            Solde += pMontant;
        }
        public void Retirer(int pMontant)
        {
            Solde -= pMontant;
        }
    }
    
}
