using System;
using System.Windows.Forms;
using Librairie1N6;

namespace InstancierUnDC
{
    public partial class FrmEx1UnDC : Form
    {
        ///----------------------------------------------------------------------
        /// <summary>
        /// Description : Instancier un disque compact.
        /// </summary>
        //-----------------------------------------------------------------------
        public const string APP_INFO = "(D�MO)";

        #region NE PAS MODIFIER
        public FrmEx1UnDC()
        {
            InitializeComponent();
            Text += APP_INFO;
        }
        private void MnuFichierQuitter_Click(object sender, EventArgs e)
        {
            Close();
        }
        #endregion 

        //  ------------------------------------------------------------------------------------------
        private void btnInstancierUnDC_Click(object sender, EventArgs e)
        {
            //  Instancier un objet disque compact avec le constructeur sans param�tre.
            //-----------------------------------------------------------------------------------------
            DisqueCompact objDisque = new DisqueCompact();

            //  Afficher les informations sur le disque instanci� dans les zones de texte appropri�es:
            //           le nombre de pistes, la dur�e totale en secondes, la dur�e totale en MM:SS et le genre de musique.
            //           Pour obtenir la dur�e totale dans un format MM:SS utiliser la m�thode statique FormatMMSS
            // ------------------------------------------------------------------------------------------------------------------
            txtNbPistes.Text = objDisque.Pistes.Length.ToString();
            txtDureeTotaleSecondes.Text = objDisque.Dur�e.ToString();
            txtDureeTotaleMMSS.Text = DisqueCompact.FormatMMSS(objDisque.Dur�e);
            txtGenre.Text = objDisque.Genre.ToString();
        }
    }
}